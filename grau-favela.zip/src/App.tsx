import { useCallback, useEffect, useRef, useState } from 'react';
import {
  Bike,
  Camera,
  ChevronDown,
  ChevronUp,
  Footprints,
  Gamepad2,
  Hand,
  Maximize2,
  Minimize2,
  Monitor,
  RotateCcw,
  Sliders,
  Volume2,
  VolumeX,
} from 'lucide-react';
import { GamepadButtonId, GamepadOverlay } from './components/GamepadOverlay';
import { GameEngine } from './game/GameEngine';
import { PLAZA_RECT, STREETS, STUNT_RAMPS } from './game/RoadTerrain';
import {
  CameraMode,
  EmoteId,
  GloveStyle,
  GraphicsQuality,
  LoadProgress,
  PhysicsPreset,
  TelemetryState,
} from './game/types';

const INITIAL_TELEMETRY: TelemetryState = {
  speedKmh: 0,
  rpm: 1450,
  maxRpm: 15000,
  gear: 1,
  wheelieAngleDeg: 0,
  stoppieAngleDeg: 0,
  leanAngleDeg: 0,
  frontSuspRatio: 0.25,
  rearSuspRatio: 0.27,
  rearSlip: 0,
  isWheelie: false,
  isBalancePoint: false,
  isScrape: false,
  isStoppie: false,
  isAirborne: false,
  isNoHand: false,
  activeEmote: 'none',
  revLimiter: false,
  clutchEngaged: true,
  grauDistanceM: 0,
  grauDurationS: 0,
  currentCombo: 0,
  totalScore: 0,
  bestGrauDistanceM: 0,
  bestCombo: 0,
  crashed: false,
  crashReason: '',
  posX: -65,
  posZ: 0,
  yawRad: 0,
  riderState: 'mounted',
  nearBike: true,
  dismountHint: '',
};

const CAMERA_OPTIONS: { id: CameraMode; label: string }[] = [
  { id: 'first_person', label: '1ª Pessoa' },
  { id: 'third_person', label: '3ª Pessoa' },
  { id: 'moto_vlog', label: 'Moto Vlog' },
  { id: 'free_orbit', label: 'Livre' },
];

const PHYSICS_OPTIONS: { id: PhysicsPreset; label: string }[] = [
  { id: 'mx_pro', label: 'MX Pro' },
  { id: 'simulation', label: 'Simulação' },
  { id: 'assist', label: 'Assistido' },
];

const GLOVE_OPTIONS: { id: GloveStyle; label: string }[] = [
  { id: 'none', label: 'Sem' },
  { id: 'black', label: 'Preta' },
  { id: 'ducati_red', label: 'Vermelha' },
  { id: 'white', label: 'Branca' },
];

const GRAPHICS_OPTIONS: { id: GraphicsQuality; label: string }[] = [
  { id: 'low', label: 'Baixo' },
  { id: 'medium', label: 'Médio' },
  { id: 'high', label: 'Alto' },
  { id: 'ultra', label: 'Ultra' },
];

const EMOTE_OPTIONS: { id: Exclude<EmoteId, 'none'>; emoji: string; label: string }[] = [
  { id: 'salve', emoji: '✌️', label: 'Salve' },
  { id: 'hang_loose', emoji: '🤙', label: 'Grau' },
  { id: 'salute', emoji: '🫡', label: 'Continência' },
  { id: 'flex', emoji: '💪', label: 'Força' },
  { id: 'celebrate', emoji: '🙌', label: 'Comemorar' },
  { id: 'clap', emoji: '👏', label: 'Palmas' },
];

const UI_FOCUS_COUNT = 13;

export default function App() {
  const canvasMountRef = useRef<HTMLDivElement | null>(null);
  const engineRef = useRef<GameEngine | null>(null);

  const [loadProgress, setLoadProgress] = useState<LoadProgress>({
    loaded: false,
    percent: 0,
    statusText: 'Inicializando motor 3D...',
    error: null,
  });
  const [telemetry, setTelemetry] = useState<TelemetryState>(INITIAL_TELEMETRY);
  const [cameraMode, setCameraMode] = useState<CameraMode>('first_person');
  const [physicsPreset, setPhysicsPreset] = useState<PhysicsPreset>('simulation');
  const [autoGear, setAutoGear] = useState(true);
  const [molejoLevel, setMolejoLevel] = useState(1.0);
  const [fpFov, setFpFov] = useState(78);
  const [fpCamDist, setFpCamDist] = useState(0);
  const [gloveStyle, setGloveStyle] = useState<GloveStyle>('black');
  const [graphicsQuality, setGraphicsQuality] = useState<GraphicsQuality>('high');
  const [muted, setMuted] = useState(false);
  const [dockOpen, setDockOpen] = useState(false);
  const [uiNavOpen, setUiNavOpen] = useState(false);
  const [uiFocusIdx, setUiFocusIdx] = useState(0);
  const [showAnalog, setShowAnalog] = useState(true);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [selectedEmote, setSelectedEmote] = useState<Exclude<EmoteId, 'none'>>('salve');

  useEffect(() => {
    const onFsChange = () => {
      setIsFullscreen(Boolean(document.fullscreenElement));
    };
    document.addEventListener('fullscreenchange', onFsChange);
    return () => document.removeEventListener('fullscreenchange', onFsChange);
  }, []);

  useEffect(() => {
    const mount = canvasMountRef.current;
    if (!mount) return;

    const engine = new GameEngine(
      mount,
      (progress) => setLoadProgress(progress),
      (t) => setTelemetry(t)
    );
    engineRef.current = engine;

    const onKey = (e: KeyboardEvent) => {
      if (e.repeat) return;
      if (e.code === 'KeyH') {
        setDockOpen((prev) => {
          const next = !prev;
          if (!next) setUiNavOpen(false);
          return next;
        });
      } else if (e.code === 'KeyV') {
        setCameraMode(engine.cameraMode);
      } else if (e.code === 'KeyG') {
        setAutoGear((prev) => !prev);
      }
    };
    window.addEventListener('keydown', onKey);

    return () => {
      window.removeEventListener('keydown', onKey);
      engine.dispose();
      engineRef.current = null;
    };
  }, []);

  const handleCameraChange = useCallback((mode: CameraMode) => {
    setCameraMode(mode);
    engineRef.current?.setCameraMode(mode);
  }, []);

  const handleCycleCamera = useCallback(() => {
    const next = engineRef.current?.cycleCameraMode();
    if (next) setCameraMode(next);
  }, []);

  const handlePresetChange = useCallback((preset: PhysicsPreset) => {
    setPhysicsPreset(preset);
    engineRef.current?.setPhysicsPreset(preset);
  }, []);

  const handleAutoGearToggle = useCallback(() => {
    setAutoGear((prev) => {
      const next = !prev;
      engineRef.current?.setAutoGear(next);
      return next;
    });
  }, []);

  const handleMolejoChange = useCallback((val: number) => {
    setMolejoLevel(val);
    if (engineRef.current) {
      engineRef.current.molejoMultiplier = val;
    }
  }, []);

  const handleFovChange = useCallback(
    (val: number) => {
      setFpFov(val);
      engineRef.current?.setFirstPersonConfig(val, fpCamDist);
    },
    [fpCamDist]
  );

  const handleCamDistChange = useCallback(
    (val: number) => {
      setFpCamDist(val);
      engineRef.current?.setFirstPersonConfig(fpFov, val);
    },
    [fpFov]
  );

  const handleGloveChange = useCallback((style: GloveStyle) => {
    setGloveStyle(style);
    engineRef.current?.setGloveStyle(style);
  }, []);

  const handleGraphicsChange = useCallback((quality: GraphicsQuality) => {
    setGraphicsQuality(quality);
    engineRef.current?.setGraphicsQuality(quality);
  }, []);

  const handleToggleMute = useCallback(() => {
    setMuted((prev) => {
      const next = !prev;
      engineRef.current?.audio.start();
      engineRef.current?.audio.setMuted(next);
      return next;
    });
  }, []);

  const handleReset = useCallback(() => {
    engineRef.current?.audio.start();
    engineRef.current?.resetBike();
  }, []);

  const handleToggleDismount = useCallback(() => {
    engineRef.current?.audio.start();
    engineRef.current?.toggleDismount();
  }, []);

  const handleToggleFullscreen = useCallback(async () => {
    try {
      if (!document.fullscreenElement) {
        await document.documentElement.requestFullscreen();
      } else {
        await document.exitFullscreen();
      }
    } catch {
      // Fullscreen may be restricted by parent iframe policy
    }
  }, []);

  const handleAnalogMove = useCallback((x: number, y: number) => {
    const eng = engineRef.current;
    if (!eng) return;
    eng.setVirtualInput('steer', x);
    // Deadzone on Y so steering left/right doesn't accidentally pull Grau
    const deadzone = 0.28;
    const pitch = Math.abs(y) < deadzone ? 0 : (y - Math.sign(y) * deadzone) / (1 - deadzone);
    eng.setVirtualInput('riderPitch', pitch);
  }, []);

  const handleRightStickMove = useCallback((x: number, y: number) => {
    engineRef.current?.setVirtualCameraLook(x, y);
  }, []);

  const handleAudioWake = useCallback(() => {
    engineRef.current?.audio.start();
  }, []);

  const handleTriggerEmote = useCallback((id: Exclude<EmoteId, 'none'>) => {
    engineRef.current?.audio.start();
    setSelectedEmote(id);
    engineRef.current?.setVirtualInput('emote', id);
    engineRef.current?.triggerEmote(id, 3.2);
  }, []);

  const adjustFocusedUi = useCallback(
    (dir: -1 | 1 | 0) => {
      const cycle = <T,>(arr: { id: T }[], cur: T, step: number) => {
        const idx = arr.findIndex((item) => item.id === cur);
        const nextIdx = (Math.max(0, idx) + step + arr.length) % arr.length;
        return arr[nextIdx].id;
      };

      switch (uiFocusIdx) {
        case 0:
          handleCameraChange(cycle(CAMERA_OPTIONS, cameraMode, dir === 0 ? 1 : dir));
          break;
        case 1:
          handlePresetChange(cycle(PHYSICS_OPTIONS, physicsPreset, dir === 0 ? 1 : dir));
          break;
        case 2:
          handleGloveChange(cycle(GLOVE_OPTIONS, gloveStyle, dir === 0 ? 1 : dir));
          break;
        case 3:
          handleGraphicsChange(cycle(GRAPHICS_OPTIONS, graphicsQuality, dir === 0 ? 1 : dir));
          break;
        case 4: {
          const step = dir === 0 ? 0.1 : dir * 0.1;
          handleMolejoChange(Math.round(Math.min(1.8, Math.max(0.3, molejoLevel + step)) * 10) / 10);
          break;
        }
        case 5: {
          const step = dir === 0 ? 0.02 : dir * 0.02;
          handleCamDistChange(
            Math.round(Math.min(0.24, Math.max(-0.18, fpCamDist + step)) * 100) / 100
          );
          break;
        }
        case 6: {
          const step = dir === 0 ? 3 : dir * 3;
          handleFovChange(Math.min(115, Math.max(65, fpFov + step)));
          break;
        }
        case 7:
          handleAutoGearToggle();
          break;
        case 8:
          setShowAnalog((v) => !v);
          break;
        case 9:
          handleToggleMute();
          break;
        case 10:
          handleToggleDismount();
          break;
        case 11:
          void handleToggleFullscreen();
          break;
        case 12:
          handleReset();
          break;
        default:
          break;
      }
    },
    [
      cameraMode,
      fpCamDist,
      fpFov,
      gloveStyle,
      graphicsQuality,
      handleAutoGearToggle,
      handleCamDistChange,
      handleCameraChange,
      handleFovChange,
      handleGloveChange,
      handleGraphicsChange,
      handleMolejoChange,
      handlePresetChange,
      handleReset,
      handleToggleDismount,
      handleToggleFullscreen,
      handleToggleMute,
      molejoLevel,
      physicsPreset,
      uiFocusIdx,
    ]
  );

  const handleGamepadHold = useCallback(
    (id: GamepadButtonId, pressed: boolean) => {
      const eng = engineRef.current;
      if (!eng) return;

      if (uiNavOpen) {
        if (id === 'lt') eng.setVirtualInput('frontBrake', pressed ? 1 : 0);
        if (id === 'rt') eng.setVirtualInput('throttle', pressed ? 1 : 0);
        return;
      }

      const onFoot = telemetry.riderState === 'on_foot';
      switch (id) {
        case 'rt':
          eng.setVirtualInput('throttle', pressed ? 1 : 0);
          break;
        case 'lt':
          eng.setVirtualInput('frontBrake', pressed ? 1 : 0);
          break;
        case 'rb':
          if (onFoot) {
            eng.setVirtualInput('noHand', pressed);
          } else {
            eng.setVirtualInput('riderPitch', pressed ? 1 : 0);
          }
          break;
        case 'lb':
          eng.setVirtualInput('clutch', pressed);
          break;
        case 'a':
          eng.setVirtualInput('rearBrake', pressed ? 1 : 0);
          break;
        case 'x':
          eng.setVirtualInput('noHand', pressed);
          break;
        case 'b':
          if (onFoot) {
            eng.setVirtualInput('clutch', pressed);
          } else {
            eng.setVirtualInput('burnout', pressed);
          }
          break;
        case 'dpad_left':
          eng.setVirtualInput('molejo', pressed ? -molejoLevel : 0);
          break;
        case 'dpad_right':
          eng.setVirtualInput('molejo', pressed ? molejoLevel : 0);
          break;
        default:
          break;
      }
    },
    [molejoLevel, telemetry.riderState, uiNavOpen]
  );

  const handleGamepadPress = useCallback(
    (id: GamepadButtonId) => {
      const eng = engineRef.current;

      if (id === 'menu') {
        setDockOpen((prevDock) => {
          const next = !prevDock;
          setUiNavOpen(next);
          return next;
        });
        return;
      }

      if (id === 'view') {
        handleCycleCamera();
        return;
      }

      if (id === 'r3') {
        eng?.resetCameraLook();
        return;
      }

      if (id === 'l3') {
        handleReset();
        return;
      }

      if (uiNavOpen) {
        switch (id) {
          case 'dpad_up':
            setUiFocusIdx((i) => (i - 1 + UI_FOCUS_COUNT) % UI_FOCUS_COUNT);
            break;
          case 'dpad_down':
            setUiFocusIdx((i) => (i + 1) % UI_FOCUS_COUNT);
            break;
          case 'dpad_left':
            adjustFocusedUi(-1);
            break;
          case 'dpad_right':
            adjustFocusedUi(1);
            break;
          case 'a':
            adjustFocusedUi(0);
            break;
          case 'x':
            handleToggleMute();
            break;
          case 'b':
            setUiNavOpen(false);
            setDockOpen(false);
            break;
          case 'y':
            handleToggleDismount();
            break;
          default:
            break;
        }
        return;
      }

      if (id === 'y') {
        handleToggleDismount();
      } else if (id === 'dpad_up') {
        eng?.shiftUp();
      } else if (id === 'dpad_down') {
        eng?.shiftDown();
      }
    },
    [
      adjustFocusedUi,
      handleCycleCamera,
      handleReset,
      handleToggleDismount,
      handleToggleMute,
      uiNavOpen,
    ]
  );

  const rpmRatio = Math.min(1, telemetry.rpm / telemetry.maxRpm);
  const wheelieTargetPct = Math.min(100, Math.max(0, (telemetry.wheelieAngleDeg / 90) * 100));
  const speedIntensity =
    telemetry.riderState === 'mounted'
      ? Math.min(1, Math.max(0, (telemetry.speedKmh - 55) / 145))
      : 0;

  return (
    <div className="relative w-full h-full overflow-hidden bg-[#0b0d11] text-zinc-100">
      {/* Dedicated WebGL Canvas Container */}
      <div ref={canvasMountRef} className="fixed inset-0 w-full h-full" />

      {/* Subtle First-Person Helmet Visor Rim Vignette */}
      {loadProgress.loaded && cameraMode === 'first_person' && (
        <div
          className="pointer-events-none fixed inset-0 z-10"
          style={{
            background:
              'radial-gradient(ellipse 86% 80% at 50% 48%, rgba(0,0,0,0) 68%, rgba(8,10,14,0.42) 90%, rgba(5,6,9,0.82) 100%)',
          }}
        />
      )}

      {/* High-Speed Peripheral Wind Streaks & Speed Tunnel Effect */}
      {loadProgress.loaded && speedIntensity > 0.02 && cameraMode !== 'free_orbit' && (
        <svg
          viewBox="0 0 100 100"
          preserveAspectRatio="none"
          className="pointer-events-none fixed inset-0 z-10 w-full h-full"
          opacity={speedIntensity * 0.55}
          aria-hidden="true"
        >
          {[
            [6, 12, 16, 22],
            [14, 5, 22, 15],
            [86, 5, 78, 15],
            [94, 12, 84, 22],
            [3, 35, 13, 39],
            [97, 35, 87, 39],
            [3, 64, 14, 60],
            [97, 64, 86, 60],
            [8, 86, 18, 76],
            [92, 86, 82, 76],
            [26, 3, 31, 12],
            [74, 3, 69, 12],
          ].map(([x1, y1, x2, y2], idx) => (
            <line
              key={idx}
              x1={x1}
              y1={y1}
              x2={x2}
              y2={y2}
              stroke="#e2e8f0"
              strokeWidth={0.22}
              strokeLinecap="round"
              strokeOpacity={0.35 + (idx % 3) * 0.16}
            />
          ))}
        </svg>
      )}

      {/* Top-Left Minimal Brand & Digital Moto Cluster */}
      {loadProgress.loaded && (
        <header className="pointer-events-none fixed top-4 left-4 z-20 flex flex-col gap-2">
          <div className="pointer-events-auto flex items-baseline gap-3 px-3.5 py-2 rounded-lg bg-[#0d1016]/85 border border-white/10">
            <h1 className="font-display text-lg font-bold tracking-tight text-white whitespace-nowrap">
              Grau Favela
            </h1>
            <span className="text-xs text-zinc-400 whitespace-nowrap">
              Ducati V4 S
            </span>
            <span className="text-xs text-zinc-500" aria-hidden="true">
              ·
            </span>
            <span className="text-xs text-zinc-300 font-mono-num whitespace-nowrap">
              Recorde {telemetry.bestGrauDistanceM.toFixed(1)} m
            </span>
            <span className="text-xs text-zinc-500" aria-hidden="true">
              ·
            </span>
            <span className="text-xs text-amber-400 font-mono-num whitespace-nowrap">
              {telemetry.totalScore} pts
            </span>
          </div>

          {/* Compact MX Bikes Telemetry Strip */}
          <div className="flex items-center gap-4 px-3.5 py-2.5 rounded-lg bg-[#0d1016]/85 border border-white/10">
            <div className="flex items-baseline gap-1.5">
              <span className="font-display text-3xl font-bold leading-none font-mono-num text-white">
                {telemetry.speedKmh}
              </span>
              <span className="text-[11px] text-zinc-400">km/h</span>
            </div>

            <div className="h-7 w-px bg-white/10" />

            <div className="flex flex-col items-center min-w-[28px]">
              <span className="text-[10px] text-zinc-400 leading-none">Marcha</span>
              <span className="font-display text-xl font-bold leading-tight text-amber-400 font-mono-num">
                {telemetry.gear === 0 ? 'N' : telemetry.gear}
              </span>
            </div>

            <div className="h-7 w-px bg-white/10" />

            <div className="flex flex-col gap-1 w-32">
              <div className="flex justify-between text-[10px] text-zinc-400 font-mono-num leading-none">
                <span>{(telemetry.rpm / 1000).toFixed(1)}k RPM</span>
                <span className={telemetry.revLimiter ? 'text-red-400 font-semibold' : ''}>
                  {telemetry.revLimiter ? 'Corte' : `${Math.abs(telemetry.leanAngleDeg)}°`}
                </span>
              </div>
              <div className="h-1.5 w-full rounded-sm bg-zinc-800 overflow-hidden">
                <div
                  className={`h-full transition-[width] duration-75 ${
                    rpmRatio > 0.88
                      ? 'bg-red-500'
                      : rpmRatio > 0.65
                        ? 'bg-amber-400'
                        : 'bg-emerald-400'
                  }`}
                  style={{ width: `${rpmRatio * 100}%` }}
                />
              </div>
              <div className="flex gap-1.5 pt-0.5">
                <div className="flex-1 h-1 rounded-sm bg-zinc-800 overflow-hidden" title="Suspensão Dianteira">
                  <div
                    className="h-full bg-sky-400"
                    style={{ width: `${Math.min(100, telemetry.frontSuspRatio * 100)}%` }}
                  />
                </div>
                <div className="flex-1 h-1 rounded-sm bg-zinc-800 overflow-hidden" title="Suspensão Traseira">
                  <div
                    className="h-full bg-orange-400"
                    style={{ width: `${Math.min(100, telemetry.rearSuspRatio * 100)}%` }}
                  />
                </div>
              </div>
            </div>
          </div>
        </header>
      )}

      {/* Top-Right Fullscreen Button + Open-World Mini-Map */}
      {loadProgress.loaded && (
        <div className="fixed top-4 right-4 z-20 flex flex-col items-end gap-2">
          <button
            type="button"
            onClick={handleToggleFullscreen}
            title={isFullscreen ? 'Sair da Tela Cheia' : 'Tela Cheia'}
            className="flex items-center gap-2 px-3 py-2 rounded-lg bg-[#0d1016]/85 hover:bg-[#171c26] border border-white/10 text-xs font-medium text-zinc-100 transition-colors whitespace-nowrap"
          >
            {isFullscreen ? (
              <>
                <Minimize2 className="w-4 h-4 text-amber-400" />
                <span>Sair Tela Cheia</span>
              </>
            ) : (
              <>
                <Maximize2 className="w-4 h-4 text-amber-400" />
                <span>Tela Cheia</span>
              </>
            )}
          </button>

          <div
            className="p-2 rounded-lg bg-[#0d1016]/85 border border-white/10 flex flex-col gap-1"
            title="Mapa Complexo do Grau"
          >
            <svg
              viewBox="-450 -315 900 555"
              className="w-36 h-24 rounded bg-[#141922] border border-white/5"
            >
              {/* Quadra / Praça */}
              <rect
                x={PLAZA_RECT.minX}
                y={PLAZA_RECT.minZ}
                width={PLAZA_RECT.maxX - PLAZA_RECT.minX}
                height={PLAZA_RECT.maxZ - PLAZA_RECT.minZ}
                fill="#1d4d3e"
                stroke="#34d399"
                strokeOpacity={0.35}
                strokeWidth={3}
              />
              {/* Ruas e Becos do Morro */}
              {STREETS.map((s) => (
                <line
                  key={s.id}
                  x1={s.ax}
                  y1={s.az}
                  x2={s.bx}
                  y2={s.bz}
                  stroke={s.isAlley ? '#d97706' : '#64748b'}
                  strokeWidth={s.halfWidth * 2.2}
                  strokeLinecap="round"
                />
              ))}
              {/* Rampas de Grau */}
              {STUNT_RAMPS.map((r, idx) => (
                <circle key={idx} cx={r.x} cy={r.z} r={7} fill="#fbbf24" />
              ))}
              {/* Jogador */}
              <g
                transform={`translate(${telemetry.posX}, ${telemetry.posZ}) rotate(${
                  (-telemetry.yawRad * 180) / Math.PI
                })`}
              >
                <polygon
                  points="22,0 -13,-12 -6,0 -13,12"
                  fill="#f59e0b"
                  stroke="#ffffff"
                  strokeWidth={3}
                />
              </g>
            </svg>
            <div className="flex items-center justify-between text-[10px] text-zinc-400 leading-none px-0.5">
              <span>Morro ↑</span>
              <span className="text-emerald-400">Quadra</span>
            </div>
          </div>
        </div>
      )}

      {/* Top-Center Live Grau Balance Indicator */}
      {loadProgress.loaded && (telemetry.isWheelie || telemetry.isStoppie || telemetry.crashed) && (
        <div className="pointer-events-none fixed top-4 left-1/2 -translate-x-1/2 z-20 flex flex-col items-center gap-1.5">
          {telemetry.crashed ? (
            <div className="pointer-events-auto flex items-center gap-3 px-4 py-2.5 rounded-lg bg-[#1a0d0e]/95 border border-red-500/40">
              <div className="flex flex-col">
                <span className="font-display text-base font-bold text-red-400">
                  {telemetry.crashReason}
                </span>
                <span className="text-xs text-zinc-300">
                  Pressione R ou clique em Voltar para levantar a moto
                </span>
              </div>
              <button
                type="button"
                onClick={handleReset}
                className="px-3 py-1.5 rounded-md bg-red-500 hover:bg-red-400 text-white text-xs font-semibold transition-colors whitespace-nowrap"
              >
                Voltar na pista
              </button>
            </div>
          ) : (
            <div className="flex flex-col items-center gap-1.5 px-4 py-2 rounded-lg bg-[#0d1016]/85 border border-white/10 min-w-[230px]">
              <div className="flex items-center justify-between w-full gap-4">
                <span
                  className={`font-display text-sm font-bold ${
                    telemetry.isScrape
                      ? 'text-orange-400'
                      : telemetry.isBalancePoint
                        ? 'text-emerald-400'
                        : telemetry.isStoppie
                          ? 'text-sky-400'
                          : 'text-amber-400'
                  }`}
                >
                  {telemetry.isStoppie
                    ? `RL / Stoppie ${telemetry.stoppieAngleDeg}°`
                    : telemetry.isScrape
                      ? `Raspão ${telemetry.wheelieAngleDeg}°`
                      : telemetry.isBalancePoint
                        ? `Ponto do Grau ${telemetry.wheelieAngleDeg}°`
                        : `Grau ${telemetry.wheelieAngleDeg}°`}
                  {telemetry.isNoHand ? ' · Sem Mão' : ''}
                </span>
                {telemetry.isWheelie && (
                  <span className="font-mono-num text-xs text-zinc-200">
                    {telemetry.grauDistanceM.toFixed(1)} m · +{telemetry.currentCombo}
                  </span>
                )}
              </div>

              {telemetry.isWheelie && (
                <div className="relative w-full h-2 rounded-sm bg-zinc-800 overflow-hidden">
                  <div
                    className="absolute top-0 bottom-0 bg-emerald-500/30"
                    style={{ left: '53%', width: '32%' }}
                  />
                  <div
                    className="absolute top-0 bottom-0 bg-orange-500/40"
                    style={{ left: '85%', width: '15%' }}
                  />
                  <div
                    className="absolute top-0 bottom-0 w-1.5 bg-white transition-[left] duration-75"
                    style={{ left: `calc(${wheelieTargetPct}% - 3px)` }}
                  />
                </div>
              )}
            </div>
          )}
        </div>
      )}

      {/* Dismount / On-Foot Hint & Near-Bike Prompt */}
      {loadProgress.loaded &&
        (telemetry.dismountHint || (telemetry.riderState === 'on_foot' && telemetry.nearBike)) &&
        !telemetry.isWheelie &&
        !telemetry.isStoppie &&
        !telemetry.crashed && (
          <div className="pointer-events-none fixed top-4 left-1/2 -translate-x-1/2 z-20 flex flex-col items-center gap-1.5">
            {telemetry.dismountHint ? (
              <div className="px-4 py-2 rounded-lg bg-[#0d1016]/90 border border-amber-500/40 text-xs font-semibold text-amber-300">
                {telemetry.dismountHint}
              </div>
            ) : (
              <button
                type="button"
                onClick={(e) => {
                  e.currentTarget.blur();
                  handleToggleDismount();
                }}
                className="pointer-events-auto flex items-center gap-2 px-4 py-2 rounded-lg bg-[#0d1016]/90 hover:bg-[#171c26] border border-emerald-400/50 text-xs font-semibold text-emerald-300 shadow-lg transition-colors"
              >
                <Bike className="w-4 h-4" />
                <span>Subir na Moto (Enter / U)</span>
              </button>
            )}
          </div>
        )}

      {/* Quick Emoji Emotes Strip (Works on Bike & On Foot, keys 1-6 or tap) */}
      {loadProgress.loaded && (
        <div
          className={`fixed left-1/2 -translate-x-1/2 z-20 flex items-center gap-1 px-2 py-1 rounded-full bg-[#0d1016]/85 border border-white/10 shadow-lg transition-all duration-150 ${
            telemetry.isWheelie ||
            telemetry.isStoppie ||
            telemetry.crashed ||
            telemetry.dismountHint ||
            (telemetry.riderState === 'on_foot' && telemetry.nearBike)
              ? 'top-[76px]'
              : 'top-4'
          }`}
        >
          {EMOTE_OPTIONS.map((em, idx) => {
            const isActive = telemetry.activeEmote === em.id;
            const isSelected = selectedEmote === em.id;
            return (
              <button
                key={em.id}
                type="button"
                title={`${em.label} (${idx + 1})`}
                aria-label={`Emote ${em.label}`}
                onClick={(e) => {
                  e.currentTarget.blur();
                  handleTriggerEmote(em.id);
                }}
                className={`w-8 h-8 rounded-full flex items-center justify-center text-base leading-none transition-transform duration-100 select-none ${
                  isActive
                    ? 'bg-amber-500 scale-110 shadow-[0_0_10px_rgba(245,158,11,0.75)]'
                    : isSelected
                      ? 'bg-white/15 hover:bg-white/25 ring-1 ring-amber-400/50'
                      : 'hover:bg-white/15 active:scale-95'
                }`}
              >
                {em.emoji}
              </button>
            );
          })}
        </div>
      )}

      {/* Transparent Cut-Out Full Game & Interface Gamepad Overlay */}
      {loadProgress.loaded && showAnalog && (
        <GamepadOverlay
          riderState={telemetry.riderState}
          uiNavOpen={uiNavOpen}
          onAudioWake={handleAudioWake}
          onLeftStick={handleAnalogMove}
          onRightStick={handleRightStickMove}
          onHoldButton={handleGamepadHold}
          onPressButton={handleGamepadPress}
        />
      )}

      {/* Collapsible Unified Bottom Control Dock (positioned cleanly above center View/Menu sprites) */}
      {loadProgress.loaded && (dockOpen || !showAnalog) && (
        <div
          className={`fixed left-1/2 -translate-x-1/2 z-30 flex flex-col items-center transition-all duration-200 ${
            showAnalog ? 'bottom-16' : 'bottom-4'
          }`}
          style={{
            maxWidth: 'min(760px, 68vw)',
            transform: dockOpen ? 'translate(-50%, 0)' : 'translate(-50%, calc(100% - 34px))',
          }}
        >
          <button
            type="button"
            onClick={() =>
              setDockOpen((v) => {
                const next = !v;
                if (!next) setUiNavOpen(false);
                return next;
              })
            }
            className="flex items-center gap-1.5 px-3 py-1 rounded-t-lg bg-[#0d1016]/90 border border-b-0 border-white/10 text-[11px] font-medium text-zinc-300 hover:text-white transition-colors whitespace-nowrap"
          >
            {dockOpen ? <ChevronDown className="w-3.5 h-3.5" /> : <ChevronUp className="w-3.5 h-3.5" />}
            <span>{dockOpen ? 'Ocultar Interface (H / ≡)' : 'Interface (H)'}</span>
          </button>

          <div className="w-full px-3.5 py-2.5 rounded-xl bg-[#0d1016]/92 border border-white/10 flex flex-col gap-2 shadow-2xl">
            <div className="flex flex-wrap items-center justify-center gap-2">
              {/* 0: Camera Switcher */}
              <div
                className={`flex items-center gap-1.5 rounded-lg px-1 py-0.5 transition-colors ${
                  uiNavOpen && uiFocusIdx === 0 ? 'ring-1 ring-amber-400 bg-amber-500/15' : ''
                }`}
              >
                <Camera className="w-3.5 h-3.5 text-zinc-400 shrink-0" />
                <div className="flex items-center gap-0.5 p-0.5 rounded-lg bg-zinc-900/90 border border-white/5">
                  {CAMERA_OPTIONS.map((opt) => (
                    <button
                      key={opt.id}
                      type="button"
                      onClick={() => handleCameraChange(opt.id)}
                      className={`px-2 py-1 rounded-md text-xs font-medium transition-colors whitespace-nowrap shrink-0 ${
                        cameraMode === opt.id
                          ? 'bg-amber-500 text-zinc-950 font-semibold'
                          : 'text-zinc-300 hover:text-white'
                      }`}
                    >
                      {opt.label}
                    </button>
                  ))}
                </div>
              </div>

              {/* 1: Physics Preset Switcher */}
              <div
                className={`flex items-center gap-1.5 rounded-lg px-1 py-0.5 transition-colors ${
                  uiNavOpen && uiFocusIdx === 1 ? 'ring-1 ring-amber-400 bg-amber-500/15' : ''
                }`}
              >
                <Sliders className="w-3.5 h-3.5 text-zinc-400 shrink-0" />
                <div className="flex items-center gap-0.5 p-0.5 rounded-lg bg-zinc-900/90 border border-white/5">
                  {PHYSICS_OPTIONS.map((opt) => (
                    <button
                      key={opt.id}
                      type="button"
                      onClick={() => handlePresetChange(opt.id)}
                      className={`px-2 py-1 rounded-md text-xs font-medium transition-colors whitespace-nowrap shrink-0 ${
                        physicsPreset === opt.id
                          ? 'bg-zinc-100 text-zinc-950 font-semibold'
                          : 'text-zinc-300 hover:text-white'
                      }`}
                    >
                      {opt.label}
                    </button>
                  ))}
                </div>
              </div>

              {/* 2: Rider Gloves Switcher */}
              <div
                className={`flex items-center gap-1.5 rounded-lg px-1 py-0.5 transition-colors ${
                  uiNavOpen && uiFocusIdx === 2 ? 'ring-1 ring-amber-400 bg-amber-500/15' : ''
                }`}
                title="Colocar ou trocar luvas do piloto"
              >
                <Hand className="w-3.5 h-3.5 text-zinc-400 shrink-0" />
                <div className="flex items-center gap-0.5 p-0.5 rounded-lg bg-zinc-900/90 border border-white/5">
                  {GLOVE_OPTIONS.map((opt) => (
                    <button
                      key={opt.id}
                      type="button"
                      onClick={() => handleGloveChange(opt.id)}
                      className={`px-2 py-1 rounded-md text-xs font-medium transition-colors whitespace-nowrap shrink-0 ${
                        gloveStyle === opt.id
                          ? 'bg-red-500 text-white font-semibold'
                          : 'text-zinc-300 hover:text-white'
                      }`}
                    >
                      {opt.label}
                    </button>
                  ))}
                </div>
              </div>

              {/* 3: Graphics Quality Switcher */}
              <div
                className={`flex items-center gap-1.5 rounded-lg px-1 py-0.5 transition-colors ${
                  uiNavOpen && uiFocusIdx === 3 ? 'ring-1 ring-amber-400 bg-amber-500/15' : ''
                }`}
                title="Aumentar ou abaixar a qualidade dos gráficos"
              >
                <Monitor className="w-3.5 h-3.5 text-zinc-400 shrink-0" />
                <div className="flex items-center gap-0.5 p-0.5 rounded-lg bg-zinc-900/90 border border-white/5">
                  {GRAPHICS_OPTIONS.map((opt) => (
                    <button
                      key={opt.id}
                      type="button"
                      onClick={() => handleGraphicsChange(opt.id)}
                      className={`px-2 py-1 rounded-md text-xs font-medium transition-colors whitespace-nowrap shrink-0 ${
                        graphicsQuality === opt.id
                          ? 'bg-sky-500 text-zinc-950 font-semibold'
                          : 'text-zinc-300 hover:text-white'
                      }`}
                    >
                      {opt.label}
                    </button>
                  ))}
                </div>
              </div>

              {/* 4..12: Sliders & Interface Actions */}
              <div className="flex flex-wrap items-center justify-center gap-2">
                <label
                  className={`flex items-center gap-1.5 text-xs text-zinc-300 whitespace-nowrap rounded-lg px-1.5 py-0.5 ${
                    uiNavOpen && uiFocusIdx === 4 ? 'ring-1 ring-amber-400 bg-amber-500/15' : ''
                  }`}
                >
                  <span>Molejo</span>
                  <input
                    type="range"
                    min={0.3}
                    max={1.8}
                    step={0.1}
                    value={molejoLevel}
                    onChange={(e) => handleMolejoChange(parseFloat(e.target.value))}
                    className="w-14 accent-amber-500 cursor-pointer"
                  />
                </label>

                <label
                  className={`flex items-center gap-1.5 text-xs text-zinc-300 whitespace-nowrap rounded-lg px-1.5 py-0.5 ${
                    uiNavOpen && uiFocusIdx === 5 ? 'ring-1 ring-amber-400 bg-amber-500/15' : ''
                  }`}
                  title="Ajustar distância da câmera em 1ª Pessoa (mais perto ou mais longe)"
                >
                  <span>Dist. 1ª</span>
                  <input
                    type="range"
                    min={-0.18}
                    max={0.24}
                    step={0.02}
                    value={fpCamDist}
                    onChange={(e) => handleCamDistChange(parseFloat(e.target.value))}
                    className="w-16 accent-amber-500 cursor-pointer"
                  />
                  <span className="text-[10px] text-zinc-400 font-mono-num w-9">
                    {fpCamDist <= -0.04 ? 'Perto' : fpCamDist >= 0.06 ? 'Longe' : 'Médio'}
                  </span>
                </label>

                <label
                  className={`flex items-center gap-1.5 text-xs text-zinc-300 whitespace-nowrap rounded-lg px-1.5 py-0.5 ${
                    uiNavOpen && uiFocusIdx === 6 ? 'ring-1 ring-amber-400 bg-amber-500/15' : ''
                  }`}
                  title="Campo de visão (FOV) da câmera"
                >
                  <span>FOV</span>
                  <input
                    type="range"
                    min={65}
                    max={115}
                    step={1}
                    value={fpFov}
                    onChange={(e) => handleFovChange(parseInt(e.target.value, 10))}
                    className="w-16 accent-amber-500 cursor-pointer"
                  />
                  <span className="text-[10px] text-zinc-400 font-mono-num w-6">{fpFov}°</span>
                </label>

                <button
                  type="button"
                  onClick={handleAutoGearToggle}
                  className={`px-2 py-1 rounded-md bg-zinc-800 hover:bg-zinc-700 text-xs font-medium text-zinc-200 transition-colors whitespace-nowrap shrink-0 ${
                    uiNavOpen && uiFocusIdx === 7 ? 'ring-2 ring-amber-400' : ''
                  }`}
                >
                  {autoGear ? 'Auto' : 'Manual Q/E'}
                </button>

                <button
                  type="button"
                  onClick={() => setShowAnalog((v) => !v)}
                  title="Mostrar / Ocultar Controles na Tela"
                  className={`flex items-center gap-1 px-2 py-1 rounded-md text-xs font-medium transition-colors whitespace-nowrap shrink-0 ${
                    showAnalog
                      ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40'
                      : 'bg-zinc-800 text-zinc-300 hover:bg-zinc-700'
                  } ${uiNavOpen && uiFocusIdx === 8 ? 'ring-2 ring-amber-400' : ''}`}
                >
                  <Gamepad2 className="w-3.5 h-3.5" />
                  <span>Controles</span>
                </button>

                <button
                  type="button"
                  onClick={handleToggleMute}
                  aria-label={muted ? 'Ativar som' : 'Silenciar som'}
                  className={`p-1.5 rounded-md bg-zinc-800 hover:bg-zinc-700 text-zinc-200 transition-colors shrink-0 ${
                    uiNavOpen && uiFocusIdx === 9 ? 'ring-2 ring-amber-400' : ''
                  }`}
                >
                  {muted ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
                </button>

                <button
                  type="button"
                  onClick={(e) => {
                    e.currentTarget.blur();
                    handleToggleDismount();
                  }}
                  title="Sair / Subir na Moto (Enter, U ou Y)"
                  className={`flex items-center gap-1 px-2.5 py-1 rounded-md text-xs font-semibold transition-colors whitespace-nowrap shrink-0 ${
                    telemetry.riderState === 'on_foot'
                      ? 'bg-emerald-500 text-zinc-950 hover:bg-emerald-400'
                      : 'bg-zinc-800 hover:bg-zinc-700 text-amber-300'
                  } ${uiNavOpen && uiFocusIdx === 10 ? 'ring-2 ring-amber-400' : ''}`}
                >
                  {telemetry.riderState === 'on_foot' ? (
                    <>
                      <Bike className="w-3.5 h-3.5" />
                      <span>Subir na Moto</span>
                    </>
                  ) : (
                    <>
                      <Footprints className="w-3.5 h-3.5" />
                      <span>Sair da Moto</span>
                    </>
                  )}
                </button>

                <button
                  type="button"
                  onClick={() => void handleToggleFullscreen()}
                  className={`flex items-center gap-1 px-2 py-1 rounded-md bg-zinc-800 hover:bg-zinc-700 text-xs font-medium text-zinc-200 transition-colors whitespace-nowrap shrink-0 ${
                    uiNavOpen && uiFocusIdx === 11 ? 'ring-2 ring-amber-400' : ''
                  }`}
                >
                  {isFullscreen ? <Minimize2 className="w-3.5 h-3.5" /> : <Maximize2 className="w-3.5 h-3.5" />}
                  <span>{isFullscreen ? 'Janela' : 'Tela Cheia'}</span>
                </button>

                <button
                  type="button"
                  onClick={(e) => {
                    e.currentTarget.blur();
                    handleReset();
                  }}
                  title="Reiniciar na pista (R ou L3)"
                  className={`flex items-center gap-1 px-2 py-1 rounded-md bg-zinc-800 hover:bg-zinc-700 text-xs font-medium text-zinc-200 transition-colors whitespace-nowrap shrink-0 ${
                    uiNavOpen && uiFocusIdx === 12 ? 'ring-2 ring-amber-400' : ''
                  }`}
                >
                  <RotateCcw className="w-3.5 h-3.5" />
                  <span>Reset</span>
                </button>
              </div>
            </div>

            {uiNavOpen ? (
              <div className="flex flex-wrap items-center justify-center gap-x-2.5 gap-y-0.5 text-[11px] text-amber-300 border-t border-white/5 pt-1.5 font-medium">
                <span>▲ / ▼ Navegar</span>
                <span aria-hidden="true">·</span>
                <span>◀ / ▶ Ajustar</span>
                <span aria-hidden="true">·</span>
                <span>A Confirmar</span>
                <span aria-hidden="true">·</span>
                <span>X Som</span>
                <span aria-hidden="true">·</span>
                <span>B / ≡ Fechar</span>
              </div>
            ) : telemetry.riderState === 'on_foot' ? (
              <div className="flex flex-wrap items-center justify-center gap-x-2.5 gap-y-0.5 text-[11px] text-zinc-400 border-t border-white/5 pt-1.5">
                <span>RT / W Andar</span>
                <span aria-hidden="true">·</span>
                <span>LB / Shift Correr</span>
                <span aria-hidden="true">·</span>
                <span>A / Espaço Pular</span>
                <span aria-hidden="true">·</span>
                <span>X / F Salve</span>
                <span aria-hidden="true">·</span>
                <span className="text-emerald-300 font-medium">Y / Enter Subir na Moto</span>
                <span aria-hidden="true">·</span>
                <span>View / V Câmera</span>
              </div>
            ) : (
              <div className="flex flex-wrap items-center justify-center gap-x-2.5 gap-y-0.5 text-[11px] text-zinc-400 border-t border-white/5 pt-1.5">
                <span>RT / W Acelerar</span>
                <span aria-hidden="true">·</span>
                <span className="text-amber-300 font-medium">RB / Analógico Puxar Grau</span>
                <span aria-hidden="true">·</span>
                <span className="text-red-300 font-medium">A / Espaço Freio Pé</span>
                <span aria-hidden="true">·</span>
                <span>LT Freio / RL</span>
                <span aria-hidden="true">·</span>
                <span>X Sem Mão</span>
                <span aria-hidden="true">·</span>
                <span className="text-emerald-300 font-medium">Y / Enter Descer</span>
                <span aria-hidden="true">·</span>
                <span>View / V Câmera</span>
              </div>
            )}
          </div>
        </div>
      )}

      {/* Clean Loading Overlay */}
      {!loadProgress.loaded && (
        <div className="fixed inset-0 z-30 flex items-center justify-center bg-[#0b0d11]/95 px-6">
          <div className="w-full max-w-md p-6 rounded-xl bg-[#12161f] border border-white/10 flex flex-col gap-4">
            <div className="flex flex-col gap-1">
              <h2 className="font-display text-2xl font-bold text-white">Grau Favela</h2>
              <p className="text-sm text-zinc-400">
                Simulador realista em 1ª pessoa com física estilo MX Bikes e molejo.
              </p>
            </div>

            {loadProgress.error ? (
              <div className="p-3 rounded-lg bg-red-950/50 border border-red-500/30 text-sm text-red-200">
                {loadProgress.error}
              </div>
            ) : (
              <div className="flex flex-col gap-2">
                <div className="flex justify-between text-xs text-zinc-300 font-mono-num">
                  <span>{loadProgress.statusText}</span>
                  <span>{loadProgress.percent}%</span>
                </div>
                <div className="h-2 w-full rounded-full bg-zinc-800 overflow-hidden">
                  <div
                    className="h-full bg-amber-500 transition-[width] duration-150"
                    style={{ width: `${loadProgress.percent}%` }}
                  />
                </div>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
