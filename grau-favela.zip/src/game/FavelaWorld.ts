import * as THREE from 'three';
import { GLTFLoader } from 'three/addons/loaders/GLTFLoader.js';
import { ProceduralTextureSet } from './ProceduralTextures';
import {
  LOMBADAS,
  PLAZA_RECT,
  RoadTerrain,
  STREETS,
  STUNT_RAMPS,
  StreetSegment,
} from './RoadTerrain';

interface Particle {
  active: boolean;
  x: number;
  y: number;
  z: number;
  vx: number;
  vy: number;
  vz: number;
  age: number;
  maxAge: number;
  size: number;
  kind: 'smoke' | 'spark';
}

export class FavelaWorld {
  public readonly group = new THREE.Group();
  public readonly sunLight: THREE.DirectionalLight;
  private readonly skyDome: THREE.Mesh;

  private readonly smokeMesh: THREE.InstancedMesh;
  private readonly sparkMesh: THREE.InstancedMesh;
  private readonly particles: Particle[] = [];
  private readonly maxSmoke = 120;
  private readonly maxSparks = 90;
  private readonly dummy = new THREE.Object3D();
  private readonly tmpColor = new THREE.Color();

  private readonly disposables: Array<{ dispose: () => void }> = [];

  constructor(
    scene: THREE.Scene,
    terrain: RoadTerrain,
    textures: ProceduralTextureSet,
    _isSoftwareGl: boolean
  ) {
    // 1. Photorealistic AI-Generated Brazilian Golden-Hour Sky Dome & Fog
    const fogColor = new THREE.Color(0xd9b89c);
    scene.background = fogColor;
    scene.fog = new THREE.FogExp2(0xd9b89c, 0.0014);

    const skyGeo = new THREE.SphereGeometry(360, 40, 28);
    const skyMat = new THREE.ShaderMaterial({
      side: THREE.BackSide,
      depthWrite: false,
      fog: false,
      uniforms: {
        skyMap: { value: textures.skyMap },
        fogColor: { value: new THREE.Color(0xd9b89c) },
        zenithColor: { value: new THREE.Color(0x1b5290) },
        sunDir: { value: new THREE.Vector3(0.6, 0.32, -0.72).normalize() },
      },
      vertexShader: `
        varying vec3 vLocalDir;
        void main() {
          vLocalDir = position;
          gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
        }
      `,
      fragmentShader: `
        uniform sampler2D skyMap;
        uniform vec3 fogColor;
        uniform vec3 zenithColor;
        uniform vec3 sunDir;
        varying vec3 vLocalDir;
        void main() {
          vec3 dir = normalize(vLocalDir);
          float sunAz = atan(sunDir.z, sunDir.x);
          float az = atan(dir.z, dir.x) - sunAz;
          // Mirrored horizontal wrap keeps 360-degree panorama 100% seamless
          float u = (az / 3.14159265) + 0.59;
          float h = clamp(dir.y, 0.0, 1.0);
          float v = clamp(0.14 + pow(h, 0.72) * 0.84, 0.02, 0.98);
          vec3 sky = texture2D(skyMap, vec2(u, v)).rgb;
          // Smooth zenith & horizon fog integration
          sky = mix(sky, zenithColor, smoothstep(0.74, 1.0, h) * 0.45);
          sky = mix(fogColor, sky, smoothstep(-0.02, 0.14, dir.y));
          float sunDot = max(dot(dir, sunDir), 0.0);
          sky += vec3(1.0, 0.88, 0.72) * pow(sunDot, 22.0) * 0.28;
          sky += vec3(1.0, 0.96, 0.86) * smoothstep(0.9965, 0.9996, sunDot) * 0.95;
          gl_FragColor = vec4(sky, 1.0);
        }
      `,
    });
    this.skyDome = new THREE.Mesh(skyGeo, skyMat);
    this.skyDome.renderOrder = -100;
    this.skyDome.frustumCulled = false;
    this.group.add(this.skyDome);
    this.disposables.push(skyGeo, skyMat);

    // 2. Fast Shadow-Free Warm/Cool Outdoor Lighting
    const hemiLight = new THREE.HemisphereLight(0x9bc4e8, 0x6b4f3a, 0.92);
    this.group.add(hemiLight);

    this.sunLight = new THREE.DirectionalLight(0xfff0d6, 2.2);
    this.sunLight.position.set(80, 95, -90);
    this.sunLight.castShadow = false;
    this.group.add(this.sunLight);

    // 3. Open-World Terrain Mesh + Street Network + Plaza / Quadra + Ramps
    this.buildTerrain(terrain, textures);
    this.buildStreets(terrain, textures);
    this.buildPlazaAndRamps(textures);

    // 4. Open-World Street Props (Houses loaded asynchronously from /models/casa_br.glb)
    this.buildStreetProps(terrain, textures);

    // 5. Instanced Smoke & Spark Particles
    const smokeGeo = new THREE.PlaneGeometry(1, 1);
    const smokeMat = new THREE.MeshBasicMaterial({
      map: textures.particleGlow,
      transparent: true,
      depthWrite: false,
      opacity: 0.45,
      color: 0xd9dce0,
    });
    this.smokeMesh = new THREE.InstancedMesh(smokeGeo, smokeMat, this.maxSmoke);
    this.smokeMesh.frustumCulled = false;
    this.smokeMesh.instanceMatrix.setUsage(THREE.DynamicDrawUsage);
    this.group.add(this.smokeMesh);
    this.disposables.push(smokeGeo, smokeMat);

    const sparkGeo = new THREE.BoxGeometry(0.03, 0.03, 0.24);
    const sparkMat = new THREE.MeshBasicMaterial({ color: 0xffb347 });
    this.sparkMesh = new THREE.InstancedMesh(sparkGeo, sparkMat, this.maxSparks);
    this.sparkMesh.frustumCulled = false;
    this.sparkMesh.instanceMatrix.setUsage(THREE.DynamicDrawUsage);
    this.group.add(this.sparkMesh);
    this.disposables.push(sparkGeo, sparkMat);

    for (let i = 0; i < this.maxSmoke; i++) {
      this.particles.push({
        active: false,
        x: 0,
        y: -999,
        z: 0,
        vx: 0,
        vy: 0,
        vz: 0,
        age: 0,
        maxAge: 1,
        size: 0.5,
        kind: 'smoke',
      });
    }
    for (let i = 0; i < this.maxSparks; i++) {
      this.particles.push({
        active: false,
        x: 0,
        y: -999,
        z: 0,
        vx: 0,
        vy: 0,
        vz: 0,
        age: 0,
        maxAge: 0.4,
        size: 1,
        kind: 'spark',
      });
    }

    scene.add(this.group);
  }

  private buildTerrain(terrain: RoadTerrain, textures: ProceduralTextureSet): void {
    const size = 1500;
    const segs = 136;
    const geo = new THREE.PlaneGeometry(size, size, segs, segs);
    geo.rotateX(-Math.PI / 2);

    const pos = geo.attributes.position as THREE.BufferAttribute;
    const uvAttr = geo.attributes.uv as THREE.BufferAttribute;
    const colors = new Float32Array(pos.count * 3);
    for (let i = 0; i < pos.count; i++) {
      const x = pos.getX(i);
      const z = pos.getZ(i);
      const y = terrain.baseTerrainHeight(x, z) - 0.08;
      pos.setY(i, y);
      uvAttr.setXY(i, x / 16, z / 16);

      const inBlock = terrain.isPointInBlock(x, z, 0);
      if (inBlock) {
        // Earthy / urban hillside soil & grass mix
        const patch = (Math.sin(x * 0.05) * Math.cos(z * 0.05) + 1) * 0.5;
        colors[i * 3] = 0.27 + patch * 0.09;
        colors[i * 3 + 1] = 0.36 + patch * 0.09;
        colors[i * 3 + 2] = 0.21 + patch * 0.04;
      } else {
        colors[i * 3] = 0.30;
        colors[i * 3 + 1] = 0.29;
        colors[i * 3 + 2] = 0.26;
      }
    }
    geo.setAttribute('color', new THREE.BufferAttribute(colors, 3));
    geo.computeVertexNormals();

    const mat = new THREE.MeshStandardMaterial({
      vertexColors: true,
      bumpMap: textures.concreteMap,
      bumpScale: 0.045,
      roughness: 0.94,
      metalness: 0.0,
    });
    const mesh = new THREE.Mesh(geo, mat);
    this.group.add(mesh);
    this.disposables.push(geo, mat);
  }

  private buildStreetRibbon(
    seg: StreetSegment,
    terrain: RoadTerrain,
    asphaltMat: THREE.Material,
    walkMat: THREE.Material
  ): void {
    const len = Math.hypot(seg.bx - seg.ax, seg.bz - seg.az);
    const steps = Math.max(12, Math.round(len / 4));
    const dx = (seg.bx - seg.ax) / len;
    const dz = (seg.bz - seg.az) / len;
    const rx = -dz;
    const rz = dx;

    const verts: number[] = [];
    const uvs: number[] = [];
    const indices: number[] = [];

    const walkVerts: number[] = [];
    const walkUVs: number[] = [];
    const walkIndices: number[] = [];

    const hw = seg.halfWidth;
    const sw = hw + 1.85;

    for (let i = 0; i <= steps; i++) {
      const t = i / steps;
      const cx = seg.ax + (seg.bx - seg.ax) * t;
      const cz = seg.az + (seg.bz - seg.az) * t;

      const lx = cx - rx * hw;
      const lz = cz - rz * hw;
      const rxp = cx + rx * hw;
      const rzp = cz + rz * hw;

      // Sample terrain at left, center, right so road conforms smoothly to hillside
      const yL = terrain.baseTerrainHeight(lx, lz) + 0.03;
      const yR = terrain.baseTerrainHeight(rxp, rzp) + 0.03;

      verts.push(lx, yL, lz, rxp, yR, rzp);
      uvs.push(0, (t * len) / 12, 1, (t * len) / 12);

      // Left & Right Concrete Sidewalks
      const lOutX = cx - rx * sw;
      const lOutZ = cz - rz * sw;
      const rOutX = cx + rx * sw;
      const rOutZ = cz + rz * sw;
      const yLOut = terrain.baseTerrainHeight(lOutX, lOutZ) + 0.13;
      const yROut = terrain.baseTerrainHeight(rOutX, rOutZ) + 0.13;

      walkVerts.push(
        lx, yL + 0.1, lz,
        lOutX, yLOut, lOutZ,
        rxp, yR + 0.1, rzp,
        rOutX, yROut, rOutZ
      );
      const vW = (t * len) / 4;
      walkUVs.push(0, vW, 1, vW, 0, vW, 1, vW);

      if (i < steps) {
        const b = i * 2;
        indices.push(b, b + 1, b + 2, b + 1, b + 3, b + 2);
        const w = i * 4;
        walkIndices.push(w, w + 1, w + 4, w + 1, w + 5, w + 4);
        walkIndices.push(w + 3, w + 2, w + 7, w + 2, w + 6, w + 7);
      }
    }

    const rGeo = new THREE.BufferGeometry();
    rGeo.setAttribute('position', new THREE.Float32BufferAttribute(verts, 3));
    rGeo.setAttribute('uv', new THREE.Float32BufferAttribute(uvs, 2));
    rGeo.setIndex(indices);
    rGeo.computeVertexNormals();
    const rMesh = new THREE.Mesh(rGeo, asphaltMat);
    this.group.add(rMesh);
    this.disposables.push(rGeo);

    const wGeo = new THREE.BufferGeometry();
    wGeo.setAttribute('position', new THREE.Float32BufferAttribute(walkVerts, 3));
    wGeo.setAttribute('uv', new THREE.Float32BufferAttribute(walkUVs, 2));
    wGeo.setIndex(walkIndices);
    wGeo.computeVertexNormals();
    const wMesh = new THREE.Mesh(wGeo, walkMat);
    this.group.add(wMesh);
    this.disposables.push(wGeo);
  }

  private buildStreets(terrain: RoadTerrain, textures: ProceduralTextureSet): void {
    const asphaltMat = new THREE.MeshStandardMaterial({
      map: textures.asphaltMap,
      roughnessMap: textures.asphaltRoughness,
      bumpMap: textures.asphaltRoughness,
      bumpScale: 0.022,
      roughness: 0.90,
      metalness: 0.04,
      polygonOffset: true,
      polygonOffsetFactor: -1,
      polygonOffsetUnits: -1,
    });
    const walkMat = new THREE.MeshStandardMaterial({
      map: textures.concreteMap,
      bumpMap: textures.concreteMap,
      bumpScale: 0.022,
      color: 0xc2bcb2,
      roughness: 0.90,
      metalness: 0.02,
    });

    for (const seg of STREETS) {
      this.buildStreetRibbon(seg, terrain, asphaltMat, walkMat);
    }
    this.disposables.push(asphaltMat, walkMat);

    // Yellow Lombada Speed Bump Meshes
    const bumpMat = new THREE.MeshStandardMaterial({
      color: 0xeab308,
      roughness: 0.72,
    });
    const bumpGeo = new THREE.CylinderGeometry(0.14, 0.14, 1, 10, 1, false, 0, Math.PI);
    bumpGeo.rotateZ(Math.PI / 2);
    bumpGeo.scale(1, 1, 8.5);

    for (const l of LOMBADAS) {
      const m = new THREE.Mesh(bumpGeo, bumpMat);
      const baseH = terrain.baseTerrainHeight(l.x, l.z);
      m.position.set(l.x, baseH + 0.03, l.z);
      const yaw = Math.atan2(-l.nz, l.nx);
      m.rotation.y = yaw + Math.PI / 2;
      m.scale.set(l.halfWidth * 1.9, 1, 1);
      this.group.add(m);
    }
    this.disposables.push(bumpGeo, bumpMat);
  }

  private buildPlazaAndRamps(textures: ProceduralTextureSet): void {
    const w = PLAZA_RECT.maxX - PLAZA_RECT.minX;
    const d = PLAZA_RECT.maxZ - PLAZA_RECT.minZ;
    const cx = (PLAZA_RECT.minX + PLAZA_RECT.maxX) * 0.5;
    const cz = (PLAZA_RECT.minZ + PLAZA_RECT.maxZ) * 0.5;

    // Concrete Plaza Deck with crisp tiled UVs
    const plazaGeo = new THREE.PlaneGeometry(w, d);
    plazaGeo.rotateX(-Math.PI / 2);
    const pUv = plazaGeo.attributes.uv as THREE.BufferAttribute;
    for (let i = 0; i < pUv.count; i++) {
      pUv.setXY(i, pUv.getX(i) * (w / 7), pUv.getY(i) * (d / 7));
    }
    const plazaMat = new THREE.MeshStandardMaterial({
      map: textures.concreteMap,
      bumpMap: textures.concreteMap,
      bumpScale: 0.02,
      color: 0xb0aba2,
      roughness: 0.88,
    });
    const plaza = new THREE.Mesh(plazaGeo, plazaMat);
    plaza.position.set(cx, 0.05, cz);
    this.group.add(plaza);
    this.disposables.push(plazaGeo, plazaMat);

    // Painted Favela Futsal Court ("Quadra") inside the plaza
    const courtGeo = new THREE.PlaneGeometry(34, 20);
    courtGeo.rotateX(-Math.PI / 2);
    const courtMat = new THREE.MeshStandardMaterial({
      color: 0x1f6b58,
      roughness: 0.85,
      polygonOffset: true,
      polygonOffsetFactor: -1,
      polygonOffsetUnits: -1,
    });
    const court = new THREE.Mesh(courtGeo, courtMat);
    court.position.set(cx - 10, 0.07, cz - 8);
    this.group.add(court);
    this.disposables.push(courtGeo, courtMat);

    // White Court Boundary Lines
    const lineMat = new THREE.MeshBasicMaterial({ color: 0xf4f4f0 });
    const outerLineGeo = new THREE.RingGeometry(9.8, 10.1, 4);
    const midLineGeo = new THREE.PlaneGeometry(0.25, 19.6);
    midLineGeo.rotateX(-Math.PI / 2);
    const midLine = new THREE.Mesh(midLineGeo, lineMat);
    midLine.position.set(cx - 10, 0.085, cz - 8);
    this.group.add(midLine);
    this.disposables.push(outerLineGeo, midLineGeo, lineMat);

    // Stunt Launch Ramps
    const rampMat = new THREE.MeshStandardMaterial({
      color: 0xd97706,
      roughness: 0.75,
      metalness: 0.2,
    });
    for (const r of STUNT_RAMPS) {
      const shape = new THREE.Shape();
      shape.moveTo(-r.length * 0.5, 0);
      shape.lineTo(r.length * 0.5, 0);
      shape.lineTo(r.length * 0.5, r.height);
      shape.closePath();

      const extrude = new THREE.ExtrudeGeometry(shape, {
        depth: r.halfWidth * 2,
        bevelEnabled: false,
      });
      extrude.translate(0, 0, -r.halfWidth);

      const mesh = new THREE.Mesh(extrude, rampMat);
      mesh.position.set(r.x, 0.02, r.z);
      mesh.rotation.y = r.yaw;
      this.group.add(mesh);
      this.disposables.push(extrude);
    }
    this.disposables.push(rampMat);
  }

  public async loadHouses(terrain: RoadTerrain, textures: ProceduralTextureSet): Promise<void> {
    const loader = new GLTFLoader();
    const gltf = await new Promise<any>((resolve, reject) => {
      loader.load('/models/casa_br.glb', resolve, undefined, reject);
    });

    gltf.scene.updateMatrixWorld(true);

    let seed = 42069;
    const rand = () => {
      seed = (seed * 1664525 + 1013904223) >>> 0;
      return seed / 4294967296;
    };

    const colorPairs: Array<[number, number, number]> = [
      [0xe08d67, 0xf4e3cf, 0xd4d4d8], // Terracota + Creme
      [0xeec45f, 0xf5f2ea, 0xcbd5e1], // Amarelo Ocre + Branco
      [0x7fb8d9, 0xeaf2f7, 0xd6d3d1], // Azul Céu + Branco
      [0x8ac9a8, 0xedf3ea, 0xe4e4e7], // Verde Água + Creme
      [0xe5988b, 0xf2e4dc, 0xd4d4d8], // Salmão + Bege
      [0xd67e49, 0xdad6cf, 0xcbd5e1], // Laranja Queimado + Cinza
      [0xc2a8db, 0xf1edf5, 0xe2e8f0], // Lilás Suave + Branco
      [0xd8c3a5, 0xe2b16b, 0xd6d3d1], // Areia + Ocre
    ];

    interface HouseSpec {
      x: number;
      y: number;
      z: number;
      yaw: number;
      sx: number;
      sy: number;
      sz: number;
      wallColor: number;
      facadeColor: number;
      gateColor: number;
    }

    const houses: HouseSpec[] = [];

    // Populate expanded open-world city blocks cleanly with houses facing their nearest street
    for (let gx = -425; gx <= 425; gx += 18) {
      for (let gz = -315; gz <= 235; gz += 18) {
        const hx = gx + (rand() - 0.5) * 4.6;
        const hz = gz + (rand() - 0.5) * 4.6;
        if (!terrain.isPointInBlock(hx, hz, 6.2)) continue;
        if (rand() < 0.14) continue;

        // Find nearest street segment to orient front facade (+X) toward the street
        let bestDist = Infinity;
        let streetX = hx;
        let streetZ = hz;
        for (let i = 0; i < STREETS.length; i++) {
          const s = STREETS[i];
          const abx = s.bx - s.ax;
          const abz = s.bz - s.az;
          const len2 = abx * abx + abz * abz || 1;
          const t = THREE.MathUtils.clamp(((hx - s.ax) * abx + (hz - s.az) * abz) / len2, 0, 1);
          const px = s.ax + abx * t;
          const pz = s.az + abz * t;
          const d = Math.hypot(px - hx, pz - hz);
          if (d < bestDist) {
            bestDist = d;
            streetX = px;
            streetZ = pz;
          }
        }

        const yaw = Math.atan2(-(streetZ - hz), streetX - hx) + (rand() - 0.5) * 0.08;
        const palette = colorPairs[Math.floor(rand() * colorPairs.length)];
        const baseScale = 0.84 + rand() * 0.24;
        const heightScale = baseScale * (0.88 + rand() * 0.34);

        // Sample terrain across front/back of house footprint so it never sinks on flat streets or floats on hills
        const fwdX = Math.cos(yaw) * 3.5 * baseScale;
        const fwdZ = -Math.sin(yaw) * 3.5 * baseScale;
        const hCenter = terrain.baseTerrainHeight(hx, hz);
        const hFront = terrain.baseTerrainHeight(hx + fwdX, hz + fwdZ);
        const hBack = terrain.baseTerrainHeight(hx - fwdX, hz - fwdZ);
        const groundY = Math.min(hCenter, hFront, hBack) - 0.12;

        houses.push({
          x: hx,
          y: groundY,
          z: hz,
          yaw,
          sx: baseScale,
          sy: heightScale,
          sz: baseScale,
          wallColor: palette[0],
          facadeColor: palette[1],
          gateColor: palette[2],
        });
      }
    }

    if (houses.length === 0) return;

    // Shift raw GLB bounds (min [-4.65, 0.13, -10.51], max [3.24, 7.67, 1.50]) so base sits at y=0 centered in XZ
    const centerShift = new THREE.Matrix4().makeTranslation(0.7, -0.13, 4.5);
    const bakeMat = new THREE.Matrix4();

    const sourceMeshes: THREE.Mesh[] = [];
    gltf.scene.traverse((obj: any) => {
      if (obj.isMesh) sourceMeshes.push(obj);
    });

    for (const src of sourceMeshes) {
      const geo = src.geometry.clone();
      bakeMat.multiplyMatrices(centerShift, src.matrixWorld);
      geo.applyMatrix4(bakeMat);

      const srcMat = (Array.isArray(src.material) ? src.material[0] : src.material) as THREE.MeshStandardMaterial;
      const mat = srcMat.clone();
      mat.color.setHex(0xffffff);
      mat.transparent = false;
      mat.depthWrite = true;
      mat.envMapIntensity = 0.85;

      const matName = (srcMat.name || '').toLowerCase();
      const meshName = (src.name || '').toLowerCase();
      const isWalls = matName.includes('parede_casa');
      const isFacade = matName.includes('parede_fachada');
      const isGate = matName.includes('portao_casa');
      const isRoof =
        matName.includes('telha') ||
        matName.includes('teto') ||
        matName.includes('roof') ||
        meshName.includes('telha') ||
        meshName.includes('roof');

      // Scale UVs cleanly so AI brick/concrete/roof textures tile at authentic architectural scale
      const uvAttr = geo.attributes.uv as THREE.BufferAttribute | undefined;
      if (uvAttr && (isWalls || isFacade || isRoof)) {
        const tileFactor = isRoof ? 2.8 : 2.2;
        for (let i = 0; i < uvAttr.count; i++) {
          uvAttr.setXY(i, uvAttr.getX(i) * tileFactor, uvAttr.getY(i) * tileFactor);
        }
      }

      if (isWalls) {
        mat.map = textures.brickMap;
        mat.bumpMap = textures.brickMap;
        mat.bumpScale = 0.038;
        mat.roughness = 0.88;
      } else if (isFacade) {
        mat.map = textures.concreteMap;
        mat.bumpMap = textures.concreteMap;
        mat.bumpScale = 0.025;
        mat.roughness = 0.86;
      } else if (isRoof) {
        mat.map = textures.roofMap;
        mat.bumpMap = textures.roofMap;
        mat.bumpScale = 0.04;
        mat.roughness = 0.72;
        mat.metalness = 0.25;
      } else if (isGate) {
        mat.metalness = 0.58;
        mat.roughness = 0.42;
        mat.envMapIntensity = 1.25;
      }

      const inst = new THREE.InstancedMesh(geo, mat, houses.length);
      inst.castShadow = false;
      inst.receiveShadow = false;

      for (let i = 0; i < houses.length; i++) {
        const h = houses[i];
        this.dummy.position.set(h.x, h.y, h.z);
        this.dummy.rotation.set(0, h.yaw, 0);
        this.dummy.scale.set(h.sx, h.sy, h.sz);
        this.dummy.updateMatrix();
        inst.setMatrixAt(i, this.dummy.matrix);

        if (isWalls) {
          // Keep brick texture warm and authentic with subtle plaster/terracotta tone shift
          this.tmpColor.setHex(h.wallColor).lerp(new THREE.Color(0xf6efe8), 0.72);
          inst.setColorAt(i, this.tmpColor);
        } else if (isFacade) {
          inst.setColorAt(i, this.tmpColor.setHex(h.facadeColor));
        } else if (isGate) {
          inst.setColorAt(i, this.tmpColor.setHex(h.gateColor));
        } else {
          inst.setColorAt(i, this.tmpColor.setHex(0xe4e4e7));
        }
      }

      if (inst.instanceColor) inst.instanceColor.needsUpdate = true;
      inst.computeBoundingSphere();
      this.group.add(inst);
      this.disposables.push(geo, mat);
    }
  }

  private buildStreetProps(terrain: RoadTerrain, textures: ProceduralTextureSet): void {
    // Utility poles along major avenues
    const poleCoords: Array<[number, number, number]> = [];
    for (const seg of STREETS) {
      if (seg.isAlley) continue;
      const len = Math.hypot(seg.bx - seg.ax, seg.bz - seg.az);
      const dx = (seg.bx - seg.ax) / len;
      const dz = (seg.bz - seg.az) / len;
      const rx = -dz;
      const rz = dx;
      for (let d = 24; d < len - 18; d += 36) {
        const px = seg.ax + dx * d + rx * (seg.halfWidth + 0.65);
        const pz = seg.az + dz * d + rz * (seg.halfWidth + 0.65);
        if (terrain.isPointInBlock(px, pz, -0.5)) {
          poleCoords.push([px, terrain.baseTerrainHeight(px, pz) + 0.1, pz]);
        }
      }
    }

    const poleGeo = new THREE.CylinderGeometry(0.11, 0.14, 7.0, 6);
    const poleMat = new THREE.MeshStandardMaterial({ color: 0x7a7670, roughness: 0.9 });
    const poleMesh = new THREE.InstancedMesh(poleGeo, poleMat, Math.max(1, poleCoords.length));
    poleCoords.forEach(([x, y, z], i) => {
      this.dummy.position.set(x, y + 3.5, z);
      this.dummy.rotation.set(0, 0, 0);
      this.dummy.scale.set(1, 1, 1);
      this.dummy.updateMatrix();
      poleMesh.setMatrixAt(i, this.dummy.matrix);
    });
    poleMesh.computeBoundingSphere();
    this.group.add(poleMesh);
    this.disposables.push(poleGeo, poleMat);

    // Lombada Warning Signs
    const signPostGeo = new THREE.CylinderGeometry(0.035, 0.035, 2.3, 6);
    const signPlateGeo = new THREE.BoxGeometry(0.65, 0.65, 0.04);
    const signPostMat = new THREE.MeshStandardMaterial({ color: 0x55595e, metalness: 0.6, roughness: 0.4 });
    const signPlateMat = new THREE.MeshStandardMaterial({ map: textures.signLombadaMap, roughness: 0.4 });

    for (const l of LOMBADAS) {
      const sx = l.x - l.nx * 10 - l.nz * (l.halfWidth + 0.6);
      const sz = l.z - l.nz * 10 + l.nx * (l.halfWidth + 0.6);
      const sy = terrain.baseTerrainHeight(sx, sz) + 0.1;

      const post = new THREE.Mesh(signPostGeo, signPostMat);
      post.position.set(sx, sy + 1.15, sz);
      const plate = new THREE.Mesh(signPlateGeo, signPlateMat);
      plate.position.set(sx, sy + 2.25, sz);
      plate.rotation.y = Math.atan2(-l.nx, -l.nz);
      plate.rotation.z = Math.PI / 4;
      this.group.add(post, plate);
    }
    this.disposables.push(signPostGeo, signPlateGeo, signPostMat, signPlateMat);

    // Tropical Hillside Trees on outer perimeter slopes
    const treeCount = 125;
    const trunkGeo = new THREE.CylinderGeometry(0.16, 0.28, 4.2, 6);
    const trunkMat = new THREE.MeshStandardMaterial({ color: 0x5c4633, roughness: 0.92 });
    const crownGeo = new THREE.DodecahedronGeometry(1.85, 0);
    const crownMat = new THREE.MeshStandardMaterial({ color: 0x2d5e2b, roughness: 0.85 });

    const trunkMesh = new THREE.InstancedMesh(trunkGeo, trunkMat, treeCount);
    const crownMesh = new THREE.InstancedMesh(crownGeo, crownMat, treeCount);

    let seed = 9182;
    const rand = () => {
      seed = (seed * 1664525 + 1013904223) >>> 0;
      return seed / 4294967296;
    };

    for (let t = 0; t < treeCount; t++) {
      const ang = (t / treeCount) * Math.PI * 2;
      const rad = 455 + rand() * 110;
      const tx = Math.cos(ang) * rad;
      const tz = Math.sin(ang) * rad * 0.72 - 45;
      const ty = terrain.baseTerrainHeight(tx, tz);
      const scale = 0.85 + rand() * 0.7;

      this.dummy.position.set(tx, ty + 2.0 * scale, tz);
      this.dummy.rotation.set(0, rand() * Math.PI * 2, 0);
      this.dummy.scale.set(scale, scale, scale);
      this.dummy.updateMatrix();
      trunkMesh.setMatrixAt(t, this.dummy.matrix);

      this.dummy.position.set(tx, ty + 4.3 * scale, tz);
      this.dummy.scale.set(scale * 1.1, scale * 0.85, scale * 1.1);
      this.dummy.updateMatrix();
      crownMesh.setMatrixAt(t, this.dummy.matrix);
      crownMesh.setColorAt(
        t,
        this.tmpColor.setHSL(0.28 + (rand() - 0.5) * 0.06, 0.45, 0.24 + rand() * 0.1)
      );
    }
    if (crownMesh.instanceColor) crownMesh.instanceColor.needsUpdate = true;
    trunkMesh.computeBoundingSphere();
    crownMesh.computeBoundingSphere();
    this.group.add(trunkMesh, crownMesh);
    this.disposables.push(trunkGeo, trunkMat, crownGeo, crownMat);
  }

  public spawnSmoke(x: number, y: number, z: number, vx: number, vy: number, vz: number): void {
    for (let i = 0; i < this.maxSmoke; i++) {
      const p = this.particles[i];
      if (!p.active) {
        p.active = true;
        p.kind = 'smoke';
        p.x = x + (Math.random() - 0.5) * 0.14;
        p.y = y + 0.08;
        p.z = z + (Math.random() - 0.5) * 0.14;
        p.vx = vx + (Math.random() - 0.5) * 1.2;
        p.vy = vy + 0.6 + Math.random() * 0.9;
        p.vz = vz + (Math.random() - 0.5) * 1.2;
        p.age = 0;
        p.maxAge = 0.65 + Math.random() * 0.45;
        p.size = 0.38 + Math.random() * 0.25;
        return;
      }
    }
  }

  public spawnSparks(x: number, y: number, z: number, vx: number, vz: number, count = 4): void {
    let spawned = 0;
    for (let i = this.maxSmoke; i < this.particles.length && spawned < count; i++) {
      const p = this.particles[i];
      if (!p.active) {
        p.active = true;
        p.kind = 'spark';
        p.x = x;
        p.y = y + 0.04;
        p.z = z;
        p.vx = vx * 0.45 + (Math.random() - 0.5) * 4.5;
        p.vy = 1.6 + Math.random() * 3.4;
        p.vz = vz * 0.45 + (Math.random() - 0.5) * 4.5;
        p.age = 0;
        p.maxAge = 0.2 + Math.random() * 0.22;
        p.size = 0.8 + Math.random() * 0.6;
        spawned++;
      }
    }
  }

  public updateParticles(dt: number, cameraPos: THREE.Vector3, playerPos: THREE.Vector3): void {
    this.skyDome.position.copy(cameraPos);
    let sIdx = 0;
    let kIdx = 0;

    for (let i = 0; i < this.particles.length; i++) {
      const p = this.particles[i];
      if (p.active) {
        p.age += dt;
        if (p.age >= p.maxAge) {
          p.active = false;
        } else {
          p.x += p.vx * dt;
          p.y += p.vy * dt;
          p.z += p.vz * dt;
          if (p.kind === 'smoke') {
            p.vx *= 0.96;
            p.vz *= 0.96;
            p.vy += 0.4 * dt;
          } else {
            p.vy -= 14 * dt;
            if (p.y < playerPos.y - 0.5) p.vy = Math.abs(p.vy) * 0.35;
          }
        }
      }

      if (p.kind === 'smoke') {
        if (p.active) {
          const t = p.age / p.maxAge;
          const sc = p.size * (1 + t * 2.4) * (1 - t * 0.35);
          this.dummy.position.set(p.x, p.y, p.z);
          this.dummy.lookAt(cameraPos);
          this.dummy.scale.set(sc, sc, sc);
        } else {
          this.dummy.position.set(0, -999, 0);
          this.dummy.scale.set(0, 0, 0);
        }
        this.dummy.updateMatrix();
        this.smokeMesh.setMatrixAt(sIdx++, this.dummy.matrix);
      } else {
        if (p.active) {
          const t = p.age / p.maxAge;
          const sc = p.size * (1 - t);
          this.dummy.position.set(p.x, p.y, p.z);
          this.dummy.lookAt(p.x + p.vx, p.y + p.vy, p.z + p.vz);
          this.dummy.scale.set(sc, sc, sc);
        } else {
          this.dummy.position.set(0, -999, 0);
          this.dummy.scale.set(0, 0, 0);
        }
        this.dummy.updateMatrix();
        this.sparkMesh.setMatrixAt(kIdx++, this.dummy.matrix);
      }
    }

    this.smokeMesh.instanceMatrix.needsUpdate = true;
    this.sparkMesh.instanceMatrix.needsUpdate = true;
  }

  public dispose(): void {
    for (const d of this.disposables) {
      d.dispose();
    }
  }
}
