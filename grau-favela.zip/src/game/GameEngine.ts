import * as THREE from 'three';
import { OrbitControls } from 'three/addons/controls/OrbitControls.js';
import { RoomEnvironment } from 'three/addons/environments/RoomEnvironment.js';
import { AudioEngine } from './AudioEngine';
import { BikePhysics } from './BikePhysics';
import { BikeRig } from './BikeRig';
import { FavelaWorld } from './FavelaWorld';
import { createProceduralTextures, ProceduralTextureSet } from './ProceduralTextures';
import { GroundHit, RoadTerrain, WORLD_HALF_EXTENT } from './RoadTerrain';
import {
  CameraMode,
  ControlInputs,
  EmoteId,
  GloveStyle,
  GraphicsQuality,
  LoadProgress,
  PhysicsPreset,
  RiderState,
  TelemetryState,
} from './types';

function dampAngle(current: number, target: number, lambda: number, dt: number): number {
  const diff = Math.atan2(Math.sin(target - current), Math.cos(target - current));
  return current + diff * (1 - Math.exp(-lambda * dt));
}

function detectSoftwareGl(): boolean {
  try {
    const canvas = document.createElement('canvas');
    const gl = canvas.getContext('webgl2');
    if (!gl) return true;
    const ext = gl.getExtension('WEBGL_debug_renderer_info');
    const param = ext ? ext.UNMASKED_RENDERER_WEBGL : gl.RENDERER;
    const gpu = String(gl.getParameter(param));
    gl.getExtension('WEBGL_lose_context')?.loseContext();
    return /SwiftShader|llvmpipe|softpipe|Software|Basic Render/i.test(gpu);
  } catch {
    return true;
  }
}

export class GameEngine {
  private readonly renderer: THREE.WebGLRenderer;
  private readonly scene: THREE.Scene;
  private readonly camera: THREE.PerspectiveCamera;
  private readonly orbitControls: OrbitControls;
  private readonly isSoftwareGl: boolean;

  private readonly terrain: RoadTerrain;
  private readonly textures: ProceduralTextureSet;
  private readonly world: FavelaWorld;
  private readonly rig: BikeRig;
  private readonly physics: BikePhysics;
  public readonly audio = new AudioEngine();

  public cameraMode: CameraMode = 'first_person';
  public graphicsQuality: GraphicsQuality = 'high';
  public molejoMultiplier = 1.0;
  public fpFov = 78;

  private readonly keys = new Set<string>();
  private readonly virtualInputs: Partial<ControlInputs> = {};
  private readonly inputs: ControlInputs = {
    throttle: 0,
    frontBrake: 0,
    rearBrake: 0,
    steer: 0,
    riderPitch: 0,
    molejo: 0,
    clutch: false,
    noHand: false,
    burnout: false,
  };

  private frameId = 0;
  private disposed = false;
  private lastTime = performance.now();
  private hudTimer = 0;

  // Camera smoothing state & scratch vectors (zero per-frame GC)
  private readonly camPos = new THREE.Vector3();
  private readonly camLook = new THREE.Vector3();
  private camYaw = 0;
  private readonly _v1 = new THREE.Vector3();
  private readonly _v2 = new THREE.Vector3();
  private readonly _v3 = new THREE.Vector3();
  private readonly _q1 = new THREE.Quaternion();
  private readonly _m1 = new THREE.Matrix4();
  private readonly _up = new THREE.Vector3(0, 1, 0);

  // First-person helmet look offset & MX Bikes neck suspension inertia
  private fpCamYaw = 0;
  private fpLookYaw = 0;
  private fpLookPitch = 0;
  private fpHeadPitchLag = 0;
  private fpHeadBackLag = 0;
  private fpHeadDropLag = 0;
  private camEffectTime = 0;
  private smoothThrottleEffect = 0;
  private smoothAccelG = 0;
  private prevSpeedMs = 0;
  private pointerLocked = false;
  private virtualCamLookX = 0;
  private virtualCamLookY = 0;
  private chaseLookYawOffset = 0;
  private chaseLookPitchOffset = 0;
  private prevVirtualJump = false;

  // Dismount / On-Foot state
  public riderState: RiderState = 'mounted';
  private transitionT = 0;
  private readonly onFootPos = new THREE.Vector3();
  private readonly onFootVel = new THREE.Vector3();
  private onFootYaw = 0;
  private onFootVertVel = 0;
  private onFootAirborne = false;
  private walkPhase = 0;
  private dismountHint = '';
  private dismountHintTimer = 0;
  private timedEmote: EmoteId = 'none';
  private timedEmoteTimer = 0;
  private readonly footHit: GroundHit = {
    height: 0,
    nx: 0,
    ny: 1,
    nz: 0,
    surface: 'asphalt',
  };

  constructor(
    private readonly container: HTMLElement,
    private readonly onLoadProgress: (p: LoadProgress) => void,
    private readonly onTelemetry: (t: TelemetryState) => void
  ) {
    this.isSoftwareGl = detectSoftwareGl();

    this.renderer = new THREE.WebGLRenderer({
      antialias: !this.isSoftwareGl,
      powerPreference: 'high-performance',
      stencil: false,
    });
    this.renderer.outputColorSpace = THREE.SRGBColorSpace;
    this.renderer.toneMapping = THREE.ACESFilmicToneMapping;
    this.renderer.toneMappingExposure = 1.08;
    this.renderer.setPixelRatio(this.isSoftwareGl ? 1 : Math.min(window.devicePixelRatio, 1.5));
    this.renderer.shadowMap.enabled = false;
    this.renderer.setSize(container.clientWidth, container.clientHeight);
    this.renderer.domElement.style.display = 'block';
    this.renderer.domElement.style.width = '100%';
    this.renderer.domElement.style.height = '100%';
    container.appendChild(this.renderer.domElement);

    this.scene = new THREE.Scene();

    // Crisp neutral studio + outdoor specular reflections (keeps Ducati factory paint & chrome clean)
    const pmrem = new THREE.PMREMGenerator(this.renderer);
    const envScene = new RoomEnvironment();
    this.scene.environment = pmrem.fromScene(envScene, 0.035).texture;
    envScene.dispose();
    pmrem.dispose();

    const aspect = container.clientWidth / Math.max(1, container.clientHeight);
    this.camera = new THREE.PerspectiveCamera(78, aspect, 0.05, 1450);

    this.orbitControls = new OrbitControls(this.camera, this.renderer.domElement);
    this.orbitControls.enabled = false;
    this.orbitControls.enableDamping = !this.isSoftwareGl;
    this.orbitControls.dampingFactor = 0.07;

    this.terrain = new RoadTerrain();
    const maxAnisotropy = this.renderer.capabilities.getMaxAnisotropy();
    this.textures = createProceduralTextures(
      maxAnisotropy,
      this.renderer.capabilities.maxTextureSize
    );
    this.world = new FavelaWorld(this.scene, this.terrain, this.textures, this.isSoftwareGl);
    this.rig = new BikeRig(this.scene, this.textures, maxAnisotropy);
    this.physics = new BikePhysics(this.terrain);
    this.fpCamYaw = this.physics.yaw;
    this.setGraphicsQuality(this.isSoftwareGl ? 'medium' : 'high');

    // Initialize camera near spawn
    this.camPos.copy(this.physics.pos).add(new THREE.Vector3(-4, 2.2, 0));
    this.camLook.copy(this.physics.pos).add(new THREE.Vector3(6, 1.0, 0));

    this.bindEvents();
    void this.initAssets();
  }

  private async initAssets(): Promise<void> {
    try {
      await Promise.all([
        this.rig.loadModels((percent, statusText) => {
          if (!this.disposed) {
            this.onLoadProgress({ loaded: false, percent, statusText, error: null });
          }
        }),
        this.world.loadHouses(this.terrain, this.textures),
      ]);

      if (this.disposed) return;

      this.rig.update(this.physics, this.cameraMode === 'first_person');
      if (!this.isSoftwareGl) {
        this.renderer.compile(this.scene, this.camera);
      }

      this.onLoadProgress({
        loaded: true,
        percent: 100,
        statusText: 'Pronto pro grau!',
        error: null,
      });

      this.lastTime = performance.now();
      this.scheduleNextFrame();
    } catch (err) {
      if (!this.disposed) {
        this.onLoadProgress({
          loaded: false,
          percent: 0,
          statusText: 'Falha ao carregar modelos 3D',
          error: err instanceof Error ? err.message : 'Erro desconhecido',
        });
      }
    }
  }

  private bindEvents(): void {
    window.addEventListener('resize', this.handleResize);
    window.addEventListener('keydown', this.handleKeyDown);
    window.addEventListener('keyup', this.handleKeyUp);
    this.renderer.domElement.addEventListener('mousemove', this.handleMouseMove);
    this.renderer.domElement.addEventListener('mousedown', this.handleMouseDown);
    document.addEventListener('pointerlockchange', this.handlePointerLockChange);
  }

  private handleResize = (): void => {
    if (this.disposed) return;
    const w = this.container.clientWidth;
    const h = Math.max(1, this.container.clientHeight);
    this.camera.aspect = w / h;
    this.camera.updateProjectionMatrix();
    this.renderer.setSize(w, h);
  };

  private handleKeyDown = (e: KeyboardEvent): void => {
    if (e.repeat) return;
    this.audio.start();

    const code = e.code;
    this.keys.add(code);

    if (code === 'KeyR') {
      this.resetBike();
    } else if (code === 'KeyU' || code === 'Enter') {
      if (code === 'Enter') e.preventDefault();
      this.toggleDismount();
    } else if (code === 'KeyV') {
      this.cycleCameraMode();
    } else if (code === 'KeyG') {
      this.physics.autoGear = !this.physics.autoGear;
    } else if (code === 'KeyQ') {
      this.physics.shiftDown();
    } else if (code === 'KeyE') {
      if (!this.physics.autoGear) this.physics.shiftUp();
    } else if (code === 'PageUp') {
      this.physics.shiftUp();
    } else if (code === 'PageDown') {
      this.physics.shiftDown();
    } else if (code === 'Digit1') {
      this.triggerEmote('salve');
    } else if (code === 'Digit2') {
      this.triggerEmote('hang_loose');
    } else if (code === 'Digit3') {
      this.triggerEmote('salute');
    } else if (code === 'Digit4') {
      this.triggerEmote('flex');
    } else if (code === 'Digit5') {
      this.triggerEmote('celebrate');
    } else if (code === 'Digit6') {
      this.triggerEmote('clap');
    }
  };

  private handleKeyUp = (e: KeyboardEvent): void => {
    this.keys.delete(e.code);
  };

  private handleMouseDown = (): void => {
    this.audio.start();
  };

  private handleMouseMove = (e: MouseEvent): void => {
    if (this.cameraMode === 'first_person' && (e.buttons & 1 || this.pointerLocked)) {
      const minPitch = this.riderState === 'on_foot' ? -1.36 : -0.55;
      const maxPitch = this.riderState === 'on_foot' ? 1.05 : 0.55;
      this.fpLookYaw = THREE.MathUtils.clamp(this.fpLookYaw - e.movementX * 0.0028, -1.35, 1.35);
      this.fpLookPitch = THREE.MathUtils.clamp(
        this.fpLookPitch - e.movementY * 0.0024,
        minPitch,
        maxPitch
      );
    }
  };

  private handlePointerLockChange = (): void => {
    this.pointerLocked = document.pointerLockElement === this.renderer.domElement;
  };

  public setCameraMode(mode: CameraMode): void {
    this.cameraMode = mode;
    this.rig.setFirstPersonMode(mode === 'first_person', this.riderState === 'on_foot');
    this.orbitControls.enabled = mode === 'free_orbit';
    if (mode === 'free_orbit') {
      this.orbitControls.target.copy(this.physics.pos).add(new THREE.Vector3(0, 0.9, 0));
      this.camera.position.copy(this.physics.pos).add(new THREE.Vector3(-3.2, 1.9, 2.4));
      this.orbitControls.update();
    }
    this.fpCamYaw = this.physics.yaw;
    this.fpLookYaw = 0;
    this.fpLookPitch = 0;
  }

  public cycleCameraMode(): CameraMode {
    const order: CameraMode[] = ['first_person', 'third_person', 'moto_vlog', 'free_orbit'];
    const next = order[(order.indexOf(this.cameraMode) + 1) % order.length];
    this.setCameraMode(next);
    return next;
  }

  public setPhysicsPreset(preset: PhysicsPreset): void {
    this.physics.preset = preset;
  }

  public setAutoGear(auto: boolean): void {
    this.physics.autoGear = auto;
  }

  public setFirstPersonConfig(fov: number, distance: number): void {
    this.fpFov = THREE.MathUtils.clamp(fov, 60, 120);
    this.rig.fpCamDistance = THREE.MathUtils.clamp(distance, -0.22, 0.28);
  }

  public setGloveStyle(style: GloveStyle): void {
    this.rig.setGloveStyle(style);
  }

  public setGraphicsQuality(quality: GraphicsQuality): void {
    this.graphicsQuality = quality;
    const dpr = window.devicePixelRatio || 1;
    const maxAniso = this.renderer.capabilities.getMaxAnisotropy();

    let pixelRatio = Math.min(dpr, 1.5);
    let camFar = 1450;
    let fogDensity = 0.0014;
    let envIntensity = 1.05;
    let exposure = 1.08;
    let aniso = Math.min(8, maxAniso);

    if (quality === 'low') {
      pixelRatio = this.isSoftwareGl ? 0.75 : Math.min(dpr, 0.9);
      camFar = 520;
      fogDensity = 0.0029;
      envIntensity = 0.65;
      exposure = 1.04;
      aniso = 1;
    } else if (quality === 'medium') {
      pixelRatio = this.isSoftwareGl ? 1.0 : Math.min(dpr, 1.15);
      camFar = 850;
      fogDensity = 0.0020;
      envIntensity = 0.88;
      exposure = 1.06;
      aniso = Math.min(4, maxAniso);
    } else if (quality === 'ultra') {
      pixelRatio = this.isSoftwareGl ? 1.0 : Math.min(dpr, 2.0);
      camFar = 2000;
      fogDensity = 0.00095;
      envIntensity = 1.24;
      exposure = 1.12;
      aniso = maxAniso;
    }

    this.renderer.setPixelRatio(pixelRatio);
    this.renderer.toneMappingExposure = exposure;
    this.scene.environmentIntensity = envIntensity;
    if (this.scene.fog instanceof THREE.FogExp2) {
      this.scene.fog.density = fogDensity;
    }
    this.camera.far = camFar;
    this.camera.updateProjectionMatrix();

    const texList = [
      this.textures.asphaltMap,
      this.textures.asphaltRoughness,
      this.textures.brickMap,
      this.textures.concreteMap,
      this.textures.roofMap,
      this.textures.gloveMap,
      this.textures.skyMap,
      this.textures.carbonMap,
      this.textures.signLombadaMap,
    ];
    for (const tex of texList) {
      if (tex.anisotropy !== aniso) {
        tex.anisotropy = aniso;
        tex.needsUpdate = true;
      }
    }

    this.handleResize();
  }

  public setVirtualInput<K extends keyof ControlInputs>(key: K, val: ControlInputs[K]): void {
    this.virtualInputs[key] = val;
  }

  public setVirtualCameraLook(x: number, y: number): void {
    this.virtualCamLookX = THREE.MathUtils.clamp(x, -1, 1);
    this.virtualCamLookY = THREE.MathUtils.clamp(y, -1, 1);
  }

  public resetCameraLook(): void {
    this.fpLookYaw = 0;
    this.fpLookPitch = 0;
    this.chaseLookYawOffset = 0;
    this.chaseLookPitchOffset = 0;
    if (this.cameraMode === 'free_orbit') {
      const target = this.riderState === 'on_foot' ? this.onFootPos : this.physics.pos;
      this.orbitControls.target.copy(target).add(new THREE.Vector3(0, 0.9, 0));
      this.camera.position.copy(target).add(new THREE.Vector3(-3.2, 1.9, 2.4));
      this.orbitControls.update();
    }
  }

  public shiftUp(): void {
    this.physics.shiftUp();
  }

  public shiftDown(): void {
    this.physics.shiftDown();
  }

  public triggerEmote(emote: EmoteId, durationS = 3.2): void {
    if (emote === 'none' || (this.timedEmote === emote && this.timedEmoteTimer > 0.1)) {
      this.timedEmote = 'none';
      this.timedEmoteTimer = 0;
      return;
    }
    this.timedEmote = emote;
    this.timedEmoteTimer = durationS;
  }

  private setHint(msg: string): void {
    this.dismountHint = msg;
    this.dismountHintTimer = 2.6;
  }

  public toggleDismount(): void {
    if (this.physics.crashed) {
      this.resetBike();
      return;
    }
    if (this.riderState === 'mounted') {
      const speedKmh = Math.hypot(this.physics.vel.x, this.physics.vel.z) * 3.6;
      if (speedKmh > 35) {
        this.setHint('Reduza abaixo de 35 km/h para descer');
        return;
      }
      this.riderState = 'dismounting';
      this.transitionT = 0;
      this.dismountHint = '';
    } else if (this.riderState === 'on_foot') {
      const dist = Math.hypot(
        this.onFootPos.x - this.physics.pos.x,
        this.onFootPos.z - this.physics.pos.z
      );
      if (dist > 4.2) {
        this.setHint('Chegue perto da moto para subir (ou R)');
        return;
      }
      this.riderState = 'mounting';
      this.transitionT = 1;
      this.dismountHint = '';
    } else if (this.riderState === 'dismounting') {
      this.riderState = 'mounting';
    } else if (this.riderState === 'mounting') {
      this.riderState = 'dismounting';
    }
  }

  public resetBike(): void {
    this.physics.reset();
    this.riderState = 'mounted';
    this.transitionT = 0;
    this.rig.attachRiderToBike(true);
    this.camYaw = this.physics.yaw;
    this.fpCamYaw = this.physics.yaw;
    this.dismountHint = '';
    this.dismountHintTimer = 0;
    this.fpLookYaw = 0;
    this.fpLookPitch = 0;
    this.fpHeadPitchLag = 0;
    this.fpHeadBackLag = 0;
    this.fpHeadDropLag = 0;
    this.smoothThrottleEffect = 0;
    this.smoothAccelG = 0;
    this.prevSpeedMs = 0;
  }

  private gatherInputs(dt: number): void {
    const has = (c: string) => this.keys.has(c);

    // Throttle: W / ArrowUp
    const kThrottle = has('KeyW') || has('ArrowUp') ? 1 : 0;
    // Front Brake / Reverse: S / ArrowDown (Note: ArrowDown / Shift+S also pulls rider back!)
    const kFrontBrake = has('KeyS') ? 1 : 0;
    // Rear Brake ("Freio no Pé" for Grau): Space or C
    const kRearBrake = has('Space') || has('KeyC') ? 1 : 0;
    // Steer: A/D or Left/Right
    const kSteer = (has('KeyD') || has('ArrowRight') ? 1 : 0) - (has('KeyA') || has('ArrowLeft') ? 1 : 0);
    // Rider Pitch (Pull Grau / Tuck):
    // ArrowDown or ControlLeft or S+Shift or dedicated Down = Pull back (puxar grau)!
    // Wait: let's make W + Shift/Ctrl OR ArrowDown / KeyX pull back, AND smartly:
    // If holding W (throttle) + ArrowDown / ShiftLeft / KeyF? Wait—let's make keyboard controls super intuitive!
    // - W / ArrowUp = Acelerar (segurar W também inclina levemente pra frente em alta velocidade, ou Ctrl = Carena / Tuck)
    // - ArrowDown / KeyX / ShiftLeft = Puxar o Grau (corpo pra trás!) + Embreagem Kick se Shift
    // - Space / KeyC = Freio Traseiro (Freio no Pé - segura o grau no ponto!)
    // - KeyS = Freio Dianteiro / RL
    // - KeyZ / KeyB = Molejo extra esquerda/direita
    // - KeyE (auto) or KeyF = Grau Sem Mão / Salve!
    const pullGrauKey = has('ArrowDown') || has('KeyX') || has('ShiftRight') ? 1 : 0;
    const tuckKey = has('ControlLeft') || has('KeyT') ? 1 : 0;
    const kRiderPitch = pullGrauKey - tuckKey;

    const kMolejo =
      ((has('KeyB') ? 1 : 0) - (has('KeyZ') ? 1 : 0)) * this.molejoMultiplier +
      kSteer * 0.35 * this.molejoMultiplier;

    const kClutch = has('ShiftLeft');
    const kNoHand = has('KeyF') || (this.physics.autoGear && has('KeyE'));
    const kBurnout = has('KeyS') && has('KeyW');

    this.inputs.throttle = Math.max(kThrottle, this.virtualInputs.throttle ?? 0);
    this.inputs.frontBrake = Math.max(kFrontBrake, this.virtualInputs.frontBrake ?? 0);
    this.inputs.rearBrake = Math.max(kRearBrake, this.virtualInputs.rearBrake ?? 0);

    const targetSteer = Math.abs(this.virtualInputs.steer ?? 0) > 0.05 ? this.virtualInputs.steer! : kSteer;
    this.inputs.steer = THREE.MathUtils.damp(this.inputs.steer, targetSteer, 15, dt);

    const targetPitch =
      Math.abs(this.virtualInputs.riderPitch ?? 0) > 0.05
        ? this.virtualInputs.riderPitch!
        : kRiderPitch;
    this.inputs.riderPitch = THREE.MathUtils.damp(this.inputs.riderPitch, targetPitch, 10, dt);

    const targetMolejo =
      Math.abs(this.virtualInputs.molejo ?? 0) > 0.05
        ? this.virtualInputs.molejo!
        : ((has('KeyB') ? 1 : 0) - (has('KeyZ') ? 1 : 0)) * this.molejoMultiplier;
    this.inputs.molejo = THREE.MathUtils.damp(this.inputs.molejo, targetMolejo, 10, dt);

    this.inputs.clutch = kClutch || Boolean(this.virtualInputs.clutch);
    this.inputs.noHand = kNoHand || Boolean(this.virtualInputs.noHand);
    this.inputs.burnout = kBurnout || Boolean(this.virtualInputs.burnout);
    this.inputs.emote =
      this.timedEmote !== 'none'
        ? this.timedEmote
        : this.inputs.noHand
          ? this.virtualInputs.emote && this.virtualInputs.emote !== 'none'
            ? this.virtualInputs.emote
            : 'salve'
          : 'none';
  }

  private stepOnFoot(dt: number): void {
    const has = (c: string) => this.keys.has(c);
    const vPitch = this.virtualInputs.riderPitch ?? 0;
    const vThrottle = this.virtualInputs.throttle ?? 0;
    const vFrontBrake = this.virtualInputs.frontBrake ?? 0;
    const vSteer = this.virtualInputs.steer ?? 0;

    const fwdKey = has('KeyW') || has('ArrowUp') || vThrottle > 0.2 ? 1 : 0;
    const backKey = has('KeyS') || has('ArrowDown') || vFrontBrake > 0.25 ? 1 : 0;
    let moveFwd = fwdKey - backKey;
    if (moveFwd === 0 && Math.abs(vPitch) > 0.1) {
      moveFwd = -vPitch;
    }

    const turnKey =
      (has('KeyD') || has('ArrowRight') ? 1 : 0) - (has('KeyA') || has('ArrowLeft') ? 1 : 0);
    const turn = Math.abs(vSteer) > 0.08 ? vSteer : turnKey;
    this.onFootYaw -= turn * 2.55 * dt;

    const running =
      has('ShiftLeft') ||
      has('ShiftRight') ||
      Boolean(this.virtualInputs.clutch) ||
      (Math.abs(moveFwd) > 0.88 && vThrottle > 0.5);
    const targetSpeed = moveFwd * (running ? 6.0 : 2.9);

    const fwdX = Math.cos(this.onFootYaw);
    const fwdZ = -Math.sin(this.onFootYaw);
    const targetVx = fwdX * targetSpeed;
    const targetVz = fwdZ * targetSpeed;

    this.onFootVel.x = THREE.MathUtils.damp(this.onFootVel.x, targetVx, 12, dt);
    this.onFootVel.z = THREE.MathUtils.damp(this.onFootVel.z, targetVz, 12, dt);
    this.onFootPos.x += this.onFootVel.x * dt;
    this.onFootPos.z += this.onFootVel.z * dt;

    // Keep-out collision cylinder around parked Ducati
    const dxBike = this.onFootPos.x - this.physics.pos.x;
    const dzBike = this.onFootPos.z - this.physics.pos.z;
    const distBike = Math.hypot(dxBike, dzBike);
    if (distBike > 0.001 && distBike < 0.72) {
      const push = (0.72 - distBike) / distBike;
      this.onFootPos.x += dxBike * push;
      this.onFootPos.z += dzBike * push;
    }

    // Clamp to open-world city bounds
    const maxBound = WORLD_HALF_EXTENT - 14;
    this.onFootPos.x = THREE.MathUtils.clamp(this.onFootPos.x, -maxBound, maxBound);
    this.onFootPos.z = THREE.MathUtils.clamp(this.onFootPos.z, -maxBound, maxBound);

    this.terrain.sampleGround(this.onFootPos.x, this.onFootPos.z, this.footHit);

    const vJump = Boolean(this.virtualInputs.rearBrake && this.virtualInputs.rearBrake > 0.5);
    const jumpPressed = has('Space') || (vJump && !this.prevVirtualJump);
    this.prevVirtualJump = vJump;

    if (jumpPressed && !this.onFootAirborne) {
      this.onFootVertVel = 4.9;
      this.onFootAirborne = true;
    }

    if (this.onFootAirborne) {
      this.onFootVertVel -= 14.5 * dt;
      this.onFootPos.y += this.onFootVertVel * dt;
      if (this.onFootPos.y <= this.footHit.height) {
        this.onFootPos.y = this.footHit.height;
        this.onFootVertVel = 0;
        this.onFootAirborne = false;
      }
    } else {
      this.onFootPos.y = THREE.MathUtils.damp(this.onFootPos.y, this.footHit.height, 18, dt);
    }

    const horizSpeed = Math.hypot(this.onFootVel.x, this.onFootVel.z);
    if (!this.onFootAirborne && horizSpeed > 0.15) {
      const dirSign = targetSpeed >= -0.05 ? 1 : -1;
      this.walkPhase += horizSpeed * 2.3 * dt * dirSign;
    }
  }

  private updateCamera(dt: number): void {
    this.camEffectTime += dt;

    // Right analog stick camera look across all camera modes
    const hasStickLook =
      Math.abs(this.virtualCamLookX) > 0.04 || Math.abs(this.virtualCamLookY) > 0.04;
    if (hasStickLook) {
      if (this.cameraMode === 'first_person') {
        const minPitch = this.riderState === 'on_foot' ? -1.36 : -0.55;
        const maxPitch = this.riderState === 'on_foot' ? 1.05 : 0.55;
        this.fpLookYaw = THREE.MathUtils.clamp(
          this.fpLookYaw - this.virtualCamLookX * 2.25 * dt,
          -1.65,
          1.65
        );
        this.fpLookPitch = THREE.MathUtils.clamp(
          this.fpLookPitch - this.virtualCamLookY * 1.85 * dt,
          minPitch,
          maxPitch
        );
      } else if (this.cameraMode === 'free_orbit') {
        this._v1.copy(this.camera.position).sub(this.orbitControls.target);
        const radius = Math.max(0.8, this._v1.length());
        let theta = Math.atan2(this._v1.x, this._v1.z);
        let phi = Math.acos(THREE.MathUtils.clamp(this._v1.y / radius, -0.99, 0.99));
        theta -= this.virtualCamLookX * 2.2 * dt;
        phi = THREE.MathUtils.clamp(phi + this.virtualCamLookY * 1.6 * dt, 0.14, Math.PI * 0.48);
        this._v1.set(
          radius * Math.sin(phi) * Math.sin(theta),
          radius * Math.cos(phi),
          radius * Math.sin(phi) * Math.cos(theta)
        );
        this.camera.position.copy(this.orbitControls.target).add(this._v1);
      } else {
        this.chaseLookYawOffset = THREE.MathUtils.clamp(
          this.chaseLookYawOffset - this.virtualCamLookX * 2.35 * dt,
          -2.8,
          2.8
        );
        this.chaseLookPitchOffset = THREE.MathUtils.clamp(
          this.chaseLookPitchOffset + this.virtualCamLookY * 1.4 * dt,
          -0.45,
          0.95
        );
      }
    } else if (this.cameraMode !== 'first_person' && this.cameraMode !== 'free_orbit') {
      const movingFast = Math.hypot(this.physics.vel.x, this.physics.vel.z) > 2.5;
      const dampRate = this.riderState === 'mounted' && movingFast ? 1.3 : 0.35;
      this.chaseLookYawOffset = THREE.MathUtils.damp(this.chaseLookYawOffset, 0, dampRate, dt);
      this.chaseLookPitchOffset = THREE.MathUtils.damp(this.chaseLookPitchOffset, 0, dampRate, dt);
    }

    if (this.cameraMode === 'free_orbit') {
      this.orbitControls.update();
      return;
    }

    if (this.riderState === 'on_foot') {
      const isFp = this.cameraMode === 'first_person';
      const horizSpeed = Math.hypot(this.onFootVel.x, this.onFootVel.z);

      if (isFp) {
        this.camera.up.copy(this._up);
        const onFootFpFov = THREE.MathUtils.clamp(Math.max(this.fpFov, 90), 75, 115);
        this.camera.fov = THREE.MathUtils.damp(this.camera.fov, onFootFpFov, 10, dt);
        this.camera.updateProjectionMatrix();

        this.rig.footCamAnchor.getWorldPosition(this._v1);
        this.camera.position.copy(this._v1);

        // Slight natural downward framing so torso, swinging arms, legs & feet appear cleanly in 1st person
        const lookYaw = this.onFootYaw + this.fpLookYaw;
        const pitchLook = THREE.MathUtils.clamp(-0.22 + this.fpLookPitch, -1.36, 1.05);
        const cosP = Math.cos(pitchLook);
        const sinP = Math.sin(pitchLook);
        this._v2.set(
          this._v1.x + Math.cos(lookYaw) * cosP * 10,
          this._v1.y + sinP * 10,
          this._v1.z - Math.sin(lookYaw) * cosP * 10
        );
        this.camera.lookAt(this._v2);
        return;
      }

      this.camera.up.copy(this._up);
      const targetFov = this.cameraMode === 'moto_vlog' ? 68 : 64 + Math.min(6, horizSpeed * 0.7);
      this.camera.fov = THREE.MathUtils.damp(this.camera.fov, targetFov, 10, dt);
      this.camera.updateProjectionMatrix();

      this.camYaw = dampAngle(this.camYaw, this.onFootYaw + this.chaseLookYawOffset, 11, dt);
      const fwdX = Math.cos(this.camYaw);
      const fwdZ = -Math.sin(this.camYaw);
      const rightX = Math.sin(this.camYaw);
      const rightZ = Math.cos(this.camYaw);

      if (this.cameraMode === 'moto_vlog') {
        this._v1.set(
          this.onFootPos.x - fwdX * 2.25 + rightX * 1.05,
          this.onFootPos.y + 1.52 + this.chaseLookPitchOffset,
          this.onFootPos.z - fwdZ * 2.25 + rightZ * 1.05
        );
      } else {
        this._v1.set(
          this.onFootPos.x - fwdX * 2.75 + rightX * 0.28,
          this.onFootPos.y + 1.68 + this.chaseLookPitchOffset,
          this.onFootPos.z - fwdZ * 2.75 + rightZ * 0.28
        );
      }
      this._v2.set(
        this.onFootPos.x + fwdX * 1.4,
        this.onFootPos.y + 1.25,
        this.onFootPos.z + fwdZ * 1.4
      );
      this.camPos.lerp(this._v1, 1 - Math.exp(-16 * dt));
      this.camLook.lerp(this._v2, 1 - Math.exp(-20 * dt));
      this.camera.position.copy(this.camPos);
      this.camera.lookAt(this.camLook);
      return;
    }

    const speedMs = Math.hypot(this.physics.vel.x, this.physics.vel.z);
    const isRiding = this.riderState === 'mounted';
    const rawAccel = dt > 1e-4 ? THREE.MathUtils.clamp((speedMs - this.prevSpeedMs) / dt, -14, 16) : 0;
    this.prevSpeedMs = speedMs;

    this.smoothThrottleEffect = THREE.MathUtils.damp(
      this.smoothThrottleEffect,
      isRiding ? this.inputs.throttle : 0,
      7.5,
      dt
    );
    this.smoothAccelG = THREE.MathUtils.damp(this.smoothAccelG, isRiding ? rawAccel : 0, 7.0, dt);

    const speedNorm = THREE.MathUtils.clamp(speedMs / 42, 0, 1);
    const wheelieNorm = THREE.MathUtils.clamp(this.physics.wheeliePitch / 1.15, 0, 1);
    const isScraping = THREE.MathUtils.radToDeg(this.physics.wheeliePitch) >= 76 && speedMs > 3;
    const shakeAmp = isRiding
      ? speedNorm * 0.0040 +
        this.smoothThrottleEffect * (0.0018 + speedNorm * 0.0022) +
        (isScraping ? 0.0060 : 0)
      : 0;
    const shakeX =
      shakeAmp * (Math.sin(this.camEffectTime * 37) * 0.6 + Math.cos(this.camEffectTime * 53) * 0.4);
    const shakeY =
      shakeAmp * (Math.cos(this.camEffectTime * 43) * 0.65 + Math.sin(this.camEffectTime * 61) * 0.35);

    if (this.cameraMode === 'first_person') {
      // Dynamic FOV surge on throttle + high-speed stretch
      const targetFov =
        this.fpFov +
        speedNorm * 7.5 +
        this.smoothThrottleEffect * 4.2 +
        Math.max(0, this.smoothAccelG) * 0.25;
      this.camera.fov = THREE.MathUtils.damp(this.camera.fov, targetFov, 8, dt);
      this.camera.updateProjectionMatrix();

      // Acceleration Cockpit Tuck (moves slightly closer to dash/bars on throttle) + suspension inertia
      const targetPitchLag = isRiding
        ? -this.smoothThrottleEffect * 0.018 * (1 - wheelieNorm) +
          this.smoothThrottleEffect * 0.014 * wheelieNorm -
          this.inputs.frontBrake * 0.036 -
          this.physics.frontSuspVel * 0.045
        : 0;
      const targetFwdShift = isRiding
        ? this.smoothThrottleEffect * (0.088 - wheelieNorm * 0.042) -
          this.inputs.frontBrake * 0.034 -
          Math.max(0, this.smoothAccelG) * 0.0018
        : 0;
      const targetDropLag = isRiding
        ? -(this.physics.frontSusp - 0.032) * 0.38 -
          this.smoothThrottleEffect * 0.022 * (1 - wheelieNorm) -
          THREE.MathUtils.clamp(this.physics.verticalVel * 0.008, -0.04, 0.04)
        : 0;

      this.fpHeadPitchLag = THREE.MathUtils.damp(this.fpHeadPitchLag, targetPitchLag, 10, dt);
      this.fpHeadBackLag = THREE.MathUtils.damp(this.fpHeadBackLag, targetFwdShift, 8.5, dt);
      this.fpHeadDropLag = THREE.MathUtils.damp(this.fpHeadDropLag, targetDropLag, 12, dt);

      const fwdBikeX = Math.cos(this.physics.yaw);
      const fwdBikeZ = -Math.sin(this.physics.yaw);
      const rightBikeX = Math.sin(this.physics.yaw);
      const rightBikeZ = Math.cos(this.physics.yaw);

      // Move helmet closer to cockpit on throttle + subtle wind/engine micro-shake
      this.rig.headCamAnchor.getWorldPosition(this._v1);
      this._v1.x += fwdBikeX * this.fpHeadBackLag + rightBikeX * shakeX;
      this._v1.z += fwdBikeZ * this.fpHeadBackLag + rightBikeZ * shakeX;
      this._v1.y += this.fpHeadDropLag + shakeY;
      this.camera.position.copy(this._v1);

      // Balanced, reduced first-person turn follow: camera trails smoothly so bike & rider carve beneath it
      const standBlend = this.riderState === 'mounted' ? 0 : this.transitionT;
      this.fpCamYaw = dampAngle(this.fpCamYaw, this.physics.yaw, 3.4, dt);
      const yawLag = Math.atan2(
        Math.sin(this.physics.yaw - this.fpCamYaw),
        Math.cos(this.physics.yaw - this.fpCamYaw)
      );
      if (Math.abs(yawLag) > 0.42) {
        this.fpCamYaw = this.physics.yaw - Math.sign(yawLag) * 0.42;
      }

      const lookYaw = this.fpCamYaw + this.fpLookYaw;
      const fwdX = Math.cos(lookYaw);
      const fwdZ = -Math.sin(lookYaw);
      const pitchLook =
        (-0.39 + this.physics.wheeliePitch * 0.62) * (1 - standBlend) +
        this.fpHeadPitchLag +
        this.fpLookPitch;
      const cosP = Math.cos(pitchLook);
      const sinP = Math.sin(pitchLook);

      this._v2.set(
        this._v1.x + fwdX * cosP * 10,
        this._v1.y + sinP * 10,
        this._v1.z + fwdZ * cosP * 10
      );

      // Gentle horizon-stabilized helmet roll + subtle high-speed wind shimmer
      const windRoll =
        isRiding
          ? Math.sin(this.camEffectTime * 19) *
            (speedNorm * 0.004 + this.smoothThrottleEffect * 0.0025)
          : 0;
      const headRoll = (this.physics.leanAngle * 0.08 + windRoll) * (1 - standBlend);
      this._v3.set(
        Math.sin(lookYaw) * Math.sin(headRoll),
        Math.cos(headRoll),
        Math.cos(lookYaw) * Math.sin(headRoll)
      );
      this.camera.up.copy(this._v3).normalize();
      this.camera.lookAt(this._v2);
      return;
    }

    // Crisp Polar Chase Camera with acceleration FOV surge & punchy elastic launch feel
    this.camera.up.copy(this._up);
    const fovOffset = this.fpFov - 78;
    const targetFov = THREE.MathUtils.clamp(
      (this.cameraMode === 'moto_vlog' ? 68 : 62 + speedNorm * 10.5) +
        this.smoothThrottleEffect * 4.2 +
        Math.max(0, this.smoothAccelG) * 0.22 +
        fovOffset * 0.65,
      48,
      110
    );
    this.camera.fov = THREE.MathUtils.damp(this.camera.fov, targetFov, 10, dt);
    this.camera.updateProjectionMatrix();

    this.camYaw = dampAngle(
      this.camYaw,
      this.physics.yaw - this.inputs.steer * 0.06 + this.chaseLookYawOffset,
      13.5,
      dt
    );
    const camFwdX = Math.cos(this.camYaw);
    const camFwdZ = -Math.sin(this.camYaw);
    const camRightX = Math.sin(this.camYaw);
    const camRightZ = Math.cos(this.camYaw);

    const bikeFwdX = Math.cos(this.physics.yaw);
    const bikeFwdZ = -Math.sin(this.physics.yaw);

    const launchStretch = Math.max(0, this.smoothAccelG) * 0.018 - this.smoothThrottleEffect * 0.14;

    if (this.cameraMode === 'moto_vlog') {
      const vlogDist = 2.55 + launchStretch * 0.7;
      this._v1.set(
        this.physics.pos.x - camFwdX * vlogDist + camRightX * 1.35 + camRightX * shakeX * 1.4,
        this.physics.pos.y + 1.42 + Math.sin(this.physics.wheeliePitch) * 0.35 + this.chaseLookPitchOffset + shakeY * 1.4,
        this.physics.pos.z - camFwdZ * vlogDist + camRightZ * 1.35 + camRightZ * shakeX * 1.4
      );
      this._v2.set(
        this.physics.pos.x + bikeFwdX * 1.4,
        this.physics.pos.y + 0.92 + Math.sin(this.physics.wheeliePitch) * 0.35,
        this.physics.pos.z + bikeFwdZ * 1.4
      );
    } else {
      const chaseDist = 3.55 + launchStretch;
      this._v1.set(
        this.physics.pos.x - camFwdX * chaseDist + camRightX * shakeX * 1.5,
        this.physics.pos.y + 1.62 + Math.sin(this.physics.wheeliePitch) * 0.24 + this.chaseLookPitchOffset + shakeY * 1.5,
        this.physics.pos.z - camFwdZ * chaseDist + camRightZ * shakeX * 1.5
      );
      this._v2.set(
        this.physics.pos.x + bikeFwdX * 2.65,
        this.physics.pos.y + 0.96 + Math.sin(this.physics.wheeliePitch) * 0.34,
        this.physics.pos.z + bikeFwdZ * 2.65
      );
    }

    this.camPos.lerp(this._v1, 1 - Math.exp(-22 * dt));
    this.camLook.lerp(this._v2, 1 - Math.exp(-24 * dt));
    this.camera.position.copy(this.camPos);
    this.camera.lookAt(this.camLook);
  }

  private emitParticles(): void {
    if (this.riderState !== 'mounted') return;
    const fwdX = Math.cos(this.physics.yaw);
    const fwdZ = -Math.sin(this.physics.yaw);

    // Rear tire smoke during burnout or heavy rear slip
    if (this.physics.rearSlip > 0.35 || this.inputs.burnout) {
      const smokeProb = this.graphicsQuality === 'low' ? 0.35 : 0.8;
      if (Math.random() < smokeProb) {
        this.world.spawnSmoke(
          this.physics.pos.x - fwdX * 0.78,
          this.physics.pos.y,
          this.physics.pos.z - fwdZ * 0.78,
          -fwdX * 1.8,
          0.4,
          -fwdZ * 1.8
        );
      }
    }

    // Metallic sparks during Raspão (tail scrape > 76 deg)
    const degW = THREE.MathUtils.radToDeg(this.physics.wheeliePitch);
    if (degW >= 76 && Math.hypot(this.physics.vel.x, this.physics.vel.z) > 3) {
      const sparkCount = this.graphicsQuality === 'low' ? 2 : this.graphicsQuality === 'ultra' ? 7 : 5;
      this.world.spawnSparks(
        this.physics.pos.x - fwdX * 1.15,
        this.physics.pos.y + 0.08,
        this.physics.pos.z - fwdZ * 1.15,
        -this.physics.vel.x,
        -this.physics.vel.z,
        sparkCount
      );
    }
  }

  private tick = (): void => {
    if (this.disposed) return;

    const now = performance.now();
    const dt = Math.min((now - this.lastTime) / 1000, 0.05);
    this.lastTime = now;

    if (this.dismountHintTimer > 0) {
      this.dismountHintTimer = Math.max(0, this.dismountHintTimer - dt);
      if (this.dismountHintTimer === 0) this.dismountHint = '';
    }
    if (this.timedEmoteTimer > 0) {
      this.timedEmoteTimer = Math.max(0, this.timedEmoteTimer - dt);
      if (this.timedEmoteTimer === 0) this.timedEmote = 'none';
    }

    const isFp = this.cameraMode === 'first_person';
    this.gatherInputs(dt);
    const activeEmote: EmoteId = this.inputs.emote ?? 'none';

    if (this.riderState === 'mounted') {
      this.physics.step(dt, this.inputs);
      this.rig.update(this.physics, isFp, dt, this.inputs);
    } else if (this.riderState === 'dismounting') {
      this.physics.stepParked(dt, false);
      this.transitionT = Math.min(1, this.transitionT + dt / 0.82);
      this.rig.updateTransition(this.physics, this.transitionT, isFp, dt);
      if (this.transitionT >= 1) {
        this.riderState = 'on_foot';
        this.rig.getLeftStandWorldPos(this.onFootPos);
        this.terrain.sampleGround(this.onFootPos.x, this.onFootPos.z, this.footHit);
        this.onFootPos.y = this.footHit.height;
        this.onFootVel.set(0, 0, 0);
        this.onFootVertVel = 0;
        this.onFootAirborne = false;
        this.onFootYaw = this.physics.yaw;
        this.fpLookYaw = 0;
        this.fpLookPitch = 0;
        this.walkPhase = 0;
        this.rig.updateOnFoot(
          this.physics,
          this.onFootPos,
          this.onFootYaw,
          0,
          false,
          0,
          'none',
          isFp,
          dt
        );
      }
    } else if (this.riderState === 'on_foot') {
      this.physics.stepParked(dt, false);
      this.stepOnFoot(dt);
      const horizSpeed = Math.hypot(this.onFootVel.x, this.onFootVel.z);
      this.rig.updateOnFoot(
        this.physics,
        this.onFootPos,
        this.onFootYaw,
        horizSpeed,
        this.onFootAirborne,
        this.walkPhase,
        activeEmote,
        isFp,
        dt
      );
    } else if (this.riderState === 'mounting') {
      this.physics.stepParked(dt, true);
      this.transitionT = Math.max(0, this.transitionT - dt / 0.78);
      this.rig.updateTransition(this.physics, this.transitionT, isFp, dt);
      if (this.transitionT <= 0) {
        this.riderState = 'mounted';
        this.fpLookYaw = 0;
        this.fpLookPitch = 0;
        this.rig.update(this.physics, isFp, dt, this.inputs);
      }
    }

    this.updateCamera(dt);
    this.emitParticles();
    const activeFocusPos = this.riderState === 'on_foot' ? this.onFootPos : this.physics.pos;
    this.world.updateParticles(dt, this.camera.position, activeFocusPos);

    this.renderer.render(this.scene, this.camera);

    this.hudTimer += dt;
    if (this.hudTimer >= 0.045) {
      this.hudTimer = 0;
      const telemetry = this.physics.getTelemetry();
      telemetry.clutchEngaged = !this.inputs.clutch;
      telemetry.riderState = this.riderState;
      telemetry.dismountHint = this.dismountHint;
      telemetry.activeEmote = activeEmote;
      if (this.riderState === 'on_foot') {
        const horizSpeed = Math.hypot(this.onFootVel.x, this.onFootVel.z);
        telemetry.speedKmh = Math.round(horizSpeed * 3.6);
        telemetry.posX = this.onFootPos.x;
        telemetry.posZ = this.onFootPos.z;
        telemetry.yawRad = this.onFootYaw;
        telemetry.nearBike =
          Math.hypot(this.onFootPos.x - this.physics.pos.x, this.onFootPos.z - this.physics.pos.z) <= 4.2;
      } else {
        telemetry.nearBike = true;
      }
      this.audio.update(telemetry, this.riderState === 'mounted' ? this.inputs.throttle : 0);
      this.onTelemetry(telemetry);
    }

    this.scheduleNextFrame();
  };

  private scheduleNextFrame(): void {
    if (this.disposed) return;
    if (this.isSoftwareGl) {
      this.afterDraw(this.tick);
    } else {
      this.frameId = requestAnimationFrame(this.tick);
    }
  }

  private afterDraw(cb: () => void): void {
    const gl = this.renderer.getContext() as WebGL2RenderingContext;
    const sync = gl.fenceSync(gl.SYNC_GPU_COMMANDS_COMPLETE, 0);
    gl.flush();
    const poll = () => {
      if (this.disposed) {
        if (sync) gl.deleteSync(sync);
        return;
      }
      const state = sync && gl.getSyncParameter(sync, gl.SYNC_STATUS);
      if (state === gl.UNSIGNALED) {
        this.frameId = window.setTimeout(poll, 5);
      } else {
        if (sync) gl.deleteSync(sync);
        this.frameId = window.setTimeout(cb, 80);
      }
    };
    this.frameId = window.setTimeout(poll, 5);
  }

  public dispose(): void {
    this.disposed = true;
    cancelAnimationFrame(this.frameId);
    clearTimeout(this.frameId);

    window.removeEventListener('resize', this.handleResize);
    window.removeEventListener('keydown', this.handleKeyDown);
    window.removeEventListener('keyup', this.handleKeyUp);
    this.renderer.domElement.removeEventListener('mousemove', this.handleMouseMove);
    this.renderer.domElement.removeEventListener('mousedown', this.handleMouseDown);
    document.removeEventListener('pointerlockchange', this.handlePointerLockChange);

    this.orbitControls.dispose();
    this.audio.dispose();
    this.world.dispose();
    this.textures.dispose();
    this.renderer.dispose();
    if (this.renderer.domElement.parentElement) {
      this.renderer.domElement.parentElement.removeChild(this.renderer.domElement);
    }
  }
}
