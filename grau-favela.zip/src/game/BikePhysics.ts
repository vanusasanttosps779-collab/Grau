import * as THREE from 'three';
import { GroundHit, RoadTerrain, WORLD_HALF_EXTENT } from './RoadTerrain';
import { ControlInputs, PhysicsPreset, TelemetryState } from './types';

const GEAR_RATIOS = [0, 3.25, 2.55, 2.06, 1.72, 1.46, 1.26]; // N, 1..6 (balanced urban street gearing)
const FINAL_DRIVE = 10.6;
const WHEEL_RADIUS_R = 0.325;
const WHEEL_RADIUS_F = 0.302;
const WHEELBASE = 1.496;
const GRAVITY = 9.81;

export class BikePhysics {
  // World-space pose (rear axle ground projection origin)
  public pos = new THREE.Vector3(-65, 0, 0);
  public vel = new THREE.Vector3(0, 0, 0);
  public yaw = 0; // 0 = +X forward

  // Dynamic angles (radians)
  public leanAngle = 0; // + = right lean, - = left lean
  public leanRate = 0;
  public whipAngle = 0; // independent Molejo / Grau sway roll without over-turning
  public steerAngle = 0; // handlebar steer angle (+ = left, - = right)
  public wheeliePitch = 0; // + = front wheel up (grau), - = rear wheel up (stoppie/RL)
  public pitchRate = 0;

  // Suspension travel (0 = extended, 0.13 = bottomed out)
  public frontSusp = 0.032;
  public rearSusp = 0.035;
  public frontSuspVel = 0;
  public rearSuspVel = 0;
  public readonly maxSuspTravel = 0.13;

  // Vertical state (for jumps / lombadas)
  public verticalVel = 0;
  public isAirborne = false;

  // Drivetrain
  public gear = 1;
  public autoGear = true;
  public rpm = 1450;
  public maxRpm = 15000;
  public wheelSpinFront = 0;
  public wheelSpinRear = 0;
  public rearSlip = 0;
  public revLimiter = false;
  private limiterTimer = 0;
  private prevClutch = false;
  private clutchKickTimer = 0;

  // Rider molejo & pose smoothing
  public riderLateral = 0; // -1..+1 hang-off / molejo
  public riderForeAft = 0; // -1 tuck .. +1 pull back
  public molejoPhase = 0;
  public noHandBlend = 0;

  // Scoring & Crash state
  public grauDistanceM = 0;
  public grauDurationS = 0;
  public currentCombo = 0;
  public totalScore = 0;
  public bestGrauDistanceM = 0;
  public bestCombo = 0;
  public crashed = false;
  public crashReason = '';
  public crashTimer = 0;

  public preset: PhysicsPreset = 'simulation';

  private readonly rearHit: GroundHit = {
    height: 0,
    nx: 0,
    ny: 1,
    nz: 0,
    surface: 'asphalt',
  };
  private readonly frontHit: GroundHit = {
    height: 0,
    nx: 0,
    ny: 1,
    nz: 0,
    surface: 'asphalt',
  };

  constructor(private readonly terrain: RoadTerrain) {
    this.loadSavedBests();
    this.reset();
  }

  private loadSavedBests(): void {
    try {
      const saved = localStorage.getItem('grau_favela_records');
      if (saved) {
        const parsed = JSON.parse(saved);
        this.bestGrauDistanceM = Number(parsed.bestGrauDistanceM) || 0;
        this.bestCombo = Number(parsed.bestCombo) || 0;
      }
    } catch {
      // ignore storage errors
    }
  }

  private saveBests(): void {
    try {
      localStorage.setItem(
        'grau_favela_records',
        JSON.stringify({
          bestGrauDistanceM: Math.round(this.bestGrauDistanceM * 10) / 10,
          bestCombo: Math.round(this.bestCombo),
        })
      );
    } catch {
      // ignore storage errors
    }
  }

  public reset(): void {
    // Spawn on Av. Principal facing +X near central intersections & Beco do Morro
    const startX = -65;
    const startZ = 0;
    const startY = this.terrain.baseTerrainHeight(startX, startZ);
    this.pos.set(startX, startY, startZ);
    this.vel.set(0, 0, 0);
    this.yaw = 0;
    this.leanAngle = 0;
    this.leanRate = 0;
    this.whipAngle = 0;
    this.steerAngle = 0;
    this.wheeliePitch = 0;
    this.pitchRate = 0;
    this.frontSusp = 0.032;
    this.rearSusp = 0.035;
    this.frontSuspVel = 0;
    this.rearSuspVel = 0;
    this.verticalVel = 0;
    this.isAirborne = false;
    this.gear = 1;
    this.rpm = 1450;
    this.rearSlip = 0;
    this.revLimiter = false;
    this.riderLateral = 0;
    this.riderForeAft = 0;
    this.noHandBlend = 0;
    this.grauDistanceM = 0;
    this.grauDurationS = 0;
    this.currentCombo = 0;
    this.crashed = false;
    this.crashReason = '';
    this.crashTimer = 0;
  }

  public shiftUp(): void {
    if (this.gear < 6) this.gear++;
  }

  public shiftDown(): void {
    if (this.gear > 0) this.gear--;
  }

  public step(dtRaw: number, inputs: ControlInputs): void {
    const clampedDt = Math.min(dtRaw, 0.05);
    const substeps = 4;
    const dt = clampedDt / substeps;

    for (let s = 0; s < substeps; s++) {
      this.substep(dt, inputs);
    }
  }

  public stepParked(dtRaw: number, engineRunning: boolean): void {
    const dt = Math.min(dtRaw, 0.05);
    this.vel.multiplyScalar(Math.exp(-7.5 * dt));
    if (this.vel.lengthSq() < 0.01) this.vel.set(0, 0, 0);
    this.pos.addScaledVector(this.vel, dt);
    this.terrain.sampleGround(this.pos.x, this.pos.z, this.rearHit);
    this.pos.y = THREE.MathUtils.damp(this.pos.y, this.rearHit.height, 14, dt);
    this.verticalVel = 0;
    this.isAirborne = false;

    // Rest Ducati cleanly on its left kickstand (-leanAngle, slight left bar lock)
    this.leanAngle = THREE.MathUtils.damp(this.leanAngle, -0.14, 7.5, dt);
    this.leanRate = 0;
    this.whipAngle = THREE.MathUtils.damp(this.whipAngle, 0, 10, dt);
    this.steerAngle = THREE.MathUtils.damp(this.steerAngle, 0.26, 7.5, dt);
    this.wheeliePitch = THREE.MathUtils.damp(this.wheeliePitch, 0, 10, dt);
    this.pitchRate = 0;
    this.riderLateral = THREE.MathUtils.damp(this.riderLateral, 0, 10, dt);
    this.riderForeAft = THREE.MathUtils.damp(this.riderForeAft, 0, 10, dt);
    this.noHandBlend = THREE.MathUtils.damp(this.noHandBlend, 0, 12, dt);
    this.rearSlip = THREE.MathUtils.damp(this.rearSlip, 0, 12, dt);
    this.frontSusp = THREE.MathUtils.damp(this.frontSusp, 0.032, 10, dt);
    this.rearSusp = THREE.MathUtils.damp(this.rearSusp, 0.035, 10, dt);
    this.rpm = THREE.MathUtils.damp(this.rpm, engineRunning ? 1450 : 0, 5.5, dt);
  }

  private getEngineTorqueNm(rpm: number): number {
    // Balanced urban stunt torque curve: smooth launches and ~125-136 km/h top speed
    const norm = THREE.MathUtils.clamp((rpm - 1400) / (15000 - 1400), 0, 1);
    const curve = 0.56 + 0.44 * Math.sin(norm * Math.PI * 0.88);
    return 30 * curve;
  }

  private substep(dt: number, inputs: ControlInputs): void {
    if (this.crashed) {
      this.crashTimer += dt;
      this.vel.multiplyScalar(Math.exp(-2.4 * dt));
      this.pos.addScaledVector(this.vel, dt);
      this.terrain.sampleGround(this.pos.x, this.pos.z, this.rearHit);
      this.pos.y = THREE.MathUtils.damp(this.pos.y, this.rearHit.height, 14, dt);
      this.leanAngle = THREE.MathUtils.damp(
        this.leanAngle,
        Math.sign(this.leanAngle || 1) * 1.32,
        8,
        dt
      );
      this.wheeliePitch = THREE.MathUtils.damp(this.wheeliePitch, 0, 8, dt);
      this.rpm = THREE.MathUtils.damp(this.rpm, 0, 6, dt);
      return;
    }

    const fwdX = Math.cos(this.yaw);
    const fwdZ = -Math.sin(this.yaw);
    const rightX = Math.sin(this.yaw);
    const rightZ = Math.cos(this.yaw);

    const vForward = this.vel.x * fwdX + this.vel.z * fwdZ;
    const vLateral = this.vel.x * rightX + this.vel.z * rightZ;
    const speedAbs = Math.hypot(vForward, vLateral);

    // 1. Sample Open-World Terrain under Rear & Front Contact
    const rearWorldX = this.pos.x - fwdX * 0.73;
    const rearWorldZ = this.pos.z - fwdZ * 0.73;
    const frontWorldX = this.pos.x + fwdX * 0.76 * Math.cos(this.wheeliePitch);
    const frontWorldZ = this.pos.z + fwdZ * 0.76 * Math.cos(this.wheeliePitch);

    this.terrain.sampleGround(rearWorldX, rearWorldZ, this.rearHit);
    this.terrain.sampleGround(frontWorldX, frontWorldZ, this.frontHit);

    const surfaceGrip =
      this.rearHit.surface === 'dirt' ? 0.85 : this.rearHit.surface === 'sidewalk' ? 0.96 : 1.05;

    // 2. Suspension & Vertical Ground Contact (MX Bikes spring-damper)
    const targetGroundY = this.rearHit.height;
    const heightAboveGround = this.pos.y - targetGroundY;

    if (heightAboveGround > 0.08 && this.verticalVel > -12) {
      this.isAirborne = true;
    } else if (heightAboveGround <= 0.015) {
      this.isAirborne = false;
    }

    if (this.isAirborne) {
      this.verticalVel -= GRAVITY * dt;
      this.pos.y += this.verticalVel * dt;
      this.frontSusp = THREE.MathUtils.damp(this.frontSusp, 0, 12, dt);
      this.rearSusp = THREE.MathUtils.damp(this.rearSusp, 0, 12, dt);
      if (this.pos.y <= targetGroundY) {
        const impactVel = Math.max(0, -this.verticalVel);
        this.pos.y = targetGroundY;
        this.verticalVel = 0;
        this.isAirborne = false;
        this.rearSuspVel += Math.min(impactVel * 0.7, 2.5);
        this.frontSuspVel += Math.min(impactVel * 0.55, 2.0);
      }
    } else {
      const prevY = this.pos.y;
      const roadDeltaY = targetGroundY - prevY;
      this.pos.y = targetGroundY;
      const groundRiseRate = roadDeltaY / Math.max(dt, 1e-4);
      if (this.rearHit.surface === 'plaza' && groundRiseRate > 1.2 && speedAbs > 9) {
        // Stunt ramp launch
        this.verticalVel = Math.min(groundRiseRate * 0.45, 5.2);
        this.pitchRate += Math.min(groundRiseRate * 0.07, 0.38);
      } else if (this.rearHit.surface === 'lombada' && groundRiseRate > 1.4 && speedAbs > 14) {
        // Speed bump suspension pop without flipping the bike
        this.verticalVel = Math.min(groundRiseRate * 0.2, 2.1);
        this.rearSuspVel += 0.45;
        this.frontSuspVel += 0.35;
        this.pitchRate += Math.min(groundRiseRate * 0.018, 0.14);
      } else {
        // Smooth sidewalk curb / terrain bump absorption
        if (groundRiseRate > 0.8) {
          this.rearSuspVel += Math.min(groundRiseRate * 0.06, 0.35);
          this.frontSuspVel += Math.min(groundRiseRate * 0.05, 0.3);
        }
        this.verticalVel = 0;
      }
    }

    const terrainPitch = Math.atan2(this.frontHit.height - this.rearHit.height, WHEELBASE);

    // 3. Gearbox & Engine RPM
    if (this.autoGear && !inputs.clutch) {
      if (this.gear === 0 && inputs.throttle > 0.1) this.gear = 1;
      if (this.gear < 6 && this.rpm > 13400 && vForward > 4) {
        this.gear++;
      } else if (this.gear > 1 && this.rpm < 5800 && vForward < 32) {
        this.gear--;
      } else if (this.gear > 1 && this.rpm < 4200) {
        this.gear--;
      }
    }

    const gearRatio = GEAR_RATIOS[this.gear] * FINAL_DRIVE;
    const wheelRpmFromSpeed = Math.max(0, (vForward / (2 * Math.PI * WHEEL_RADIUS_R)) * 60);

    this.limiterTimer += dt;
    const overRev = this.rpm >= this.maxRpm - 180;
    this.revLimiter = overRev && inputs.throttle > 0.4;
    const effectiveThrottle =
      this.revLimiter && Math.sin(this.limiterTimer * 52) > 0 ? 0.05 : inputs.throttle;

    const engaged = !inputs.clutch && this.gear > 0 && !inputs.burnout;
    if (!engaged) {
      const freeTarget = 1450 + effectiveThrottle * (this.maxRpm - 1450);
      this.rpm = THREE.MathUtils.damp(this.rpm, freeTarget, effectiveThrottle > 0.1 ? 14 : 6, dt);
    } else {
      const coupledRpm = Math.max(1450, wheelRpmFromSpeed * gearRatio);
      const slipBoost = inputs.throttle * 1200 * (1 - Math.min(1, speedAbs / 18));
      this.rpm = THREE.MathUtils.damp(this.rpm, Math.min(this.maxRpm, coupledRpm + slipBoost), 22, dt);
    }

    // 4. Longitudinal Propulsion, Braking & Traction
    const engineTorque = this.getEngineTorqueNm(this.rpm) * effectiveThrottle;
    let driveForce = 0;

    if (inputs.burnout && speedAbs < 3) {
      this.rearSlip = THREE.MathUtils.damp(this.rearSlip, 0.95, 10, dt);
      driveForce = 0;
    } else if (engaged) {
      const rawWheelTorque = engineTorque * gearRatio * 0.92;
      driveForce = rawWheelTorque / WHEEL_RADIUS_R;
      if (this.rpm >= this.maxRpm - 120 && vForward > 36) {
        driveForce *= 0.1;
      }
    }

    const maxTireForce = 215 * GRAVITY * 1.18 * surfaceGrip;
    if (driveForce > maxTireForce) {
      this.rearSlip = THREE.MathUtils.clamp((driveForce - maxTireForce) / maxTireForce, 0, 1);
      driveForce = maxTireForce * (1 - this.rearSlip * 0.18);
    } else {
      this.rearSlip = THREE.MathUtils.damp(this.rearSlip, 0, 10, dt);
    }

    const frontBrakeContact = this.wheeliePitch < 0.12 ? 1 : 0;
    const frontBrakeForce = inputs.frontBrake * 2150 * frontBrakeContact * surfaceGrip;
    const rearBrakeForce = inputs.rearBrake * 1050 * surfaceGrip;
    const totalBrakeForce = vForward > 0.2 ? frontBrakeForce + rearBrakeForce : 0;

    const tuckBonus = inputs.riderPitch < 0 ? 0.80 : 1.0;
    const wheelieDrag = 1 + Math.sin(Math.max(0, this.wheeliePitch)) * 0.72;
    const aeroDrag = 0.88 * tuckBonus * wheelieDrag * vForward * Math.abs(vForward);
    const rollResist = 40 * Math.sign(vForward) * (speedAbs > 0.1 ? 1 : 0);
    const slopeGravityForce = -220 * GRAVITY * Math.sin(terrainPitch);

    const scrapeThreshold = THREE.MathUtils.degToRad(77);
    const isScraping = this.wheeliePitch > scrapeThreshold;
    const scrapeDrag = isScraping ? 380 : 0;

    const netLongAccel =
      (driveForce - totalBrakeForce - aeroDrag - rollResist - scrapeDrag + slopeGravityForce) / 225;

    let nextVForward = vForward + netLongAccel * dt;
    if (vForward >= 0 && nextVForward < 0 && inputs.throttle < 0.05) {
      nextVForward = 0;
    }
    if (speedAbs < 1.2 && inputs.frontBrake > 0.5 && inputs.throttle === 0) {
      nextVForward = -1.8;
    }

    // 5. Crisp Cornering, Counter-Steering & Controlled MX Bikes Lean / Grau Molejo Dynamics
    const presetAssist =
      this.preset === 'assist' ? 1.38 : this.preset === 'simulation' ? 1.18 : 1.0;
    const speedFactor = THREE.MathUtils.clamp(speedAbs / 3.8, 0.56, 1.0);
    const maxLean = THREE.MathUtils.degToRad(48);
    const wheelieNorm = THREE.MathUtils.clamp(this.wheeliePitch / 1.15, 0, 1);

    // Balanced athletic weight shift into turns + controlled Molejo on Z/B keys
    const lateralLimit = 0.85 + wheelieNorm * 0.18;
    const riderLeanShift = THREE.MathUtils.clamp(
      inputs.steer * 0.52 + inputs.molejo * (0.58 + wheelieNorm * 0.24),
      -lateralLimit,
      lateralLimit
    );
    this.riderLateral = THREE.MathUtils.damp(this.riderLateral, riderLeanShift, 13, dt);
    this.riderForeAft = THREE.MathUtils.damp(this.riderForeAft, inputs.riderPitch, 11, dt);

    // Multi-harmonic fluid bike whip / figure-8 Grau balance sway (purely visual style, never pulls steering off line)
    const whipDeg = 9.0 + wheelieNorm * 6.5;
    const grauRhythmLean =
      wheelieNorm *
      (Math.sin(this.molejoPhase) * (0.018 + Math.abs(inputs.molejo) * 0.06) +
        Math.sin(this.molejoPhase * 0.53) * 0.014 +
        Math.cos(this.molejoPhase * 1.37) * 0.008);
    const targetWhip = inputs.molejo * THREE.MathUtils.degToRad(whipDeg) + grauRhythmLean;
    this.whipAngle = THREE.MathUtils.damp(this.whipAngle, targetWhip, 13, dt);

    const targetLean = THREE.MathUtils.clamp(
      inputs.steer * maxLean * speedFactor,
      -0.86,
      0.86
    );
    const leanStiffness = (54 + speedAbs * 0.82) * presetAssist;
    const leanDamping = 2 * Math.sqrt(leanStiffness) * 0.88;
    const leanAccel =
      (targetLean - this.leanAngle) * leanStiffness - this.leanRate * leanDamping;
    this.leanRate += leanAccel * dt;
    this.leanAngle = THREE.MathUtils.clamp(this.leanAngle + this.leanRate * dt, -0.88, 0.88);

    // Expressive counter-steering kick, natural fork trail & fluid Grau bar micro-corrections
    const counterSteerKick = -this.leanRate * 0.18 * THREE.MathUtils.clamp(speedAbs / 12, 0.2, 1.15);
    const steadySteer =
      -inputs.steer * THREE.MathUtils.lerp(0.48, 0.15, THREE.MathUtils.clamp(speedAbs / 28, 0, 1));
    const grauBarFlow =
      wheelieNorm * (Math.sin(this.molejoPhase * 0.85) * 0.075 + Math.cos(this.molejoPhase * 1.55) * 0.035);
    this.steerAngle = THREE.MathUtils.damp(
      this.steerAngle,
      THREE.MathUtils.clamp(steadySteer + counterSteerKick + grauBarFlow, -0.58, 0.58),
      24,
      dt
    );

    // Effortless, fluid cornering across city streets, intersections, and mid-Grau
    const wheelieSteerDamp = THREE.MathUtils.clamp(1 - this.wheeliePitch / 3.2, 0.84, 1);
    const lowSpeedSteer =
      THREE.MathUtils.clamp(1 - speedAbs / 8.5, 0, 1) *
      (-inputs.steer * 2.05 * Math.sign(nextVForward || 1));
    const leanTurn =
      speedAbs > 0.8
        ? (-(Math.tan(this.leanAngle) * GRAVITY) / Math.max(speedAbs, 4.2)) * 1.58 * wheelieSteerDamp
        : 0;
    const directSteerCarve =
      speedAbs > 0.8
        ? -inputs.steer * THREE.MathUtils.clamp(speedAbs / 7.2, 0.44, 0.98) * wheelieSteerDamp
        : 0;
    const lateralTurnRate = lowSpeedSteer + leanTurn + directSteerCarve;

    this.yaw += lateralTurnRate * dt;

    const latGripDamp = (this.rearHit.surface === 'dirt' ? 6.2 : 19.5) * (1 - this.rearSlip * 0.35);
    const nextVLateral = vLateral * Math.exp(-latGripDamp * dt);

    const newFwdX = Math.cos(this.yaw);
    const newFwdZ = -Math.sin(this.yaw);
    const newRightX = Math.sin(this.yaw);
    const newRightZ = Math.cos(this.yaw);

    this.vel.x = newFwdX * nextVForward + newRightX * nextVLateral;
    this.vel.z = newFwdZ * nextVForward + newRightZ * nextVLateral;
    this.pos.x += this.vel.x * dt;
    this.pos.z += this.vel.z * dt;

    // Soft open-world map boundary keep-in (±222m inside 240m world edge)
    const maxBound = WORLD_HALF_EXTENT - 18;
    if (this.pos.x > maxBound) {
      this.pos.x = maxBound;
      if (this.vel.x > 0) this.vel.x = -this.vel.x * 0.25;
    } else if (this.pos.x < -maxBound) {
      this.pos.x = -maxBound;
      if (this.vel.x < 0) this.vel.x = -this.vel.x * 0.25;
    }
    if (this.pos.z > maxBound) {
      this.pos.z = maxBound;
      if (this.vel.z > 0) this.vel.z = -this.vel.z * 0.25;
    } else if (this.pos.z < -maxBound) {
      this.pos.z = -maxBound;
      if (this.vel.z < 0) this.vel.z = -this.vel.z * 0.25;
    }

    // Clutch-kick detection (revving with clutch in, then dumping clutch)
    if (this.prevClutch && !inputs.clutch && this.rpm > 6800 && inputs.throttle > 0.35 && this.gear > 0) {
      this.clutchKickTimer = 0.42;
    }
    this.prevClutch = inputs.clutch;
    if (this.clutchKickTimer > 0) {
      this.clutchKickTimer = Math.max(0, this.clutchKickTimer - dt);
    }

    // 6. Balanced, Progressive "Grau" (Wheelie) Equilibrium & "RL" (Stoppie) Pitch Dynamics
    // Pulls up smoothly without snapping too hard backward, settling cleanly around the 55-64 deg balance point
    const mass = 225;
    const pitchInertia = 92;
    const cmDist = 0.58;
    // Natural balance point around ~60 deg (pi/2 - 0.52 = 1.05 rad)
    const cmNeutralAngle = 0.52;

    const gravityTorque = -mass * GRAVITY * cmDist * Math.cos(this.wheeliePitch + cmNeutralAngle);

    // Pure acceleration keeps the front wheel planted on the asphalt; Grau only lifts when pulling Grau or clutch-kicking!
    const wantsGrau = inputs.riderPitch > 0.08 || this.clutchKickTimer > 0;
    const highAngleLiftScale = THREE.MathUtils.clamp(
      1 - Math.max(0, this.wheeliePitch - 0.62) * 1.38,
      0.12,
      1.0
    );
    let driveLiftTorque = 0;
    if (this.wheeliePitch < 0.10 && !wantsGrau) {
      driveLiftTorque = Math.min(Math.max(0, driveForce) * 0.18, Math.abs(gravityTorque) * 0.62);
    } else {
      const inWheelieBoost = this.wheeliePitch > 0.14 ? 0.46 : 0.34;
      driveLiftTorque = Math.max(0, driveForce) * inWheelieBoost * highAngleLiftScale;
    }
    const clutchKickTorque = this.clutchKickTimer > 0 ? 860 * (this.clutchKickTimer / 0.42) : 0;

    // Rider body shift ("Puxar Grau" / "Carena"):
    // Smooth progressive pull-up that naturally tapers near the balance point instead of yanking straight to 85 deg
    let riderShiftTorque = 0;
    if (inputs.riderPitch > 0.05) {
      const pullFade = THREE.MathUtils.clamp(1 - Math.max(0, this.wheeliePitch - 0.40) / 0.72, 0.14, 1);
      riderShiftTorque = inputs.riderPitch * 1240 * pullFade;
    } else if (inputs.riderPitch < -0.05) {
      riderShiftTorque = inputs.riderPitch * 860;
    }

    // Rear brake ("Freio no Pé") smoothly modulates and lowers the nose proportionally
    const rearBrakePitchTorque = -inputs.rearBrake * 1500;

    // Front brake creates forward dive / RL stoppie torque when front wheel is near ground
    const frontDiveTorque =
      this.wheeliePitch < 0.08 ? -inputs.frontBrake * Math.min(1, speedAbs / 5.5) * 1120 : 0;

    // Sweet-spot equilibrium damping around the balance point so holding a steady Grau feels effortless
    const inSweetSpot = THREE.MathUtils.clamp(1 - Math.abs(this.wheeliePitch - 1.04) / 0.52, 0, 1);
    const basePitchDamping = this.preset === 'mx_pro' ? 92 : this.preset === 'simulation' ? 124 : 156;
    const pitchDamping = basePitchDamping + inSweetSpot * 92;

    let netPitchTorque =
      driveLiftTorque +
      clutchKickTorque +
      riderShiftTorque +
      rearBrakePitchTorque +
      frontDiveTorque -
      this.pitchRate * pitchDamping;

    if (this.wheeliePitch > 0.01 || netPitchTorque + gravityTorque > 0 || inputs.frontBrake > 0.45) {
      netPitchTorque += gravityTorque;
    }

    // Gentle equilibrium cushion around ~58..64 deg so the player can hold & modulate balance smoothly
    const balanceTarget = 1.04 + Math.sin(this.molejoPhase * 0.65) * 0.035;
    if (this.wheeliePitch > 0.68 && this.wheeliePitch < 1.34 && inputs.rearBrake < 0.15) {
      const balStrength = this.preset === 'assist' ? 480 : this.preset === 'simulation' ? 290 : 155;
      netPitchTorque += (balanceTarget - this.wheeliePitch) * balStrength;
    }

    // Soft Raspão (tail scrape) cushion at 77..85.5 deg — NO falling off / loop-out during Grau!
    const scrapeLimitRad = THREE.MathUtils.degToRad(77);
    if (this.wheeliePitch > scrapeLimitRad) {
      netPitchTorque -= (this.wheeliePitch - scrapeLimitRad) * 1950 + Math.max(0, this.pitchRate) * 210;
    }

    const pitchAccel = netPitchTorque / pitchInertia;
    this.pitchRate += pitchAccel * dt;
    this.wheeliePitch += this.pitchRate * dt;

    // Ground contact clamp (or Stoppie down to -0.68 rad)
    const minPitch = inputs.frontBrake > 0.45 && speedAbs > 6 ? -0.68 : 0;
    if (this.wheeliePitch < minPitch) {
      if (this.pitchRate < -1.2) {
        this.frontSuspVel += Math.abs(this.pitchRate) * 0.32;
      }
      this.wheeliePitch = minPitch;
      if (this.pitchRate < 0) this.pitchRate = 0;
    }

    // Maximum Raspão ceiling (~85.5 deg) without crashing so players can scrape freely
    const maxGrauRad = THREE.MathUtils.degToRad(85.5);
    if (this.wheeliePitch > maxGrauRad) {
      this.wheeliePitch = maxGrauRad;
      if (this.pitchRate > 0) this.pitchRate *= -0.18;
    }

    // 7. Suspension Spring-Damper Integration
    const weightTransfer = THREE.MathUtils.clamp(netLongAccel / GRAVITY, -0.8, 0.8);
    const frontStaticTarget =
      this.wheeliePitch > 0.04
        ? 0.004
        : THREE.MathUtils.clamp(0.032 - weightTransfer * 0.045, 0.005, this.maxSuspTravel);
    const rearStaticTarget = THREE.MathUtils.clamp(
      0.035 +
        weightTransfer * 0.045 +
        (this.wheeliePitch > 0.1 ? 0.026 + Math.sin(this.molejoPhase * 1.15) * 0.009 * wheelieNorm : 0),
      0.005,
      this.maxSuspTravel
    );

    const kSusp = 190;
    const cSusp = 22;
    this.frontSuspVel += ((frontStaticTarget - this.frontSusp) * kSusp - this.frontSuspVel * cSusp) * dt;
    this.frontSusp = THREE.MathUtils.clamp(
      this.frontSusp + this.frontSuspVel * dt,
      0,
      this.maxSuspTravel
    );

    this.rearSuspVel += ((rearStaticTarget - this.rearSusp) * kSusp - this.rearSuspVel * cSusp) * dt;
    this.rearSusp = THREE.MathUtils.clamp(
      this.rearSusp + this.rearSuspVel * dt,
      0,
      this.maxSuspTravel
    );

    // 8. Wheel Spin & Molejo / No-Hand Blend
    const frontSpinSpeed = this.wheeliePitch > 0.06 ? Math.max(0, nextVForward * 0.96) : nextVForward;
    this.wheelSpinFront += (frontSpinSpeed / WHEEL_RADIUS_F) * dt;
    const rearSpinSpeed = inputs.burnout ? 24 : nextVForward * (1 + this.rearSlip * 0.65);
    this.wheelSpinRear += (rearSpinSpeed / WHEEL_RADIUS_R) * dt;

    const molejoSpeed =
      4.4 +
      Math.abs(inputs.molejo) * (5.6 + wheelieNorm * 2.2) +
      Math.abs(inputs.steer) * 3.8 +
      wheelieNorm * 2.8;
    this.molejoPhase += molejoSpeed * dt;

    const wantNoHand = inputs.noHand && this.wheeliePitch > THREE.MathUtils.degToRad(20) ? 1 : 0;
    this.noHandBlend = THREE.MathUtils.damp(this.noHandBlend, wantNoHand, 8, dt);

    // 9. Grau Combo & Distance Scoring
    const degWheelie = THREE.MathUtils.radToDeg(Math.max(0, this.wheeliePitch));
    const isGrau = degWheelie > 15 && speedAbs > 3.0;
    if (isGrau) {
      const distStep = Math.max(0, nextVForward) * dt;
      this.grauDistanceM += distStep;
      this.grauDurationS += dt;
      const inBalance = degWheelie >= 48 && degWheelie <= 77;
      const mult = (inBalance ? 2.2 : 1.0) * (isScraping ? 1.8 : 1.0) * (this.noHandBlend > 0.5 ? 1.6 : 1.0);
      this.currentCombo += distStep * 14 * mult;

      if (this.grauDistanceM > this.bestGrauDistanceM) {
        this.bestGrauDistanceM = this.grauDistanceM;
      }
      if (this.currentCombo > this.bestCombo) {
        this.bestCombo = this.currentCombo;
      }
    } else if (this.grauDistanceM > 0) {
      this.totalScore += Math.round(this.currentCombo);
      this.saveBests();
      this.grauDistanceM = 0;
      this.grauDurationS = 0;
      this.currentCombo = 0;
    }
  }

  private triggerCrash(reason: string): void {
    this.crashed = true;
    this.crashReason = reason;
    this.crashTimer = 0;
    this.grauDistanceM = 0;
    this.grauDurationS = 0;
    this.currentCombo = 0;
  }

  public getTelemetry(): TelemetryState {
    const speedMs = Math.hypot(this.vel.x, this.vel.z);
    const degWheelie = THREE.MathUtils.radToDeg(Math.max(0, this.wheeliePitch));
    const degStoppie = THREE.MathUtils.radToDeg(Math.max(0, -this.wheeliePitch));

    return {
      speedKmh: Math.round(speedMs * 3.6),
      rpm: Math.round(this.rpm),
      maxRpm: this.maxRpm,
      gear: this.gear,
      wheelieAngleDeg: Math.round(degWheelie),
      stoppieAngleDeg: Math.round(degStoppie),
      leanAngleDeg: Math.round(THREE.MathUtils.radToDeg(this.leanAngle + this.whipAngle)),
      frontSuspRatio: this.frontSusp / this.maxSuspTravel,
      rearSuspRatio: this.rearSusp / this.maxSuspTravel,
      rearSlip: this.rearSlip,
      isWheelie: degWheelie > 15 && speedMs > 3.0,
      isBalancePoint: degWheelie >= 48 && degWheelie <= 77,
      isScrape: degWheelie >= 77,
      isStoppie: degStoppie > 10,
      isAirborne: this.isAirborne,
      isNoHand: this.noHandBlend > 0.5,
      activeEmote: 'none',
      revLimiter: this.revLimiter,
      clutchEngaged: false,
      grauDistanceM: Math.round(this.grauDistanceM * 10) / 10,
      grauDurationS: Math.round(this.grauDurationS * 10) / 10,
      currentCombo: Math.round(this.currentCombo),
      totalScore: this.totalScore,
      bestGrauDistanceM: Math.round(this.bestGrauDistanceM * 10) / 10,
      bestCombo: Math.round(this.bestCombo),
      crashed: this.crashed,
      crashReason: this.crashReason,
      posX: this.pos.x,
      posZ: this.pos.z,
      yawRad: this.yaw,
      riderState: 'mounted',
      nearBike: true,
      dismountHint: '',
    };
  }
}
