import * as THREE from 'three';
import { GLTFLoader } from 'three/addons/loaders/GLTFLoader.js';
import { BikePhysics } from './BikePhysics';
import { ProceduralTextureSet } from './ProceduralTextures';
import { ControlInputs, EmoteId, GloveStyle } from './types';

const GROUND_OFFSET_Y = 0.112; // Shifts Ducati bottom tires to y=0
const RAKE_RAD = THREE.MathUtils.degToRad(24.5);

function smoothstep(edge0: number, edge1: number, x: number): number {
  const t = THREE.MathUtils.clamp((x - edge0) / (edge1 - edge0), 0, 1);
  return t * t * (3 - 2 * t);
}

export class BikeRig {
  public readonly root = new THREE.Group(); // World pos (rear ground contact), yaw
  public readonly leanPivot = new THREE.Group(); // Roll (leanAngle)
  public readonly pitchPivot = new THREE.Group(); // Wheelie/Stoppie pitch around rear contact
  public readonly chassisPivot = new THREE.Group(); // Suspension heave & chassis pitch
  public readonly steeringHeadPivot = new THREE.Group(); // Front steering axis (with rake)
  public readonly forkSlidePivot = new THREE.Group(); // Front wheel/fender suspension travel
  public readonly frontWheelSpinPivot = new THREE.Group(); // Front tire + disc spin
  public readonly swingarmPivot = new THREE.Group(); // Rear swingarm + fender
  public readonly rearWheelSpinPivot = new THREE.Group(); // Rear tire + disc spin

  public readonly leftGripTarget = new THREE.Object3D();
  public readonly rightGripTarget = new THREE.Object3D();
  public readonly headCamAnchor = new THREE.Object3D();
  public readonly footCamAnchor = new THREE.Object3D();

  private readonly scene: THREE.Scene;
  private readonly textures: ProceduralTextureSet;
  private readonly maxAnisotropy: number;
  private readonly contactShadowMesh: THREE.Mesh;
  private riderRoot = new THREE.Group();
  private bones = new Map<string, THREE.Bone>();
  private restQuats = new Map<string, THREE.Quaternion>();
  private restPositions = new Map<string, THREE.Vector3>();
  private vestMeshes: THREE.Object3D[] = [];
  private readonly gloveUniforms = {
    uGloveEnabled: { value: 1.0 },
    uGlovePrimary: { value: new THREE.Color(0x3d424d) },
    uGloveAccent: { value: new THREE.Color(0x6b7280) },
    uGloveMap: { value: null as THREE.Texture | null },
    uCarbonMap: { value: null as THREE.Texture | null },
  };
  private currentGloveStyle: GloveStyle = 'black';
  private neckBone: THREE.Bone | null = null;
  private headBone: THREE.Bone | null = null;

  // Reusable math scratch objects (zero per-frame GC)
  private readonly _vA = new THREE.Vector3();
  private readonly _vB = new THREE.Vector3();
  private readonly _vC = new THREE.Vector3();
  private readonly _vTarget = new THREE.Vector3();
  private readonly _vPole = new THREE.Vector3();
  private readonly _qWorld = new THREE.Quaternion();
  private readonly _qParent = new THREE.Quaternion();
  private readonly _qDelta = new THREE.Quaternion();
  private readonly _euler = new THREE.Euler();

  private readonly _ikToTarget = new THREE.Vector3();
  private readonly _ikDir = new THREE.Vector3();
  private readonly _ikToPole = new THREE.Vector3();
  private readonly _ikDesiredMid = new THREE.Vector3();
  private readonly _ikCurDir = new THREE.Vector3();
  private readonly _ikWantDir = new THREE.Vector3();
  private readonly _qSteer = new THREE.Quaternion();
  private readonly _qGrip = new THREE.Quaternion();
  private readonly _mBasis = new THREE.Matrix4();
  private readonly _vHX = new THREE.Vector3();
  private readonly _vHY = new THREE.Vector3();
  private readonly _vHZ = new THREE.Vector3();

  public fpCamDistance = 0; // -0.18 (mais perto) .. +0.24 (mais longe)
  private animTime = 0;
  private smoothThrottle = 0;
  private smoothFrontBrake = 0;
  private smoothClutch = 0;
  private smoothEmoteBlend = 0;
  private activeEmoteType: EmoteId = 'none';

  constructor(scene: THREE.Scene, textures: ProceduralTextureSet, maxAnisotropy = 4) {
    this.scene = scene;
    this.textures = textures;
    this.maxAnisotropy = maxAnisotropy;
    this.gloveUniforms.uGloveMap.value = textures.gloveMap;
    this.gloveUniforms.uCarbonMap.value = textures.carbonMap;
    const shadowGeo = new THREE.PlaneGeometry(1.65, 2.75);
    shadowGeo.rotateX(-Math.PI / 2);
    const shadowMat = new THREE.MeshBasicMaterial({
      map: textures.contactShadow,
      transparent: true,
      depthWrite: false,
      opacity: 0.72,
    });
    this.contactShadowMesh = new THREE.Mesh(shadowGeo, shadowMat);
    this.contactShadowMesh.position.y = 0.018;
    this.contactShadowMesh.rotation.y = Math.PI / 2;
    this.root.add(this.contactShadowMesh);

    this.pitchPivot.position.set(-0.734, 0, 0);
    this.chassisPivot.position.set(0.734, 0, 0);

    // Steering head at Ducati triple-clamp axis (ZYX order: tilt by RAKE first, then steer around fork axis!)
    this.steeringHeadPivot.position.set(0.49, 0.92, 0);
    this.steeringHeadPivot.rotation.order = 'ZYX';
    this.steeringHeadPivot.rotation.z = RAKE_RAD;

    const dxF = 0.762 - 0.49;
    const dyF = 0.301 - 0.92;
    const cosR = Math.cos(-RAKE_RAD);
    const sinR = Math.sin(-RAKE_RAD);
    this.frontWheelSpinPivot.position.set(
      dxF * cosR - dyF * sinR,
      dxF * sinR + dyF * cosR,
      0
    );

    this.swingarmPivot.position.set(-0.18, 0.38, 0);
    this.rearWheelSpinPivot.position.set(-0.734 - -0.18, 0.338 - 0.38, 0);

    // Measured Ducati Streetfighter rubber grip centers: (0.348, 1.008, ±0.368).
    // Palm center is ~0.068m past wrist bone -> wrist rests at (0.280, 1.022, ±0.352)
    // so forearm flows straight into hand and curled fingers wrap directly around the grip tube!
    const dxGL = 0.280 - 0.49;
    const dyGL = 1.022 - 0.92;
    const gxL = dxGL * cosR - dyGL * sinR;
    const gyL = dxGL * sinR + dyGL * cosR;
    this.leftGripTarget.position.set(gxL, gyL, -0.352);

    const dxGR = 0.280 - 0.49;
    const dyGR = 1.022 - 0.92;
    const gxR = dxGR * cosR - dyGR * sinR;
    const gyR = dxGR * sinR + dyGR * cosR;
    this.rightGripTarget.position.set(gxR, gyR, 0.352);

    this.root.add(this.leanPivot);
    this.leanPivot.add(this.pitchPivot);
    this.pitchPivot.add(this.chassisPivot);

    this.chassisPivot.add(this.steeringHeadPivot);
    this.steeringHeadPivot.add(this.forkSlidePivot);
    this.forkSlidePivot.add(this.frontWheelSpinPivot);
    this.steeringHeadPivot.add(this.leftGripTarget);
    this.steeringHeadPivot.add(this.rightGripTarget);

    this.chassisPivot.add(this.swingarmPivot);
    this.swingarmPivot.add(this.rearWheelSpinPivot);

    this.chassisPivot.add(this.riderRoot);
    this.headCamAnchor.position.set(0.05, 1.28, 0);
    this.chassisPivot.add(this.headCamAnchor);
    this.footCamAnchor.position.set(0, 1.56, 0.08);
    this.riderRoot.add(this.footCamAnchor);

    scene.add(this.root);
    this.root.updateMatrixWorld(true);
  }

  public async loadModels(
    onProgress: (percent: number, label: string) => void
  ): Promise<void> {
    const loader = new GLTFLoader();

    let bikePct = 0;
    let riderPct = 0;
    const report = (label: string) => {
      onProgress(Math.round((bikePct * 0.65 + riderPct * 0.35) * 100), label);
    };

    const loadGlb = (url: string, isBike: boolean) =>
      new Promise<any>((resolve, reject) => {
        loader.load(
          url,
          (gltf) => {
            if (isBike) bikePct = 1;
            else riderPct = 1;
            report(isBike ? 'Ducati carregada...' : 'Piloto carregado...');
            resolve(gltf);
          },
          (evt) => {
            if (evt.total > 0) {
              const p = Math.min(1, evt.loaded / evt.total);
              if (isBike) bikePct = p;
              else riderPct = p;
              report('Carregando modelos 3D...');
            }
          },
          reject
        );
      });

    report('Baixando Ducati V4 S e Piloto Brasileiro 3D...');
    const [bikeGltf, riderGltf] = await Promise.all([
      loadGlb('/models/ducati_v4s.glb', true),
      loadGlb('/models/rider_br.glb', false),
    ]);

    this.setupBikeModel(bikeGltf.scene);
    this.setupRiderModel(riderGltf.scene);
  }

  private setupBikeModel(bikeScene: THREE.Group): void {
    this.root.position.set(0, 0, 0);
    this.root.rotation.set(0, 0, 0);
    this.root.updateMatrixWorld(true);
    bikeScene.updateMatrixWorld(true);

    bikeScene.traverse((obj: any) => {
      if (obj.isMesh) {
        obj.castShadow = false;
        obj.receiveShadow = false;
        if (obj.material) {
          const mats = Array.isArray(obj.material) ? obj.material : [obj.material];
          for (const m of mats) {
            if (!m) continue;
            // Sharpen all Ducati textures at grazing angles (decals, dash, carbon, tires)
            for (const texKey of ['map', 'normalMap', 'roughnessMap', 'metalnessMap', 'aoMap', 'emissiveMap']) {
              const t = m[texKey];
              if (t) {
                t.anisotropy = this.maxAnisotropy;
                t.needsUpdate = true;
              }
            }

            if (m.transmission && m.transmission > 0) {
              m.transmission = 0;
              m.transparent = true;
              m.opacity = 0.34;
              m.roughness = 0.06;
              m.envMapIntensity = 1.45;
            } else if ((m.metalness ?? 0) >= 0.6) {
              // Chrome forks, exhaust headers, rotors & alloy with crisp reflections
              m.roughness = Math.max(0.10, (m.roughness ?? 0.25) * 0.80);
              m.envMapIntensity = 1.60;
            } else if ((m.roughness ?? 0.5) < 0.45) {
              // Glossy Ducati paint / lacquer sheen preserving original color & textures
              if ('clearcoat' in m) {
                m.clearcoat = Math.max(m.clearcoat ?? 0, 0.82);
                m.clearcoatRoughness = 0.09;
              }
              m.envMapIntensity = 1.38;
            } else {
              m.envMapIntensity = 1.05;
            }
          }
        }
      }
    });

    const groundShift = new THREE.Matrix4().makeTranslation(0, GROUND_OFFSET_Y, 0);
    const invPivot = new THREE.Matrix4();
    const localMat = new THREE.Matrix4();

    const attachToPivot = (nodeNamePrefix: string, pivot: THREE.Object3D) => {
      let targetNode: THREE.Object3D | null = null;
      bikeScene.traverse((o) => {
        if (!targetNode && o.name && o.name.startsWith(nodeNamePrefix)) {
          targetNode = o;
        }
      });
      if (!targetNode) return;

      const node = targetNode as THREE.Object3D;
      node.updateMatrixWorld(true);
      const worldMat = node.matrixWorld.clone().premultiply(groundShift);

      this.root.updateMatrixWorld(true);
      invPivot.copy(pivot.matrixWorld).invert();
      localMat.multiplyMatrices(invPivot, worldMat);

      pivot.add(node);
      node.matrixAutoUpdate = true;
      localMat.decompose(node.position, node.quaternion, node.scale);
    };

    attachToPivot('SM_Fork_', this.steeringHeadPivot);
    attachToPivot('SM_FrontKit_', this.steeringHeadPivot);

    attachToPivot('SM_Fender_F_', this.forkSlidePivot);
    attachToPivot('SM_Tire_F_', this.frontWheelSpinPivot);
    attachToPivot('SM_Disk_F_', this.frontWheelSpinPivot);

    attachToPivot('SM_Swingarm_', this.swingarmPivot);
    attachToPivot('SM_Fender_R_', this.swingarmPivot);
    attachToPivot('SM_Tire_R_', this.rearWheelSpinPivot);
    attachToPivot('SM_Disk_R_', this.rearWheelSpinPivot);

    attachToPivot('SM_Frame_', this.chassisPivot);
    attachToPivot('SM_Engine_', this.chassisPivot);
    attachToPivot('SM_Base_', this.chassisPivot);
    attachToPivot('SM_Exhaust_', this.chassisPivot);
    attachToPivot('SM_RearKit_', this.chassisPivot);
    attachToPivot('SM_Root_Ducati', this.chassisPivot);
  }

  /**
   * Procedurally builds an anatomical 19-bone skeleton & smooth vertex skinning
   * for rider_br.glb (brazilian_with_covid-19.glb) so it supports full Molejo,
   * glued hand IK, throttle twist animation, and clean 1st-person head hiding.
   */
  private setupRiderModel(riderScene: THREE.Group): void {
    riderScene.updateMatrixWorld(true);

    // 1. Create clean anatomical 21-bone hierarchy (including curled finger bones)
    const createBone = (name: string, parent: THREE.Object3D | null, wx: number, wy: number, wz: number, pwx = 0, pwy = 0, pwz = 0) => {
      const b = new THREE.Bone();
      b.name = name;
      b.position.set(wx - pwx, wy - pwy, wz - pwz);
      if (parent) parent.add(b);
      this.bones.set(name, b);
      this.restQuats.set(name, b.quaternion.clone());
      this.restPositions.set(name, b.position.clone());
      return b;
    };

    const hips = createBone('Hips', null, 0, 0.88, 0);
    const spine = createBone('Spine_', hips, 0, 1.03, -0.01, 0, 0.88, 0);
    const spine2 = createBone('Spine2_', spine, 0, 1.24, -0.02, 0, 1.03, -0.01);
    const neck = createBone('Neck_', spine2, 0, 1.44, -0.01, 0, 1.24, -0.02);
    const head = createBone('Head_', neck, 0, 1.54, 0.01, 0, 1.44, -0.01);
    this.neckBone = neck;
    this.headBone = head;

    const lShoulder = createBone('LeftShoulder_', spine2, 0.11, 1.36, -0.045, 0, 1.24, -0.02);
    const lArm = createBone('LeftArm_', lShoulder, 0.21, 1.365, -0.045, 0.11, 1.36, -0.045);
    const lFore = createBone('LeftForeArm_', lArm, 0.48, 1.358, -0.06, 0.21, 1.365, -0.045);
    const lHand = createBone('LeftHand_', lFore, 0.74, 1.348, -0.048, 0.48, 1.358, -0.06);
    const lFingers = createBone('LeftFingers_', lHand, 0.845, 1.345, -0.05, 0.74, 1.348, -0.048);

    const rShoulder = createBone('RightShoulder_', spine2, -0.11, 1.36, -0.045, 0, 1.24, -0.02);
    const rArm = createBone('RightArm_', rShoulder, -0.21, 1.365, -0.045, -0.11, 1.36, -0.045);
    const rFore = createBone('RightForeArm_', rArm, -0.48, 1.358, -0.06, -0.21, 1.365, -0.045);
    const rHand = createBone('RightHand_', rFore, -0.74, 1.348, -0.048, -0.48, 1.358, -0.06);
    const rFingers = createBone('RightFingers_', rHand, -0.845, 1.345, -0.05, -0.74, 1.348, -0.048);
    const rBrakeFingers = createBone('RightBrakeFingers_', rHand, -0.845, 1.345, -0.05, -0.74, 1.348, -0.048);

    const lUpLeg = createBone('LeftUpLeg_', hips, 0.095, 0.86, 0, 0, 0.88, 0);
    const lLeg = createBone('LeftLeg_', lUpLeg, 0.095, 0.48, 0.01, 0.095, 0.86, 0);
    const lFoot = createBone('LeftFoot_', lLeg, 0.095, 0.08, 0.01, 0.095, 0.48, 0.01);

    const rUpLeg = createBone('RightUpLeg_', hips, -0.095, 0.86, 0, 0, 0.88, 0);
    const rLeg = createBone('RightLeg_', rUpLeg, -0.095, 0.48, 0.01, -0.095, 0.86, 0);
    const rFoot = createBone('RightFoot_', rLeg, -0.095, 0.08, 0.01, -0.095, 0.48, 0.01);

    const boneList = [
      hips,
      spine,
      spine2,
      neck,
      head,
      lShoulder,
      lArm,
      lFore,
      lHand,
      rShoulder,
      rArm,
      rFore,
      rHand,
      lUpLeg,
      lLeg,
      lFoot,
      rUpLeg,
      rLeg,
      rFoot,
      lFingers,
      rFingers,
      rBrakeFingers,
    ];

    const B = {
      HIPS: 0,
      SPINE: 1,
      SPINE2: 2,
      NECK: 3,
      HEAD: 4,
      L_ARM: 6,
      L_FORE: 7,
      L_HAND: 8,
      R_ARM: 10,
      R_FORE: 11,
      R_HAND: 12,
      L_UPLEG: 13,
      L_LEG: 14,
      L_FOOT: 15,
      R_UPLEG: 16,
      R_LEG: 17,
      R_FOOT: 18,
      L_FINGERS: 19,
      R_FINGERS: 20,
      R_BRAKE_FINGERS: 21,
    };

    // Keep riderRoot at identity transform when creating Skeleton & binding SkinnedMeshes
    // so boneInverses and skinned.bindMatrix share the exact same coordinate frame!
    this.riderRoot.position.set(0, 0, 0);
    this.riderRoot.rotation.set(0, 0, 0);
    this.riderRoot.scale.setScalar(1);
    this.riderRoot.add(hips);
    this.riderRoot.updateMatrixWorld(true);

    const skeleton = new THREE.Skeleton(boneList);

    // 2. Bake cm->m transform & bind vertices smoothly to our 19 bones
    const scaleMat = new THREE.Matrix4().makeScale(0.01, 0.01, 0.01);
    const bakeMat = new THREE.Matrix4();
    const posVec = new THREE.Vector3();

    const sourceMeshes: THREE.Mesh[] = [];
    riderScene.traverse((obj: any) => {
      if (obj.isMesh) sourceMeshes.push(obj);
    });

    for (const src of sourceMeshes) {
      const geo = src.geometry.clone();
      bakeMat.multiplyMatrices(scaleMat, src.matrixWorld);
      geo.applyMatrix4(bakeMat);
      // Remove pre-baked vec4 tangents because bakeMat scales/rotates vertex coordinates
      if (geo.attributes.tangent) geo.deleteAttribute('tangent');

      const posAttr = geo.attributes.position as THREE.BufferAttribute;
      const count = posAttr.count;
      const skinIndices = new Uint16Array(count * 4);
      const skinWeights = new Float32Array(count * 4);
      const gloveData = new Float32Array(count * 4);
      let hasHandVerts = false;

      for (let i = 0; i < count; i++) {
        posVec.fromBufferAttribute(posAttr, i);
        const vx = posVec.x;
        const vy = posVec.y;
        const ax = Math.abs(vx);

        let b0 = B.SPINE2;
        let b1 = B.SPINE2;
        let w0 = 1;
        let w1 = 0;

        // 2D Glove mask & UV projection mapped cleanly onto the rider's actual sculpted hands
        if (ax > 0.705 && vy > 1.2 && vy < 1.52) {
          hasHandVerts = true;
          const gMask = smoothstep(0.705, 0.718, ax);
          const gU = (ax - 0.705) * 4.4;
          const gV = (posVec.z - -0.04) * 9.5;
          let gZone = 0.0;
          if (ax >= 0.712 && ax <= 0.742) {
            gZone = 0.35; // Wrist cuff band
          } else if (ax >= 0.794 && ax <= 0.834 && vy > 1.335 && posVec.z <= 0.008) {
            gZone = 0.85; // 2D Carbon knuckle bridge on back of hand
          }
          gloveData[i * 4] = gMask;
          gloveData[i * 4 + 1] = gU;
          gloveData[i * 4 + 2] = gV;
          gloveData[i * 4 + 3] = gZone;
        }

        // Arms (|x| > 0.202 excludes Object_3 backpack/vest trim at ±0.196)
        if (ax > 0.202 && vy > 1.2 && vy < 1.52) {
          const isLeft = vx > 0;
          const armB = isLeft ? B.L_ARM : B.R_ARM;
          const foreB = isLeft ? B.L_FORE : B.R_FORE;
          const handB = isLeft ? B.L_HAND : B.R_HAND;
          const isBrakeFinger = !isLeft && posVec.z <= -0.005 && posVec.z >= -0.048;
          const fingerB = isLeft ? B.L_FINGERS : isBrakeFinger ? B.R_BRAKE_FINGERS : B.R_FINGERS;

          if (ax < 0.25) {
            const t = smoothstep(0.202, 0.25, ax);
            b0 = B.SPINE2;
            b1 = armB;
            w0 = 1 - t;
            w1 = t;
          } else if (ax < 0.44) {
            b0 = armB;
            w0 = 1;
          } else if (ax < 0.52) {
            const t = smoothstep(0.44, 0.52, ax);
            b0 = armB;
            b1 = foreB;
            w0 = 1 - t;
            w1 = t;
          } else if (ax < 0.685) {
            b0 = foreB;
            w0 = 1;
          } else if (ax < 0.765) {
            const t = smoothstep(0.685, 0.765, ax);
            b0 = foreB;
            b1 = handB;
            w0 = 1 - t;
            w1 = t;
          } else if (ax < 0.83 || posVec.z > -0.005) {
            // Keep palm & thumb on hand bone
            b0 = handB;
            w0 = 1;
          } else if (ax < 0.865) {
            const t = smoothstep(0.83, 0.865, ax);
            b0 = handB;
            b1 = fingerB;
            w0 = 1 - t;
            w1 = t;
          } else {
            b0 = fingerB;
            w0 = 1;
          }
        } else if (vy < 0.89) {
          // Legs & Feet
          const isLeft = vx >= 0;
          const upB = isLeft ? B.L_UPLEG : B.R_UPLEG;
          const legB = isLeft ? B.L_LEG : B.R_LEG;
          const footB = isLeft ? B.L_FOOT : B.R_FOOT;

          if (vy > 0.81) {
            const t = smoothstep(0.81, 0.89, vy);
            b0 = upB;
            b1 = B.HIPS;
            w0 = 1 - t;
            w1 = t;
          } else if (vy > 0.53) {
            b0 = upB;
            w0 = 1;
          } else if (vy > 0.43) {
            const t = smoothstep(0.43, 0.53, vy);
            b0 = legB;
            b1 = upB;
            w0 = 1 - t;
            w1 = t;
          } else if (vy > 0.13) {
            b0 = legB;
            w0 = 1;
          } else if (vy > 0.06) {
            const t = smoothstep(0.06, 0.13, vy);
            b0 = footB;
            b1 = legB;
            w0 = 1 - t;
            w1 = t;
          } else {
            b0 = footB;
            w0 = 1;
          }
        } else {
          // Torso, Neck & Head
          if (vy < 0.97) {
            const t = smoothstep(0.89, 0.97, vy);
            b0 = B.HIPS;
            b1 = B.SPINE;
            w0 = 1 - t;
            w1 = t;
          } else if (vy < 1.15) {
            const t = smoothstep(0.97, 1.15, vy);
            b0 = B.SPINE;
            b1 = B.SPINE2;
            w0 = 1 - t;
            w1 = t;
          } else if (vy < 1.38) {
            b0 = B.SPINE2;
            w0 = 1;
          } else if (vy < 1.44) {
            const t = smoothstep(1.38, 1.44, vy);
            b0 = B.SPINE2;
            b1 = B.NECK;
            w0 = 1 - t;
            w1 = t;
          } else if (vy < 1.462) {
            const t = smoothstep(1.44, 1.462, vy);
            b0 = B.NECK;
            b1 = B.HEAD;
            w0 = 1 - t;
            w1 = t;
          } else {
            b0 = B.HEAD;
            w0 = 1;
          }
        }

        skinIndices[i * 4] = b0;
        skinIndices[i * 4 + 1] = b1;
        skinWeights[i * 4] = w0;
        skinWeights[i * 4 + 1] = w1;
      }

      geo.setAttribute('skinIndex', new THREE.Uint16BufferAttribute(skinIndices, 4));
      geo.setAttribute('skinWeight', new THREE.Float32BufferAttribute(skinWeights, 4));
      geo.setAttribute('aGloveData', new THREE.Float32BufferAttribute(gloveData, 4));

      let meshMat: THREE.Material | THREE.Material[] = src.material;
      if (hasHandVerts) {
        const baseMat = Array.isArray(src.material) ? src.material[0] : src.material;
        const cloned = baseMat.clone() as THREE.MeshStandardMaterial;
        cloned.envMapIntensity = 0.85;
        cloned.customProgramCacheKey = () => 'rider_glove_2d_v1';
        cloned.onBeforeCompile = (shader) => {
          shader.uniforms.uGloveEnabled = this.gloveUniforms.uGloveEnabled;
          shader.uniforms.uGlovePrimary = this.gloveUniforms.uGlovePrimary;
          shader.uniforms.uGloveAccent = this.gloveUniforms.uGloveAccent;
          shader.uniforms.uGloveMap = this.gloveUniforms.uGloveMap;
          shader.uniforms.uCarbonMap = this.gloveUniforms.uCarbonMap;

          shader.vertexShader = shader.vertexShader
            .replace(
              '#include <common>',
              '#include <common>\nattribute vec4 aGloveData;\nvarying vec4 vGloveData;'
            )
            .replace('#include <begin_vertex>', '#include <begin_vertex>\nvGloveData = aGloveData;');

          shader.fragmentShader = shader.fragmentShader
            .replace(
              '#include <common>',
              `#include <common>
uniform float uGloveEnabled;
uniform vec3 uGlovePrimary;
uniform vec3 uGloveAccent;
uniform sampler2D uGloveMap;
uniform sampler2D uCarbonMap;
varying vec4 vGloveData;`
            )
            .replace(
              '#include <map_fragment>',
              `#include <map_fragment>
if (uGloveEnabled > 0.5 && vGloveData.x > 0.01) {
  float gMask = smoothstep(0.05, 0.95, vGloveData.x);
  vec2 gUv = vec2(vGloveData.y * 1.45, vGloveData.z * 0.55 + 0.5);
  vec3 aiTex = pow(max(texture2D(uGloveMap, gUv).rgb, vec3(0.0)), vec3(2.2));
  vec3 carbTex = pow(max(texture2D(uCarbonMap, gUv * 2.5).rgb, vec3(0.0)), vec3(2.2));

  float isCuff = smoothstep(0.15, 0.45, vGloveData.w) * (1.0 - smoothstep(0.55, 0.75, vGloveData.w));
  float isKnuckle = smoothstep(0.65, 0.92, vGloveData.w);

  vec3 leatherColor = aiTex * uGlovePrimary * 1.68;
  vec3 cuffColor = aiTex * uGloveAccent * 1.50;
  vec3 knuckleColor = mix(carbTex * 0.75, uGloveAccent * 0.45, 0.22);

  vec3 gloveCol = mix(leatherColor, cuffColor, isCuff);
  gloveCol = mix(gloveCol, knuckleColor, isKnuckle);
  diffuseColor.rgb = mix(diffuseColor.rgb, gloveCol, gMask);
}`
            )
            .replace(
              '#include <roughnessmap_fragment>',
              `#include <roughnessmap_fragment>
if (uGloveEnabled > 0.5 && vGloveData.x > 0.01) {
  roughnessFactor = mix(roughnessFactor, 0.44, vGloveData.x);
}`
            );
        };
        meshMat = cloned;
      } else {
        const mats = Array.isArray(src.material) ? src.material : [src.material];
        for (const m of mats) {
          if (m) (m as any).envMapIntensity = 0.85;
        }
      }

      const skinned = new THREE.SkinnedMesh(geo, meshMat);
      skinned.castShadow = false;
      skinned.receiveShadow = false;
      skinned.frustumCulled = false;
      this.riderRoot.add(skinned);
      skinned.bind(skeleton);

      // Hide backpack/vest trim (Object_3) in 1st-person so it never blocks the visor view
      if (src.name === 'Object_3') {
        this.vestMeshes.push(skinned);
      }
    }

    this.setGloveStyle(this.currentGloveStyle);

    // Apply riding orientation (+Z forward -> +X bike forward) & scale ONLY after binding!
    this.riderRoot.rotation.y = Math.PI / 2;
    this.riderRoot.scale.setScalar(0.96);
    this.riderRoot.updateMatrixWorld(true);
  }

  public setGloveStyle(style: GloveStyle): void {
    this.currentGloveStyle = style;
    const visible = style !== 'none';
    this.gloveUniforms.uGloveEnabled.value = visible ? 1.0 : 0.0;
    if (!visible) return;

    if (style === 'black') {
      this.gloveUniforms.uGlovePrimary.value.setHex(0x3d424d);
      this.gloveUniforms.uGloveAccent.value.setHex(0x6b7280);
    } else if (style === 'ducati_red') {
      this.gloveUniforms.uGlovePrimary.value.setHex(0xdc2626);
      this.gloveUniforms.uGloveAccent.value.setHex(0x2d313a);
    } else if (style === 'white') {
      this.gloveUniforms.uGlovePrimary.value.setHex(0xf3f5f8);
      this.gloveUniforms.uGloveAccent.value.setHex(0xdc2626);
    }
  }

  private findBone(name: string): THREE.Bone | undefined {
    return this.bones.get(name);
  }

  public setFirstPersonMode(isFirstPerson: boolean, isOnFoot = false): void {
    const s = isFirstPerson ? 0.0001 : 1;
    if (this.neckBone) {
      // Collapse neck/chin/mask/head/cap cleanly inside upper collar in 1st person
      this.neckBone.scale.setScalar(s);
    }
    if (this.headBone) {
      this.headBone.scale.setScalar(s);
    }
    for (const m of this.vestMeshes) {
      // Keep full vest/torso visible when walking outside the bike in 1st-person!
      m.visible = !isFirstPerson || isOnFoot;
    }
  }

  public attachRiderToBike(onBike: boolean): void {
    if (onBike) {
      if (this.riderRoot.parent !== this.chassisPivot) {
        this.chassisPivot.add(this.riderRoot);
        this.riderRoot.rotation.set(0, Math.PI / 2, 0);
        this.riderRoot.scale.setScalar(0.96);
      }
    } else if (this.riderRoot.parent !== this.scene) {
      this.scene.add(this.riderRoot);
      this.riderRoot.scale.setScalar(0.96);
    }
  }

  public getLeftStandWorldPos(out: THREE.Vector3): THREE.Vector3 {
    this.root.updateMatrixWorld(true);
    out.set(-0.14, 0, -0.58);
    return this.chassisPivot.localToWorld(out);
  }

  private updateBikeTransforms(physics: BikePhysics): void {
    this.root.position.copy(physics.pos);
    this.root.rotation.set(0, physics.yaw, 0);

    this.leanPivot.rotation.x = physics.leanAngle + physics.whipAngle;
    this.pitchPivot.rotation.z = physics.wheeliePitch;

    const rearDrop = physics.rearSusp;
    const frontDrop = physics.frontSusp;
    const avgDrop = (rearDrop + frontDrop) * 0.5;
    this.chassisPivot.position.y = -avgDrop * 0.72;
    this.chassisPivot.rotation.z = (rearDrop - frontDrop) * 0.25;

    this.steeringHeadPivot.rotation.y = physics.steerAngle;
    this.forkSlidePivot.position.y = THREE.MathUtils.clamp((frontDrop - 0.032) * 0.55, -0.025, 0.045);
    this.swingarmPivot.rotation.z = (rearDrop - 0.035) * 0.35;

    this.frontWheelSpinPivot.rotation.z = -physics.wheelSpinFront;
    this.rearWheelSpinPivot.rotation.z = -physics.wheelSpinRear;

    const shadowFade = THREE.MathUtils.clamp(1 - physics.wheeliePitch * 0.35, 0.35, 0.78);
    (this.contactShadowMesh.material as THREE.MeshBasicMaterial).opacity = physics.isAirborne
      ? 0.22
      : shadowFade;
    this.contactShadowMesh.position.x = THREE.MathUtils.clamp(
      -Math.sin(physics.wheeliePitch) * 0.45,
      -0.6,
      0.2
    );

    this.root.updateMatrixWorld(true);
  }

  public update(
    physics: BikePhysics,
    isFirstPerson: boolean,
    dt = 0.016,
    inputs?: ControlInputs
  ): void {
    this.animTime += dt;
    this.smoothThrottle = THREE.MathUtils.damp(this.smoothThrottle, inputs?.throttle ?? 0, 9, dt);
    this.smoothFrontBrake = THREE.MathUtils.damp(this.smoothFrontBrake, inputs?.frontBrake ?? 0, 12, dt);
    this.smoothClutch = THREE.MathUtils.damp(this.smoothClutch, inputs?.clutch ? 1 : 0, 14, dt);
    const reqEmote = inputs?.emote && inputs.emote !== 'none' ? inputs.emote : inputs?.noHand ? 'salve' : 'none';
    if (reqEmote !== 'none') {
      this.activeEmoteType = reqEmote;
    }
    this.smoothEmoteBlend = THREE.MathUtils.damp(
      this.smoothEmoteBlend,
      reqEmote !== 'none' ? 1 : 0,
      8.5,
      dt
    );
    if (this.smoothEmoteBlend < 0.01 && reqEmote === 'none') {
      this.activeEmoteType = 'none';
    }
    this.attachRiderToBike(true);
    this.setFirstPersonMode(isFirstPerson);
    this.updateBikeTransforms(physics);
    this.updateRiderPose(physics, isFirstPerson, inputs);
  }

  /**
   * Procedural Dismount / Mount leg-swing animation (t = 0 mounted -> t = 1 standing beside left side)
   */
  public updateTransition(
    physics: BikePhysics,
    t: number,
    isFirstPerson: boolean,
    dt = 0.016
  ): void {
    this.animTime += dt;
    this.attachRiderToBike(true);
    this.setFirstPersonMode(isFirstPerson, t > 0.45);
    this.updateBikeTransforms(physics);

    const hips = this.findBone('Hips');
    const spine = this.findBone('Spine_');
    const spine2 = this.findBone('Spine2_');
    const neck = this.findBone('Neck_');
    const head = this.findBone('Head_');
    if (!hips) return;

    for (const [name, q] of this.restQuats) {
      const b = this.bones.get(name);
      if (b) {
        b.quaternion.copy(q);
        const rp = this.restPositions.get(name);
        if (rp) b.position.copy(rp);
      }
    }

    const sHands = smoothstep(0.0, 0.38, t);
    const sHip = smoothstep(0.08, 0.90, t);
    const sLegSwing = smoothstep(0.18, 0.84, t);
    const sLegArc = Math.sin(sLegSwing * Math.PI);

    // Smoothly slide rider off the left side and rise to exact standing hip height (0.845m)
    const hipX = THREE.MathUtils.lerp(-0.19, -0.14, sHip);
    const hipY = THREE.MathUtils.lerp(0.785, 0.845, sHip) + sLegArc * 0.035;
    const hipZ = THREE.MathUtils.lerp(0, -0.58, sHip);
    this.riderRoot.position.set(hipX, hipY, hipZ);
    hips.position.set(0, 0, 0);

    const pelvisPitch = THREE.MathUtils.lerp(0.15, 0.02, sHip);
    const torsoCurve = THREE.MathUtils.lerp(0.24, 0.03, sHip);
    this.applyLocalEuler(hips, pelvisPitch, -sLegArc * 0.24, sLegArc * 0.14);
    if (spine) this.applyLocalEuler(spine, torsoCurve * 0.45, 0, 0);
    if (spine2) this.applyLocalEuler(spine2, torsoCurve * 0.55, 0, 0);
    if (neck) this.applyLocalEuler(neck, -(pelvisPitch + torsoCurve) * 0.42, sLegArc * 0.14, 0);
    if (head) this.applyLocalEuler(head, -(pelvisPitch + torsoCurve) * 0.38, 0, 0);

    const lShoulder = this.findBone('LeftShoulder_');
    const rShoulder = this.findBone('RightShoulder_');
    if (lShoulder) this.applyLocalEuler(lShoulder, 0.06 * (1 - sHands), -0.12 * (1 - sHands), -0.08);
    if (rShoulder) this.applyLocalEuler(rShoulder, 0.06 * (1 - sHands), 0.12 * (1 - sHands), 0.08);

    const lUpLeg = this.findBone('LeftUpLeg_');
    const lLeg = this.findBone('LeftLeg_');
    const lFoot = this.findBone('LeftFoot_');
    const rUpLeg = this.findBone('RightUpLeg_');
    const rLeg = this.findBone('RightLeg_');
    const rFoot = this.findBone('RightFoot_');

    if (lUpLeg) this.applyLocalEuler(lUpLeg, -0.65 * (1 - sHip), 0, -0.08);
    if (lLeg) this.applyLocalEuler(lLeg, 0.85 * (1 - sHip), 0, 0);
    if (rUpLeg) this.applyLocalEuler(rUpLeg, -0.65 * (1 - sHip) - sLegArc * 0.45, 0, 0.08);
    if (rLeg) this.applyLocalEuler(rLeg, 0.85 * (1 - sHip) + sLegArc * 0.65, 0, 0);

    this.root.updateMatrixWorld(true);

    // Smooth helmet eye transition for 1st-person mode
    this.headCamAnchor.position.set(
      THREE.MathUtils.lerp(0.03, -0.06, sHip),
      THREE.MathUtils.lerp(1.345, 1.50, sHip),
      THREE.MathUtils.lerp(0, -0.58, sHip)
    );
    this.headCamAnchor.updateMatrixWorld(true);

    // Left leg steps cleanly onto ground beside bike
    if (lUpLeg && lLeg && lFoot) {
      this._vTarget.set(
        THREE.MathUtils.lerp(-0.227, -0.14, sHip),
        THREE.MathUtils.lerp(0.33, 0.08, smoothstep(0.05, 0.55, t)),
        THREE.MathUtils.lerp(-0.205, -0.47, sHip)
      );
      this.chassisPivot.localToWorld(this._vTarget);
      this._vPole.set(
        THREE.MathUtils.lerp(0.34, 0.15, sHip),
        THREE.MathUtils.lerp(0.56, 0.46, sHip),
        THREE.MathUtils.lerp(-0.36, -0.49, sHip)
      );
      this.chassisPivot.localToWorld(this._vPole);
      this.solveTwoBoneIK(lUpLeg, lLeg, lFoot, this._vTarget, this._vPole);
      this.alignFootToPeg(lFoot, THREE.MathUtils.lerp(-0.12, -0.04, sHip));
    }

    // Right leg arcs up and over the Ducati tail seat cleanly!
    if (rUpLeg && rLeg && rFoot) {
      const rFootX = THREE.MathUtils.lerp(-0.231, -0.14, sLegSwing) - sLegArc * 0.34;
      const rFootY = THREE.MathUtils.lerp(0.335, 0.08, sLegSwing) + sLegArc * 0.82;
      const rFootZ = THREE.MathUtils.lerp(0.207, -0.68, sLegSwing);
      this._vTarget.set(rFootX, rFootY, rFootZ);
      this.chassisPivot.localToWorld(this._vTarget);
      this._vPole.set(
        THREE.MathUtils.lerp(0.34, 0.15, sLegSwing) - sLegArc * 0.12,
        THREE.MathUtils.lerp(0.56, 0.46, sLegSwing) + sLegArc * 0.55,
        THREE.MathUtils.lerp(0.36, -0.70, sLegSwing)
      );
      this.chassisPivot.localToWorld(this._vPole);
      this.solveTwoBoneIK(rUpLeg, rLeg, rFoot, this._vTarget, this._vPole);
      this.alignFootToPeg(rFoot, THREE.MathUtils.lerp(0.12, 0.04, sLegSwing));
    }

    // Arms release grips and lower smoothly to rider's sides
    const lArm = this.findBone('LeftArm_');
    const lFore = this.findBone('LeftForeArm_');
    const lHand = this.findBone('LeftHand_');
    const lFingers = this.findBone('LeftFingers_');
    const rArm = this.findBone('RightArm_');
    const rFore = this.findBone('RightForeArm_');
    const rHand = this.findBone('RightHand_');
    const rFingers = this.findBone('RightFingers_');
    const rBrakeFingers = this.findBone('RightBrakeFingers_');

    const gripWeight = 1 - smoothstep(0.04, 0.48, t);
    if (rArm && rFore && rHand) {
      this.rightGripTarget.getWorldPosition(this._vTarget);
      this._vA.set(-0.08, 0.84, -0.80);
      this.chassisPivot.localToWorld(this._vA);
      this._vTarget.lerp(this._vA, sHands);
      this._vPole.set(
        THREE.MathUtils.lerp(0.045, -0.14, sHands),
        THREE.MathUtils.lerp(1.105, 1.02, sHands),
        THREE.MathUtils.lerp(0.375, -0.82, sHands)
      );
      this.chassisPivot.localToWorld(this._vPole);
      this.solveArmIK(rArm, rFore, rHand, this._vTarget, this._vPole, 'right');
      this.alignHandToGrip(rHand, 'right', 0, 0, gripWeight);
      this.twistForearmToHand(rFore, rHand, 0.22 * gripWeight);
      if (rFingers) {
        rFingers.rotation.set(0, 0, 1.5 * gripWeight + 0.25 * (1 - gripWeight));
        rFingers.updateMatrixWorld(true);
      }
      if (rBrakeFingers) {
        rBrakeFingers.rotation.set(0, 0, 1.5 * gripWeight + 0.25 * (1 - gripWeight));
        rBrakeFingers.updateMatrixWorld(true);
      }
    }

    if (lArm && lFore && lHand) {
      this.leftGripTarget.getWorldPosition(this._vTarget);
      this._vA.set(-0.08, 0.84, -0.36);
      this.chassisPivot.localToWorld(this._vA);
      this._vTarget.lerp(this._vA, sHands);
      this._vPole.set(
        THREE.MathUtils.lerp(0.075, -0.14, sHands),
        THREE.MathUtils.lerp(1.06, 1.02, sHands),
        THREE.MathUtils.lerp(-0.49, -0.34, sHands)
      );
      this.chassisPivot.localToWorld(this._vPole);
      this.solveArmIK(lArm, lFore, lHand, this._vTarget, this._vPole, 'left');
      this.alignHandToGrip(lHand, 'left', 0, 0, gripWeight);
      this.twistForearmToHand(lFore, lHand, 0.22 * gripWeight);
      if (lFingers) {
        lFingers.rotation.set(0, 0, -1.5 * gripWeight - 0.25 * (1 - gripWeight));
        lFingers.updateMatrixWorld(true);
      }
    }
  }

  /**
   * Free-roam On-Foot walking / running / jumping / Salve animation across the city
   */
  public updateOnFoot(
    physics: BikePhysics,
    worldPos: THREE.Vector3,
    yaw: number,
    speed: number,
    isAirborne: boolean,
    walkPhase: number,
    emote: EmoteId | boolean,
    isFirstPerson: boolean,
    dt = 0.016
  ): void {
    this.animTime += dt;
    const activeEmote: EmoteId =
      typeof emote === 'boolean' ? (emote ? 'salve' : 'none') : emote;
    if (activeEmote !== 'none') {
      this.activeEmoteType = activeEmote;
    }
    this.smoothEmoteBlend = THREE.MathUtils.damp(
      this.smoothEmoteBlend,
      activeEmote !== 'none' ? 1 : 0,
      9.5,
      dt
    );
    if (this.smoothEmoteBlend < 0.01 && activeEmote === 'none') {
      this.activeEmoteType = 'none';
    }

    this.updateBikeTransforms(physics);
    this.attachRiderToBike(false);
    this.setFirstPersonMode(isFirstPerson, true);

    this.riderRoot.position.copy(worldPos);
    this.riderRoot.rotation.set(0, yaw + Math.PI / 2, 0);

    const hips = this.findBone('Hips');
    const spine = this.findBone('Spine_');
    const spine2 = this.findBone('Spine2_');
    const neck = this.findBone('Neck_');
    const head = this.findBone('Head_');
    if (!hips) return;

    for (const [name, q] of this.restQuats) {
      const b = this.bones.get(name);
      if (b) {
        b.quaternion.copy(q);
        const rp = this.restPositions.get(name);
        if (rp) b.position.copy(rp);
      }
    }

    const walkBlend = THREE.MathUtils.clamp(speed / 2.6, 0, 1);
    const jogBlend = THREE.MathUtils.clamp((speed - 3.1) / 2.8, 0, 1);
    const breath = Math.sin(this.animTime * 2.1) * 0.014;
    const idleShift = (1 - walkBlend) * Math.sin(this.animTime * 0.9) * 0.015;

    // Natural double-frequency center-of-mass stride bounce + lateral stance-leg weight shift
    const strideBob =
      (-Math.cos(walkPhase * 2) * 0.5 + 0.5) * (0.036 * walkBlend + 0.034 * jogBlend);
    const bob = isAirborne ? 0.03 : strideBob;
    const hipLatShift = isAirborne
      ? 0
      : Math.sin(walkPhase) * 0.022 * walkBlend * (1 - 0.35 * jogBlend) + idleShift * 0.4;
    const hipRoll = isAirborne ? 0 : Math.cos(walkPhase) * 0.042 * walkBlend;
    const pelvisYaw = isAirborne ? 0 : -Math.sin(walkPhase) * (0.095 * walkBlend + 0.035 * jogBlend);
    const forwardLean = 0.035 + walkBlend * 0.05 + jogBlend * 0.12;

    hips.position.y += bob;
    hips.position.x += hipLatShift;
    this.applyLocalEuler(hips, forwardLean, pelvisYaw, hipRoll + idleShift * 0.3);
    if (spine) {
      this.applyLocalEuler(
        spine,
        0.025 + walkBlend * 0.04 + jogBlend * 0.08 + breath,
        -pelvisYaw * 0.65,
        -hipRoll * 0.6
      );
    }
    if (spine2) {
      this.applyLocalEuler(
        spine2,
        0.02 + walkBlend * 0.04 + jogBlend * 0.06 + breath * 0.8,
        -pelvisYaw * 0.65,
        -hipRoll * 0.25
      );
    }
    if (neck) this.applyLocalEuler(neck, -forwardLean * 0.52, pelvisYaw * 0.2, 0);
    if (head) {
      this.applyLocalEuler(
        head,
        -forwardLean * 0.42 + Math.sin(this.animTime * 1.35) * 0.012,
        idleShift * 1.4,
        0
      );
    }

    const lShoulder = this.findBone('LeftShoulder_');
    const rShoulder = this.findBone('RightShoulder_');
    if (lShoulder) this.applyLocalEuler(lShoulder, 0.02, -pelvisYaw * 0.35, -0.065);
    if (rShoulder) this.applyLocalEuler(rShoulder, 0.02, -pelvisYaw * 0.35, 0.065);

    // 4-phase natural human gait: hip stride + asymmetric knee flexion + heel-strike / toe-off roll
    const lUpLeg = this.findBone('LeftUpLeg_');
    const lLeg = this.findBone('LeftLeg_');
    const lFoot = this.findBone('LeftFoot_');
    const rUpLeg = this.findBone('RightUpLeg_');
    const rLeg = this.findBone('RightLeg_');
    const rFoot = this.findBone('RightFoot_');

    const computeLegAngles = (phase: number) => {
      const hipSwing = -Math.sin(phase) * (0.48 * walkBlend + 0.26 * jogBlend);
      const swingKnee = Math.max(0, Math.cos(phase - 0.35)) * (0.72 * walkBlend + 0.45 * jogBlend);
      const stanceKnee = Math.max(0, -Math.sin(phase - 0.2)) * 0.14 * walkBlend;
      const knee = 0.06 + swingKnee + stanceKnee;
      const heelUp = -Math.max(0, Math.sin(phase + 0.42)) * 0.25 * walkBlend;
      const toePush = Math.max(0, -Math.sin(phase - 0.55)) * 0.35 * walkBlend;
      const foot = heelUp + toePush - knee * 0.22;
      return { hipSwing, knee, foot };
    };

    const legL = computeLegAngles(walkPhase);
    const legR = computeLegAngles(walkPhase + Math.PI);

    if (lUpLeg) this.applyLocalEuler(lUpLeg, isAirborne ? -0.45 : legL.hipSwing, 0, -0.025);
    if (lLeg) this.applyLocalEuler(lLeg, isAirborne ? 0.62 : legL.knee, 0, 0);
    if (lFoot) this.applyLocalEuler(lFoot, isAirborne ? 0.25 : legL.foot, 0, 0);

    if (rUpLeg) this.applyLocalEuler(rUpLeg, isAirborne ? -0.25 : legR.hipSwing, 0, 0.025);
    if (rLeg) this.applyLocalEuler(rLeg, isAirborne ? 0.36 : legR.knee, 0, 0);
    if (rFoot) this.applyLocalEuler(rFoot, isAirborne ? 0.20 : legR.foot, 0, 0);

    // Twist-free sagittal arm swing (rx rotates in parent shoulder plane so arms never corkscrew!)
    const lArm = this.findBone('LeftArm_');
    const lFore = this.findBone('LeftForeArm_');
    const lHand = this.findBone('LeftHand_');
    const lFingers = this.findBone('LeftFingers_');
    const rArm = this.findBone('RightArm_');
    const rFore = this.findBone('RightForeArm_');
    const rHand = this.findBone('RightHand_');
    const rFingers = this.findBone('RightFingers_');
    const rBrakeFingers = this.findBone('RightBrakeFingers_');

    const armAmp = 0.38 * walkBlend + 0.26 * jogBlend;
    const armPhase = Math.sin(walkPhase);
    const leftArmPitch = armPhase * armAmp; // +rx = backward when left leg steps forward
    const rightArmPitch = -armPhase * armAmp; // -rx = forward opposite left leg
    const fwdLeft = Math.max(0, -armPhase);
    const fwdRight = Math.max(0, armPhase);
    const elbowFlexL = 0.16 + 0.14 * walkBlend + 0.56 * jogBlend + fwdLeft * (0.30 + 0.25 * jogBlend);
    const elbowFlexR = 0.16 + 0.14 * walkBlend + 0.56 * jogBlend + fwdRight * (0.30 + 0.25 * jogBlend);

    if (lArm) {
      this.applyLocalEuler(lArm, leftArmPitch, -0.05, -1.36 + walkBlend * 0.05);
    }
    if (lFore) this.applyLocalEuler(lFore, 0, -elbowFlexL, 0);
    if (lFingers) lFingers.rotation.set(0, 0, -0.34);

    if (rArm) {
      this.applyLocalEuler(rArm, rightArmPitch, 0.05, 1.36 - walkBlend * 0.05);
    }
    if (rFore) this.applyLocalEuler(rFore, 0, elbowFlexR, 0);
    if (rFingers) rFingers.rotation.set(0, 0, 0.34);
    if (rBrakeFingers) rBrakeFingers.rotation.set(0, 0, 0.34);

    this.riderRoot.updateMatrixWorld(true);

    // Solve clean anatomical Emotes on-foot using solveArmIK
    if (this.smoothEmoteBlend > 0.02 && this.activeEmoteType !== 'none') {
      const em = this.activeEmoteType;
      const eb = this.smoothEmoteBlend;
      const tAnim = this.animTime;
      const dualArm = em === 'celebrate' || em === 'flex' || em === 'clap';

      if (lArm && lFore && lHand) {
        let lx = 0.32;
        let ly = 1.62;
        let lz = 0.16;
        let lpx = 0.44;
        let lpy = 1.24;
        let lpz = 0.04;

        if (em === 'salve') {
          lx = 0.30 + Math.sin(tAnim * 7.5) * 0.12;
          ly = 1.68 + Math.cos(tAnim * 7.5) * 0.03;
          lz = 0.18;
          lpx = 0.46;
          lpy = 1.28;
          lpz = 0.06;
        } else if (em === 'hang_loose') {
          lx = 0.50;
          ly = 1.34 + Math.sin(tAnim * 5.2) * 0.08;
          lz = 0.24;
          lpx = 0.34;
          lpy = 1.12;
          lpz = -0.08;
        } else if (em === 'salute') {
          lx = 0.16;
          ly = 1.56;
          lz = 0.14;
          lpx = 0.48;
          lpy = 1.32;
          lpz = 0.12;
        } else if (em === 'flex') {
          lx = 0.28;
          ly = 1.54 + Math.sin(tAnim * 6.0) * 0.03;
          lz = 0.14;
          lpx = 0.48;
          lpy = 1.22;
          lpz = 0.08;
        } else if (em === 'celebrate') {
          lx = 0.36;
          ly = 1.76 + Math.sin(tAnim * 7.0) * 0.05;
          lz = 0.12;
          lpx = 0.44;
          lpy = 1.44;
          lpz = 0.02;
        } else if (em === 'clap') {
          const clapCycle = Math.abs(Math.sin(tAnim * 8.5));
          lx = 0.04 + clapCycle * 0.14;
          ly = 1.20;
          lz = 0.34;
          lpx = 0.36;
          lpy = 1.05;
          lpz = 0.12;
        }

        lHand.getWorldPosition(this._vC);
        this._vTarget.set(lx, ly + bob, lz);
        this.riderRoot.localToWorld(this._vTarget);
        this._vTarget.lerpVectors(this._vC, this._vTarget, eb);
        this._vPole.set(lpx, lpy + bob, lpz);
        this.riderRoot.localToWorld(this._vPole);
        this.solveArmIK(lArm, lFore, lHand, this._vTarget, this._vPole, 'left');
        if (lFingers) {
          lFingers.rotation.set(0, 0, em === 'flex' ? -1.4 : -0.2);
          lFingers.updateMatrixWorld(true);
        }
      }

      if (dualArm && rArm && rFore && rHand) {
        let rx = -0.28;
        let ry = 1.54;
        let rz = 0.14;
        let rpx = -0.48;
        let rpy = 1.22;
        let rpz = 0.08;

        if (em === 'celebrate') {
          rx = -0.36;
          ry = 1.76 + Math.sin(tAnim * 7.0 + 0.4) * 0.05;
          rz = 0.12;
          rpx = -0.44;
          rpy = 1.44;
          rpz = 0.02;
        } else if (em === 'clap') {
          const clapCycle = Math.abs(Math.sin(tAnim * 8.5));
          rx = -0.04 - clapCycle * 0.14;
          ry = 1.20;
          rz = 0.34;
          rpx = -0.36;
          rpy = 1.05;
          rpz = 0.12;
        } else if (em === 'flex') {
          ry = 1.54 + Math.sin(tAnim * 6.0) * 0.03;
        }

        rHand.getWorldPosition(this._vC);
        this._vTarget.set(rx, ry + bob, rz);
        this.riderRoot.localToWorld(this._vTarget);
        this._vTarget.lerpVectors(this._vC, this._vTarget, eb);
        this._vPole.set(rpx, rpy + bob, rpz);
        this.riderRoot.localToWorld(this._vPole);
        this.solveArmIK(rArm, rFore, rHand, this._vTarget, this._vPole, 'right');
        const curl = em === 'flex' ? 1.4 : 0.2;
        if (rFingers) {
          rFingers.rotation.set(0, 0, curl);
          rFingers.updateMatrixWorld(true);
        }
        if (rBrakeFingers) {
          rBrakeFingers.rotation.set(0, 0, curl);
          rBrakeFingers.updateMatrixWorld(true);
        }
      }
    }

    // Position 1st-person eye camera just above collar & slightly back so torso, swinging arms, legs & feet stay in view
    this.footCamAnchor.position.set(hipLatShift * 0.45, 1.535 + bob, 0.018);
    this.riderRoot.updateMatrixWorld(true);
  }

  private updateRiderPose(
    physics: BikePhysics,
    isFirstPerson: boolean,
    inputs?: ControlInputs
  ): void {
    const hips = this.findBone('Hips');
    const spine = this.findBone('Spine_');
    const spine2 = this.findBone('Spine2_');
    const neck = this.findBone('Neck_');
    const head = this.findBone('Head_');

    if (!hips) return;

    for (const [name, q] of this.restQuats) {
      const b = this.bones.get(name);
      if (b) {
        b.quaternion.copy(q);
        const rp = this.restPositions.get(name);
        if (rp) b.position.copy(rp);
      }
    }

    const speedMs = Math.hypot(physics.vel.x, physics.vel.z);
    const speedNorm = THREE.MathUtils.clamp(speedMs / 35, 0, 1);
    const wheelieNorm = THREE.MathUtils.clamp(physics.wheeliePitch / 1.15, 0, 1);
    const rpmNorm = THREE.MathUtils.clamp(physics.rpm / physics.maxRpm, 0, 1);
    const throttle = this.smoothThrottle;
    const frontBrake = this.smoothFrontBrake;
    const clutch = this.smoothClutch;
    const backShift = this.fpCamDistance;

    // Varied, fluid Brazilian Grau choreography (multi-harmonic waves so Grau never feels stiff)
    const manualMolejo = Math.abs(inputs?.molejo ?? 0);
    const breath = Math.sin(this.animTime * 2.4) * 0.010;
    const engineVib = Math.sin(this.animTime * (20 + rpmNorm * 28)) * 0.0022 * (0.25 + rpmNorm);
    const fluidGroove =
      Math.sin(physics.molejoPhase) * 0.62 +
      Math.sin(physics.molejoPhase * 0.54) * 0.42 +
      Math.cos(physics.molejoPhase * 1.44) * 0.24;
    const molejoCadence =
      fluidGroove *
      ((isFirstPerson ? 0.075 : 0.13) * wheelieNorm +
        (isFirstPerson ? 0.085 : 0.12) * manualMolejo * (1 + wheelieNorm * 0.35));
    const molejoWave = THREE.MathUtils.clamp(
      molejoCadence + physics.riderLateral * ((isFirstPerson ? 0.22 : 0.40) + wheelieNorm * (isFirstPerson ? 0.08 : 0.16)),
      isFirstPerson ? -0.40 : -0.85,
      isFirstPerson ? 0.40 : 0.85
    );

    // Three evolving Grau stunt grooves blended smoothly over time
    const grauPump =
      (Math.sin(physics.molejoPhase * 1.15) * 0.65 + Math.cos(physics.molejoPhase * 2.1) * 0.35) *
      wheelieNorm;
    const grauStandFloat =
      wheelieNorm * (0.28 + 0.72 * (0.5 + 0.5 * Math.sin(this.animTime * 0.68 + physics.molejoPhase * 0.15)));
    const grauShoulderGroove =
      wheelieNorm * Math.sin(physics.molejoPhase * 0.76 + Math.cos(this.animTime * 0.55) * 0.9);
    const rearBrakeVal = inputs?.rearBrake ?? 0;
    const grauThrottleSurge = (throttle - rearBrakeVal * 0.7) * wheelieNorm;
    const grauChestPump =
      grauPump * 0.09 +
      Math.sin(physics.molejoPhase * 0.64) * wheelieNorm * 0.075 +
      (rearBrakeVal * 0.11 - throttle * 0.06) * wheelieNorm;

    // Lively contextual riding life: street-scan glances when cruising, corner hang-off, & Grau head rhythm
    const cruiseLookYaw =
      (1 - speedNorm * 0.65) * (1 - wheelieNorm) * Math.sin(this.animTime * 0.72) * 0.11;
    const cornerHipShift =
      physics.leanAngle * (isFirstPerson ? 0.014 : 0.070) * (1 - wheelieNorm * 0.35);
    const cornerChestLean =
      physics.leanAngle * (isFirstPerson ? 0.08 : 0.18) * (1 - wheelieNorm * 0.4);
    const grauHeadNod = wheelieNorm * Math.sin(physics.molejoPhase * 1.12) * 0.062;
    const clutchTapAnim =
      clutch * 0.65 +
      (1 - clutch) * Math.max(0, Math.sin(this.animTime * 4.2)) * 0.05 * speedNorm * (1 - wheelieNorm);

    // Smooth forward aerodynamic tuck when accelerating & braking forward brace on 2 wheels
    const totalBrake = Math.max(frontBrake, rearBrakeVal * 0.65);
    const brakeBrace = totalBrake * (1 - wheelieNorm) * (isFirstPerson ? 0.095 : 0.13);
    const accelLean = throttle * (isFirstPerson ? 0.14 : 0.22) * (1 - wheelieNorm);
    const tuckAmount = THREE.MathUtils.clamp(
      (physics.riderForeAft < 0 ? -physics.riderForeAft * 0.55 : 0) +
        speedNorm * (isFirstPerson ? 0.11 : 0.20) * (1 - wheelieNorm) +
        accelLean,
      0,
      1
    );

    // Dynamic seat positioning: anchored cleanly forward enough so arms keep a solid ~40deg athletic elbow bend
    const hipX =
      (isFirstPerson
        ? -0.155 - Math.max(0, backShift) * 0.22 - wheelieNorm * 0.034 - tuckAmount * 0.015
        : -0.148 - wheelieNorm * 0.034 - tuckAmount * 0.018) +
      throttle * 0.022 * (1 - wheelieNorm) +
      totalBrake * 0.018 * (1 - wheelieNorm) +
      grauPump * 0.018 +
      grauStandFloat * 0.014;
    const hipY =
      (isFirstPerson ? 0.775 : 0.785) -
      tuckAmount * 0.020 -
      brakeBrace * 0.09 -
      wheelieNorm * 0.010 +
      grauStandFloat * (isFirstPerson ? 0.026 : 0.044) -
      Math.abs(molejoWave) * (isFirstPerson ? 0.012 : 0.012) -
      Math.abs(physics.leanAngle) * 0.014 +
      grauPump * 0.014 +
      engineVib;
    const hipMaxZ = isFirstPerson ? 0.052 + wheelieNorm * 0.02 : 0.095 + wheelieNorm * 0.032;
    const hipZ = THREE.MathUtils.clamp(
      molejoWave * ((isFirstPerson ? 0.042 : 0.072) + wheelieNorm * (isFirstPerson ? 0.016 : 0.034)) +
        cornerHipShift,
      -hipMaxZ,
      hipMaxZ
    );

    this.riderRoot.position.set(hipX, hipY, hipZ);
    hips.position.set(0, 0, 0);

    // Rider torso follows side-to-side steering & bike lean smoothly
    const bodyTurnFollow = physics.leanAngle * 0.24 + (inputs?.steer ?? 0) * 0.14;

    // Note: in rider local space (+Z forward, +X left, -X right):
    // +rx tilts torso FORWARD toward +Z; +rz rolls torso RIGHT (-X); -ry yaws shoulders RIGHT
    const pelvisPitch =
      (isFirstPerson
        ? 0.22 + tuckAmount * 0.10 - wheelieNorm * 0.11
        : 0.15 + tuckAmount * 0.12 - wheelieNorm * 0.11) +
      brakeBrace * 0.55 +
      grauChestPump * 0.65;
    this.applyLocalEuler(
      hips,
      pelvisPitch,
      -molejoWave * ((isFirstPerson ? 0.17 : 0.10) + wheelieNorm * 0.09) -
        grauShoulderGroove * 0.08 -
        bodyTurnFollow * 0.42,
      molejoWave * ((isFirstPerson ? 0.15 : 0.085) + wheelieNorm * 0.075) +
        grauShoulderGroove * 0.06 +
        cornerChestLean * 0.45 +
        bodyTurnFollow * 0.26
    );

    const torsoCurve =
      (isFirstPerson
        ? 0.32 + tuckAmount * 0.14 - wheelieNorm * 0.11 + breath
        : 0.24 + tuckAmount * 0.20 - wheelieNorm * 0.13 + breath) +
      brakeBrace * 0.78 +
      grauChestPump * 0.85;
    const lowerSway =
      molejoWave * ((isFirstPerson ? 0.15 : 0.10) + wheelieNorm * 0.07) +
      grauShoulderGroove * 0.05 +
      cornerChestLean * 0.65 +
      bodyTurnFollow * 0.32;
    const upperCounterSway =
      -molejoWave * ((isFirstPerson ? 0.08 : 0.055) + wheelieNorm * 0.045) -
      grauShoulderGroove * 0.07 +
      cornerChestLean * 0.45 +
      bodyTurnFollow * 0.28;
    const barFollowYaw =
      physics.steerAngle * 0.36 + grauShoulderGroove * 0.10 - bodyTurnFollow * 0.44;

    if (spine) {
      this.applyLocalEuler(
        spine,
        torsoCurve * 0.45,
        -molejoWave * ((isFirstPerson ? 0.09 : 0.055) + wheelieNorm * 0.06) - bodyTurnFollow * 0.38,
        lowerSway
      );
    }
    if (spine2) {
      this.applyLocalEuler(spine2, torsoCurve * 0.55, barFollowYaw, upperCounterSway);
    }

    const totalTorsoPitch = pelvisPitch + torsoCurve;
    const lookHorizon = -totalTorsoPitch * 0.76 - physics.wheeliePitch * 0.35;
    const grauHeadPeek = wheelieNorm * Math.sin(physics.molejoPhase * 0.68) * 0.16;
    if (neck) {
      this.applyLocalEuler(
        neck,
        lookHorizon * 0.55 + grauHeadNod * 0.45,
        -physics.leanAngle * 0.32 - barFollowYaw * 0.45 + grauHeadPeek + cruiseLookYaw * 0.65,
        -molejoWave * (isFirstPerson ? 0.16 : 0.11) - grauShoulderGroove * 0.06 - cornerChestLean * 0.45
      );
    }
    if (head) {
      this.applyLocalEuler(
        head,
        lookHorizon * 0.45 +
          Math.sin(this.animTime * 1.9 + rpmNorm * 3.0) * 0.015 +
          grauPump * 0.04 +
          grauHeadNod * 0.55 +
          frontBrake * (1 - wheelieNorm) * 0.048,
        -physics.leanAngle * 0.24 + grauHeadPeek * 0.4 + cruiseLookYaw * 0.45,
        -physics.leanAngle * 0.12
      );
    }

    const lShoulder = this.findBone('LeftShoulder_');
    const rShoulder = this.findBone('RightShoulder_');
    const reachShift = physics.steerAngle * 0.22;
    if (lShoulder) {
      this.applyLocalEuler(
        lShoulder,
        0.06 - wheelieNorm * 0.025 - grauThrottleSurge * 0.025 - Math.max(0, -physics.leanAngle) * 0.05,
        -0.12 - Math.max(0, -reachShift) * 0.24,
        -0.07 + molejoWave * 0.03
      );
    }
    if (rShoulder) {
      this.applyLocalEuler(
        rShoulder,
        0.06 - wheelieNorm * 0.025 - grauThrottleSurge * 0.025 - Math.max(0, physics.leanAngle) * 0.05,
        0.12 + Math.max(0, reachShift) * 0.24,
        0.07 + molejoWave * 0.03
      );
    }

    const lUpLeg = this.findBone('LeftUpLeg_');
    const lLeg = this.findBone('LeftLeg_');
    const lFoot = this.findBone('LeftFoot_');
    const rUpLeg = this.findBone('RightUpLeg_');
    const rLeg = this.findBone('RightLeg_');
    const rFoot = this.findBone('RightFoot_');

    // Initial leg bend in rider space (+rx bends leg forward, -rx bends knee backward)
    if (lUpLeg) this.applyLocalEuler(lUpLeg, -1.1, 0, -0.14);
    if (lLeg) this.applyLocalEuler(lLeg, 1.45, 0, 0);
    if (rUpLeg) this.applyLocalEuler(rUpLeg, -1.1, 0, 0.14);
    if (rLeg) this.applyLocalEuler(rLeg, 1.45, 0, 0);

    this.root.updateMatrixWorld(true);

    // Position 1st-Person Helmet Cam: peeks around raised tank & bars during Grau + Molejo,
    // and tucks slightly closer forward when accelerating!
    this.headCamAnchor.position.set(
      THREE.MathUtils.clamp(
        0.03 -
          backShift * 0.48 +
          Math.abs(physics.leanAngle) * 0.05 -
          wheelieNorm * 0.055 +
          throttle * 0.045 * (1 - wheelieNorm) +
          grauPump * 0.025,
        -0.16,
        0.18
      ),
      THREE.MathUtils.clamp(
        1.345 +
          Math.max(0, backShift) * 0.18 -
          Math.min(0, backShift) * 0.07 -
          Math.abs(physics.leanAngle) * 0.105 +
          wheelieNorm * 0.068 +
          grauStandFloat * 0.022 -
          throttle * 0.024 * (1 - wheelieNorm) -
          Math.abs(molejoWave) * 0.022 +
          engineVib * 0.3,
        1.20,
        1.54
      ),
      THREE.MathUtils.clamp(
        physics.leanAngle * 0.10 +
          molejoWave * (0.068 + wheelieNorm * 0.032) +
          grauShoulderGroove * 0.020,
        -0.14,
        0.14
      )
    );
    this.headCamAnchor.updateMatrixWorld(true);

    // Varied Grau + Cornering leg/knee choreography: inside knee-out on turns + periodic left-foot hover
    const leanLeft = Math.max(0, -physics.leanAngle);
    const leanRight = Math.max(0, physics.leanAngle);
    const kneeScale = isFirstPerson ? 1.0 : 0.78;
    const legWaveL = Math.max(0, Math.sin(physics.molejoPhase * 0.88));
    const legWaveR = Math.max(0, Math.cos(physics.molejoPhase * 0.82));
    const grauKneeL =
      wheelieNorm * (0.09 + Math.max(0, -molejoWave) * 0.18 + legWaveL * 0.12) * kneeScale;
    const grauKneeR =
      wheelieNorm * (0.09 + Math.max(0, molejoWave) * 0.18 + legWaveR * 0.12) * kneeScale;
    const kneeOutL =
      0.18 +
      leanLeft * 0.44 * kneeScale +
      Math.max(0, -molejoWave) * 0.18 * kneeScale +
      grauKneeL;
    const kneeOutR =
      0.18 +
      leanRight * 0.44 * kneeScale +
      Math.max(0, molejoWave) * 0.18 * kneeScale +
      grauKneeR;

    // Periodic left-foot hover/tap off the peg during deep Grau or Sem Mão
    const deepGrauGate = smoothstep(0.45, 0.85, wheelieNorm);
    const footWave = Math.max(0, Math.sin(this.animTime * 1.35 + physics.molejoPhase * 0.25));
    const lFootHover =
      deepGrauGate *
      (physics.noHandBlend * 0.08 + footWave * 0.065) *
      (isFirstPerson ? 0.55 : 1.0);

    if (lUpLeg && lLeg && lFoot) {
      this._vTarget.set(
        -0.227 - lFootHover * 0.45,
        0.33 + lFootHover * 1.15 + grauPump * 0.015,
        -0.205 - lFootHover * 0.40
      );
      this.chassisPivot.localToWorld(this._vTarget);
      this._vPole.set(
        0.34 + leanLeft * 0.16 + grauKneeL * 0.22,
        0.56 + leanLeft * 0.05 + grauKneeL * 0.24 + lFootHover * 0.35,
        -0.20 - kneeOutL
      );
      this.chassisPivot.localToWorld(this._vPole);
      this.solveTwoBoneIK(lUpLeg, lLeg, lFoot, this._vTarget, this._vPole);
      this.alignFootToPeg(lFoot, -0.12 - grauKneeL * 0.28 - lFootHover * 1.1);
    }
    if (rUpLeg && rLeg && rFoot) {
      // Right foot slides forward onto the rear brake pedal and stomps downward smoothly
      this._vTarget.set(
        -0.231 + rearBrakeVal * 0.048,
        0.335 - rearBrakeVal * 0.024,
        0.207 - rearBrakeVal * 0.014
      );
      this.chassisPivot.localToWorld(this._vTarget);
      this._vPole.set(
        0.34 + leanRight * 0.16 + grauKneeR * 0.22 + rearBrakeVal * 0.028,
        0.56 + leanRight * 0.05 + grauKneeR * 0.24 - rearBrakeVal * 0.026,
        0.20 + kneeOutR - rearBrakeVal * 0.020
      );
      this.chassisPivot.localToWorld(this._vPole);
      this.solveTwoBoneIK(rUpLeg, rLeg, rFoot, this._vTarget, this._vPole);
      this.alignFootToPeg(rFoot, 0.12 + grauKneeR * 0.28 - rearBrakeVal * 0.06, -rearBrakeVal * 0.44);
    }

    // Solve Arms onto Ducati Handlebar Grips with solid, hinge-aligned athletic posture (zero corkscrew twist)
    const lArm = this.findBone('LeftArm_');
    const lFore = this.findBone('LeftForeArm_');
    const lHand = this.findBone('LeftHand_');
    const lFingers = this.findBone('LeftFingers_');
    const rArm = this.findBone('RightArm_');
    const rFore = this.findBone('RightForeArm_');
    const rHand = this.findBone('RightHand_');
    const rFingers = this.findBone('RightFingers_');
    const rBrakeFingers = this.findBone('RightBrakeFingers_');

    const elbowBaseY = (isFirstPerson ? 1.11 : 1.10) + wheelieNorm * 0.015;
    const elbowDropR =
      elbowBaseY -
      throttle * 0.026 -
      frontBrake * 0.026 -
      leanRight * 0.032 +
      leanLeft * 0.018;
    const elbowDropL =
      elbowBaseY -
      frontBrake * 0.014 -
      leanLeft * 0.032 +
      leanRight * 0.018;
    const elbowOutR = 0.365 - leanRight * 0.028 + leanLeft * 0.018;
    const elbowOutL = 0.365 - leanLeft * 0.028 + leanRight * 0.018;
    const elbowFwdR = 0.045 - throttle * 0.014 + frontBrake * 0.024 + leanRight * 0.020;
    const elbowFwdL = 0.045 + frontBrake * 0.014 + leanLeft * 0.020;

    if (rArm && rFore && rHand) {
      this.rightGripTarget.getWorldPosition(this._vTarget);
      if (throttle > 0.005 || frontBrake > 0.005) {
        const wristShiftY = -throttle * 0.014 + frontBrake * 0.010;
        const wristShiftX = throttle * 0.005 - frontBrake * 0.010;
        this._vA.set(wristShiftX, wristShiftY, 0);
        this.steeringHeadPivot.getWorldQuaternion(this._qSteer);
        this._vA.applyQuaternion(this._qSteer);
        this._vTarget.add(this._vA);
      }
      if (rShoulder) {
        rArm.getWorldPosition(this._vA);
        const reachDist = this._vA.distanceTo(this._vTarget);
        const extra = smoothstep(0.41, 0.50, reachDist) * 0.16;
        if (extra > 0.001) {
          this.applyLocalEuler(rShoulder, 0, extra, 0);
          rShoulder.updateMatrixWorld(true);
        }
      }
      this._vPole.set(elbowFwdR, elbowDropR, elbowOutR);
      this.chassisPivot.localToWorld(this._vPole);
      this.solveArmIK(rArm, rFore, rHand, this._vTarget, this._vPole, 'right');
      this.alignHandToGrip(rHand, 'right', throttle, frontBrake, 1);
      this.twistForearmToHand(rFore, rHand, 0.22);
      const baseRightCurl = 1.50 + throttle * 0.14;
      if (rFingers) {
        rFingers.rotation.set(0, 0, baseRightCurl);
        rFingers.updateMatrixWorld(true);
      }
      if (rBrakeFingers) {
        const reachOpen = smoothstep(0.0, 0.28, frontBrake) * 0.78;
        const squeezePull = smoothstep(0.22, 1.0, frontBrake) * 0.30;
        rBrakeFingers.rotation.set(0, 0, baseRightCurl - reachOpen + squeezePull);
        rBrakeFingers.updateMatrixWorld(true);
      }
    }

    if (lArm && lFore && lHand) {
      this.leftGripTarget.getWorldPosition(this._vTarget);
      const emoteBlend = Math.max(physics.noHandBlend, this.smoothEmoteBlend);
      const activeEm = this.activeEmoteType !== 'none' ? this.activeEmoteType : 'salve';

      let lPoleX = elbowFwdL;
      let lPoleY = elbowDropL;
      let lPoleZ = -elbowOutL;

      if (emoteBlend > 0.01) {
        let tx = 0.02;
        let ty = 1.48;
        let tz = -0.50;
        let px = -0.04;
        let py = 1.14;
        let pz = -0.46;

        if (activeEm === 'salve') {
          tx = 0.04 + Math.cos(this.animTime * 6.5) * 0.05;
          ty = 1.54 + Math.sin(this.animTime * 6.5) * 0.07;
          tz = -0.48 - Math.sin(this.animTime * 3.2) * 0.08;
        } else if (activeEm === 'hang_loose') {
          tx = -0.02 + Math.cos(physics.molejoPhase * 0.9) * 0.08;
          ty = 1.24 + Math.sin(this.animTime * 5.2) * 0.08;
          tz = -0.64;
          py = 1.12;
          pz = -0.36;
        } else if (activeEm === 'salute') {
          tx = 0.10;
          ty = 1.46;
          tz = -0.18;
          px = 0.06;
          py = 1.20;
          pz = -0.44;
        } else if (activeEm === 'flex') {
          tx = 0.00;
          ty = 1.46 + Math.sin(this.animTime * 6.0) * 0.03;
          tz = -0.34;
          px = -0.02;
          py = 1.16;
          pz = -0.48;
        } else if (activeEm === 'celebrate') {
          tx = 0.00;
          ty = 1.62 + Math.sin(this.animTime * 7.0) * 0.05;
          tz = -0.54;
          py = 1.32;
          pz = -0.42;
        } else if (activeEm === 'clap') {
          tx = 0.14;
          ty = 1.18 + Math.abs(Math.sin(this.animTime * 8.5)) * 0.09;
          tz = -0.22;
          px = 0.02;
          py = 1.04;
          pz = -0.40;
        }

        this._vA.set(tx, ty, tz);
        this.chassisPivot.localToWorld(this._vA);
        this._vTarget.lerp(this._vA, emoteBlend);

        lPoleX = THREE.MathUtils.lerp(elbowFwdL, px, emoteBlend);
        lPoleY = THREE.MathUtils.lerp(elbowDropL, py, emoteBlend);
        lPoleZ = THREE.MathUtils.lerp(-elbowOutL, pz, emoteBlend);
      } else if (lShoulder) {
        lArm.getWorldPosition(this._vA);
        const reachDist = this._vA.distanceTo(this._vTarget);
        const extra = smoothstep(0.41, 0.50, reachDist) * 0.16;
        if (extra > 0.001) {
          this.applyLocalEuler(lShoulder, 0, -extra, 0);
          lShoulder.updateMatrixWorld(true);
        }
      }

      this._vPole.set(lPoleX, lPoleY, lPoleZ);
      this.chassisPivot.localToWorld(this._vPole);
      this.solveArmIK(lArm, lFore, lHand, this._vTarget, this._vPole, 'left');
      this.alignHandToGrip(lHand, 'left', 0, clutchTapAnim, 1 - emoteBlend);
      this.twistForearmToHand(lFore, lHand, 0.22 * (1 - emoteBlend));
      if (lFingers) {
        const emCurl = activeEm === 'flex' ? -1.35 : -0.18;
        lFingers.rotation.set(
          0,
          0,
          THREE.MathUtils.lerp(-1.50 + clutchTapAnim * 0.86, emCurl, emoteBlend)
        );
        lFingers.updateMatrixWorld(true);
      }
    }
  }

  private alignFootToPeg(foot: THREE.Bone, toeOutYaw: number, toePitch = 0): void {
    if (!foot.parent) return;
    this.chassisPivot.getWorldQuaternion(this._qSteer);
    // Rider foot rest pose has +Z = toes forward, +Y = up, +X = left -> map to chassis +X forward, +Y up, -Z left
    this._vHZ.set(Math.cos(toeOutYaw), -0.14 + toePitch, Math.sin(toeOutYaw)).normalize();
    this._vHY.set(0.14, 0.99, 0).normalize();
    this._vHX.crossVectors(this._vHY, this._vHZ).normalize();
    this._vHY.crossVectors(this._vHZ, this._vHX).normalize();
    this._mBasis.makeBasis(this._vHX, this._vHY, this._vHZ);
    this._qGrip.setFromRotationMatrix(this._mBasis).premultiply(this._qSteer);
    foot.parent.getWorldQuaternion(this._qParent);
    foot.quaternion.copy(this._qParent).invert().multiply(this._qGrip);
    foot.updateMatrixWorld(true);
  }

  /**
   * Aligns our procedural hand bones directly in steeringHeadPivot's swept-bar frame:
   * - Swept Ducati Streetfighter bars angle back ~16 deg (0.27 rad)
   * - Compensates steeringHeadPivot +RAKE_RAD so neutral knuckles (-0.14 rad in bike space) continue the downward forearm slope
   * - Throttle acceleration (+throttle) rolls right knuckles BACKWARD/UP (+0.30 rad) around the grip tube!
   */
  private alignHandToGrip(
    hand: THREE.Bone,
    side: 'left' | 'right',
    throttle: number,
    frontBrake: number,
    weight: number
  ): void {
    if (weight <= 0.001 || !hand.parent) return;

    this.steeringHeadPivot.getWorldQuaternion(this._qSteer);

    const fingerAngle = -RAKE_RAD - 0.14 + throttle * 0.30 - frontBrake * 0.22;
    const cosA = Math.cos(fingerAngle);
    const sinA = Math.sin(fingerAngle);

    if (side === 'left') {
      this._vHX.set(cosA, sinA, -0.25).normalize(); // +X: fingers forward & slightly outward along swept bar
      this._vHZ.set(0.25, 0.02, 0.96).normalize(); // +Z: thumb inward along handlebar stem
      this._vHY.crossVectors(this._vHZ, this._vHX).normalize(); // +Y: back of hand UP
      this._vHZ.crossVectors(this._vHX, this._vHY).normalize();
    } else {
      this._vHX.set(-cosA, -sinA, -0.25).normalize(); // -X: fingers forward & slightly outward along swept bar
      this._vHZ.set(0.25, 0.02, -0.96).normalize(); // +Z: thumb inward along handlebar stem
      this._vHY.crossVectors(this._vHZ, this._vHX).normalize(); // +Y: back of hand UP
      this._vHZ.crossVectors(this._vHX, this._vHY).normalize();
    }

    this._mBasis.makeBasis(this._vHX, this._vHY, this._vHZ);
    this._qGrip.setFromRotationMatrix(this._mBasis).premultiply(this._qSteer);

    hand.parent.getWorldQuaternion(this._qParent);
    this._qDelta.copy(this._qParent).invert().multiply(this._qGrip);

    if (weight >= 0.999) {
      hand.quaternion.copy(this._qDelta);
    } else {
      hand.quaternion.slerp(this._qDelta, weight);
    }
    hand.updateMatrixWorld(true);
  }

  /**
   * Pronates/supinates the forearm bone smoothly toward the wrist's orientation around the
   * elbow-to-wrist axis, eliminating pinched wrist creases while preserving exact hand grip lock.
   */
  private twistForearmToHand(fore: THREE.Bone, hand: THREE.Bone, blend: number): void {
    if (blend <= 0.001 || !fore.parent) return;

    fore.getWorldPosition(this._vA);
    hand.getWorldPosition(this._vB);
    this._ikDir.subVectors(this._vB, this._vA);
    if (this._ikDir.lengthSq() < 1e-6) return;
    this._ikDir.normalize();

    fore.getWorldQuaternion(this._qWorld);
    hand.getWorldQuaternion(this._qGrip);

    // Back-of-forearm (+Y) vs back-of-hand (+Y) projected orthogonal to forearm axis
    this._vHX.set(0, 1, 0).applyQuaternion(this._qWorld);
    this._vHX.addScaledVector(this._ikDir, -this._vHX.dot(this._ikDir));
    this._vHY.set(0, 1, 0).applyQuaternion(this._qGrip);
    this._vHY.addScaledVector(this._ikDir, -this._vHY.dot(this._ikDir));

    if (this._vHX.lengthSq() < 1e-5 || this._vHY.lengthSq() < 1e-5) return;
    this._vHX.normalize();
    this._vHY.normalize();

    this._vHZ.crossVectors(this._vHX, this._vHY);
    const sinTheta = this._vHZ.dot(this._ikDir);
    const cosTheta = THREE.MathUtils.clamp(this._vHX.dot(this._vHY), -1, 1);
    const twistAngle = THREE.MathUtils.clamp(Math.atan2(sinTheta, cosTheta), -0.65, 0.65) * blend;

    this._qDelta.setFromAxisAngle(this._ikDir, twistAngle);
    this._qWorld.premultiply(this._qDelta);
    fore.parent.getWorldQuaternion(this._qParent);
    fore.quaternion.copy(this._qParent).invert().multiply(this._qWorld);
    fore.updateMatrixWorld(true);

    // Re-lock hand world orientation so grip alignment remains 100% exact
    fore.getWorldQuaternion(this._qParent);
    hand.quaternion.copy(this._qParent).invert().multiply(this._qGrip);
    hand.updateMatrixWorld(true);
  }

  private applyLocalEuler(bone: THREE.Bone, rx: number, ry: number, rz: number): void {
    this._euler.set(rx, ry, rz, 'XYZ');
    this._qDelta.setFromEuler(this._euler);
    bone.quaternion.multiply(this._qDelta);
  }

  private solveArmIK(
    upper: THREE.Bone,
    mid: THREE.Bone,
    end: THREE.Bone,
    targetWorld: THREE.Vector3,
    poleWorld: THREE.Vector3,
    side: 'left' | 'right'
  ): void {
    upper.updateMatrixWorld(true);
    upper.getWorldPosition(this._vA);
    mid.getWorldPosition(this._vB);
    end.getWorldPosition(this._vC);

    const len1 = this._vA.distanceTo(this._vB);
    const len2 = this._vB.distanceTo(this._vC);
    if (len1 < 1e-4 || len2 < 1e-4) return;

    this._ikToTarget.subVectors(targetWorld, this._vA);
    const rawLen = this._ikToTarget.length();
    if (rawLen < 1e-5) return;
    const dist = THREE.MathUtils.clamp(
      rawLen,
      Math.abs(len1 - len2) + 0.03,
      len1 + len2 - 0.015
    );
    this._ikDir.copy(this._ikToTarget).divideScalar(rawLen);

    const cosAngleUpper = THREE.MathUtils.clamp(
      (len1 * len1 + dist * dist - len2 * len2) / (2 * len1 * dist),
      -1,
      1
    );
    const angleUpper = Math.acos(cosAngleUpper);

    this._ikToPole.subVectors(poleWorld, this._vA);
    this._ikToPole.addScaledVector(this._ikDir, -this._ikToPole.dot(this._ikDir));
    if (this._ikToPole.lengthSq() < 1e-6) this._ikToPole.set(0, -1, 0);
    this._ikToPole.normalize();

    this._ikDesiredMid
      .copy(this._vA)
      .addScaledVector(this._ikDir, Math.cos(angleUpper) * len1)
      .addScaledVector(this._ikToPole, Math.sin(angleUpper) * len1);

    // Direction of upper arm & forearm in world space
    this._ikCurDir.subVectors(this._ikDesiredMid, this._vA).normalize(); // dirUpper
    this._ikWantDir
      .copy(this._vA)
      .addScaledVector(this._ikDir, dist)
      .sub(this._ikDesiredMid);
    if (this._ikWantDir.lengthSq() < 1e-6) {
      this._ikWantDir.copy(this._ikCurDir);
    } else {
      this._ikWantDir.normalize(); // dirFore
    }

    // Shared anatomical elbow hinge normal:
    // Left arm (+X) bending forward (+Z) -> cross(dirFore, dirUpper) points UP (+Y)
    // Right arm (-X) bending forward (+Z) -> cross(dirUpper, dirFore) points UP (+Y)
    if (side === 'left') {
      this._vHY.crossVectors(this._ikWantDir, this._ikCurDir);
      if (this._vHY.lengthSq() < 1e-5) {
        this._vHY.crossVectors(this._ikToPole, this._ikCurDir);
      }
    } else {
      this._vHY.crossVectors(this._ikCurDir, this._ikWantDir);
      if (this._vHY.lengthSq() < 1e-5) {
        this._vHY.crossVectors(this._ikCurDir, this._ikToPole);
      }
    }
    if (this._vHY.lengthSq() < 1e-6) this._vHY.set(0, 1, 0);
    this._vHY.normalize();

    // Orient Upper Arm with zero corkscrew twist relative to ForeArm
    const signX = side === 'left' ? 1 : -1;
    this._vHX.copy(this._ikCurDir).multiplyScalar(signX);
    this._vHZ.crossVectors(this._vHX, this._vHY).normalize();
    this._vHY.crossVectors(this._vHZ, this._vHX).normalize();
    this._mBasis.makeBasis(this._vHX, this._vHY, this._vHZ);
    this._qWorld.setFromRotationMatrix(this._mBasis);
    upper.parent!.getWorldQuaternion(this._qParent);
    upper.quaternion.copy(this._qParent).invert().multiply(this._qWorld);
    upper.updateMatrixWorld(true);

    // Orient ForeArm sharing the exact same elbow hinge axis (zero rubbery elbow collapse)
    this._vHX.copy(this._ikWantDir).multiplyScalar(signX);
    this._vHZ.crossVectors(this._vHX, this._vHY).normalize();
    this._vHY.crossVectors(this._vHZ, this._vHX).normalize();
    this._mBasis.makeBasis(this._vHX, this._vHY, this._vHZ);
    this._qWorld.setFromRotationMatrix(this._mBasis);
    mid.parent!.getWorldQuaternion(this._qParent);
    mid.quaternion.copy(this._qParent).invert().multiply(this._qWorld);
    mid.updateMatrixWorld(true);
  }

  private solveTwoBoneIK(
    upper: THREE.Bone,
    mid: THREE.Bone,
    end: THREE.Bone,
    targetWorld: THREE.Vector3,
    poleWorld: THREE.Vector3,
    _lockEnd = false
  ): void {
    upper.updateMatrixWorld(true);

    upper.getWorldPosition(this._vA);
    mid.getWorldPosition(this._vB);
    end.getWorldPosition(this._vC);

    const len1 = this._vA.distanceTo(this._vB);
    const len2 = this._vB.distanceTo(this._vC);
    if (len1 < 1e-4 || len2 < 1e-4) return;

    this._ikToTarget.subVectors(targetWorld, this._vA);
    const dist = THREE.MathUtils.clamp(
      this._ikToTarget.length(),
      Math.abs(len1 - len2) + 0.02,
      len1 + len2 - 0.012
    );
    this._ikDir.copy(this._ikToTarget).normalize();

    const cosAngleUpper = THREE.MathUtils.clamp(
      (len1 * len1 + dist * dist - len2 * len2) / (2 * len1 * dist),
      -1,
      1
    );
    const angleUpper = Math.acos(cosAngleUpper);

    this._ikToPole.subVectors(poleWorld, this._vA);
    this._ikToPole.addScaledVector(this._ikDir, -this._ikToPole.dot(this._ikDir));
    if (this._ikToPole.lengthSq() < 1e-6) this._ikToPole.set(0, 1, 0);
    this._ikToPole.normalize();

    this._ikDesiredMid
      .copy(this._vA)
      .addScaledVector(this._ikDir, Math.cos(angleUpper) * len1)
      .addScaledVector(this._ikToPole, Math.sin(angleUpper) * len1);

    this._ikCurDir.subVectors(this._vB, this._vA).normalize();
    this._ikWantDir.subVectors(this._ikDesiredMid, this._vA).normalize();
    this._qDelta.setFromUnitVectors(this._ikCurDir, this._ikWantDir);
    upper.getWorldQuaternion(this._qWorld);
    this._qWorld.premultiply(this._qDelta);
    upper.parent!.getWorldQuaternion(this._qParent);
    upper.quaternion.copy(this._qParent.invert().multiply(this._qWorld));
    upper.updateMatrixWorld(true);

    mid.getWorldPosition(this._vB);
    end.getWorldPosition(this._vC);
    this._ikCurDir.subVectors(this._vC, this._vB).normalize();
    this._ikWantDir.subVectors(targetWorld, this._vB).normalize();
    this._qDelta.setFromUnitVectors(this._ikCurDir, this._ikWantDir);
    mid.getWorldQuaternion(this._qWorld);
    this._qWorld.premultiply(this._qDelta);
    mid.parent!.getWorldQuaternion(this._qParent);
    mid.quaternion.copy(this._qParent.invert().multiply(this._qWorld));
    mid.updateMatrixWorld(true);
  }
}
