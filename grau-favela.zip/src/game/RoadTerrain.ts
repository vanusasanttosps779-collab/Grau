import * as THREE from 'three';

export interface StreetSegment {
  id: string;
  ax: number;
  az: number;
  bx: number;
  bz: number;
  halfWidth: number;
  isAlley?: boolean;
}

export interface StuntRamp {
  x: number;
  z: number;
  yaw: number; // direction ramp ascends toward
  length: number;
  halfWidth: number;
  height: number;
}

export interface LombadaSpec {
  x: number;
  z: number;
  nx: number; // travel direction unit vector
  nz: number;
  halfWidth: number;
}

export interface GroundHit {
  height: number;
  nx: number;
  ny: number;
  nz: number;
  surface: 'asphalt' | 'lombada' | 'sidewalk' | 'plaza' | 'dirt';
}

export const WORLD_HALF_EXTENT = 480;

// Expanded Open-World Favela & Baixada City Network (~900m x 560m)
export const STREETS: StreetSegment[] = [
  // East-West Avenues (Baixada -> Centro -> Morro)
  { id: 'av_marginal', ax: -430, az: 210, bx: 430, bz: 210, halfWidth: 6.2 },
  { id: 'av_brasil', ax: -420, az: 115, bx: 420, bz: 115, halfWidth: 5.2 },
  { id: 'av_principal', ax: -430, az: 0, bx: 430, bz: 0, halfWidth: 5.8 },
  { id: 'rua_laje', ax: -410, az: -95, bx: 410, bz: -95, halfWidth: 4.6 },
  { id: 'rua_mirante', ax: -380, az: -195, bx: 380, bz: -195, halfWidth: 4.5 },
  { id: 'rua_topo', ax: -310, az: -290, bx: 310, bz: -290, halfWidth: 4.3 },

  // North-South Cross Streets (connecting Baixada, Centro & Alto do Morro)
  { id: 'tv_ponte', ax: -380, az: -200, bx: -380, bz: 216, halfWidth: 4.8 },
  { id: 'tv_oeste', ax: -265, az: -295, bx: -265, bz: 216, halfWidth: 4.6 },
  { id: 'tv_padaria', ax: -135, az: -295, bx: -135, bz: 216, halfWidth: 4.8 },
  { id: 'tv_central', ax: 0, az: -295, bx: 0, bz: 216, halfWidth: 5.2 },
  { id: 'tv_quadra', ax: 125, az: -295, bx: 125, bz: 216, halfWidth: 4.8 },
  { id: 'tv_leste', ax: 265, az: -295, bx: 265, bz: 216, halfWidth: 4.6 },
  { id: 'tv_viaduto', ax: 390, az: -200, bx: 390, bz: 216, halfWidth: 4.8 },

  // Diagonal Becos / Atalhos da Favela
  { id: 'beco_morro', ax: -55, az: 0, bx: -25, bz: -95, halfWidth: 3.1, isAlley: true },
  { id: 'beco_mirante', ax: 60, az: -95, bx: 95, bz: -195, halfWidth: 3.1, isAlley: true },
  { id: 'beco_baixada', ax: -205, az: 115, bx: -170, bz: 0, halfWidth: 3.2, isAlley: true },
  { id: 'beco_leste', ax: 195, az: 0, bx: 230, bz: 115, halfWidth: 3.2, isAlley: true },
];

// Central Open Plaza & Futsal Court ("Quadra do Grau")
export const PLAZA_RECT = {
  minX: 28,
  maxX: 98,
  minZ: 14,
  maxZ: 74,
};

// Stunt Ramps spread across the expanded city
export const STUNT_RAMPS: StuntRamp[] = [
  { x: 62, z: 44, yaw: 0, length: 6.5, halfWidth: 2.6, height: 1.15 },
  { x: 195, z: 0, yaw: 0, length: 5.8, halfWidth: 2.3, height: 0.95 },
  { x: -200, z: 0, yaw: Math.PI, length: 5.8, halfWidth: 2.3, height: 0.95 },
  { x: 75, z: 210, yaw: 0, length: 7.0, halfWidth: 2.8, height: 1.25 },
  { x: -195, z: 210, yaw: Math.PI, length: 6.5, halfWidth: 2.6, height: 1.15 },
  { x: 65, z: -195, yaw: 0, length: 5.5, halfWidth: 2.2, height: 0.95 },
];

// Speed Bumps (Lombadas) across the city avenues
export const LOMBADAS: LombadaSpec[] = [
  { x: -35, z: 0, nx: 1, nz: 0, halfWidth: 5.6 },
  { x: 60, z: 0, nx: 1, nz: 0, halfWidth: 5.6 },
  { x: -210, z: 115, nx: 1, nz: 0, halfWidth: 5.0 },
  { x: 200, z: 115, nx: 1, nz: 0, halfWidth: 5.0 },
  { x: -35, z: -95, nx: 1, nz: 0, halfWidth: 4.4 },
  { x: 190, z: -95, nx: 1, nz: 0, halfWidth: 4.4 },
  { x: 0, z: 58, nx: 0, nz: -1, halfWidth: 5.0 },
  { x: 0, z: -48, nx: 0, nz: -1, halfWidth: 5.0 },
  { x: -75, z: 210, nx: 1, nz: 0, halfWidth: 6.0 },
];

export class RoadTerrain {
  public readonly roadSamplesForMinimap = STREETS;

  /**
   * Smooth analytical favela hillside terrain heightfield:
   * - Baixada & Avenues (z >= -25) stay fast and flat/gentle for high-speed Grau
   * - Morro climbs smoothly northward (z < -25) up to ~26m at Rua do Topo
   */
  public baseTerrainHeight(x: number, z: number): number {
    // Smooth ramp up into the Morro for z < -22
    const morroT = THREE.MathUtils.clamp((-z - 22) / 280, 0, 1);
    const morroSmooth = morroT * morroT * (3 - 2 * morroT);
    const hillRise = morroSmooth * 26.0;

    // Gentle rolling hillside undulation
    const roll =
      Math.sin(x * 0.013) * Math.cos(z * 0.014) * 1.6 * morroSmooth +
      Math.sin((x + z) * 0.01) * 0.55;

    // Keep the central plaza / quadra flat at y=0
    if (
      x >= PLAZA_RECT.minX - 6 &&
      x <= PLAZA_RECT.maxX + 6 &&
      z >= PLAZA_RECT.minZ - 6 &&
      z <= PLAZA_RECT.maxZ + 6
    ) {
      return 0;
    }

    return hillRise + roll;
  }

  public isPointInBlock(x: number, z: number, margin = 2.0): boolean {
    // Check Plaza
    if (
      x >= PLAZA_RECT.minX - margin &&
      x <= PLAZA_RECT.maxX + margin &&
      z >= PLAZA_RECT.minZ - margin &&
      z <= PLAZA_RECT.maxZ + margin
    ) {
      return false;
    }

    // Check distance to every street segment
    for (let i = 0; i < STREETS.length; i++) {
      const s = STREETS[i];
      const abx = s.bx - s.ax;
      const abz = s.bz - s.az;
      const len2 = abx * abx + abz * abz || 1;
      const t = THREE.MathUtils.clamp(((x - s.ax) * abx + (z - s.az) * abz) / len2, 0, 1);
      const px = s.ax + abx * t;
      const pz = s.az + abz * t;
      const dist = Math.hypot(x - px, z - pz);
      if (dist < s.halfWidth + margin) {
        return false;
      }
    }
    return true;
  }

  public sampleGround(x: number, z: number, out: GroundHit): GroundHit {
    let baseH = this.baseTerrainHeight(x, z);
    let surface: GroundHit['surface'] = 'dirt';

    // Check Plaza / Quadra
    if (
      x >= PLAZA_RECT.minX &&
      x <= PLAZA_RECT.maxX &&
      z >= PLAZA_RECT.minZ &&
      z <= PLAZA_RECT.maxZ
    ) {
      surface = 'plaza';
      baseH = 0.04;
    }

    // Check distance to nearest street
    let minStreetDist = Infinity;
    let nearestHalfW = 4.5;
    for (let i = 0; i < STREETS.length; i++) {
      const s = STREETS[i];
      const abx = s.bx - s.ax;
      const abz = s.bz - s.az;
      const len2 = abx * abx + abz * abz || 1;
      const t = THREE.MathUtils.clamp(((x - s.ax) * abx + (z - s.az) * abz) / len2, 0, 1);
      const px = s.ax + abx * t;
      const pz = s.az + abz * t;
      const d = Math.hypot(x - px, z - pz);
      if (d - s.halfWidth < minStreetDist - nearestHalfW) {
        minStreetDist = d;
        nearestHalfW = s.halfWidth;
      }
    }

    if (minStreetDist <= nearestHalfW) {
      surface = 'asphalt';
    } else if (minStreetDist <= nearestHalfW + 1.9 && surface !== 'plaza') {
      surface = 'sidewalk';
      const curbRamp = Math.min(1, (minStreetDist - nearestHalfW) / 0.14);
      baseH += 0.11 * curbRamp;
    }

    // Check Lombadas
    for (let i = 0; i < LOMBADAS.length; i++) {
      const l = LOMBADAS[i];
      const dx = x - l.x;
      const dz = z - l.z;
      const along = Math.abs(dx * l.nx + dz * l.nz);
      const across = Math.abs(dx * -l.nz + dz * l.nx);
      if (along < 1.15 && across <= l.halfWidth) {
        const phase = (along / 1.15) * Math.PI * 0.5;
        baseH += 0.14 * Math.cos(phase) * Math.cos(phase);
        surface = 'lombada';
      }
    }

    // Check Stunt Ramps
    for (let i = 0; i < STUNT_RAMPS.length; i++) {
      const r = STUNT_RAMPS[i];
      const cosY = Math.cos(r.yaw);
      const sinY = Math.sin(r.yaw);
      const dx = x - r.x;
      const dz = z - r.z;
      const localX = dx * cosY - dz * sinY;
      const localZ = dx * sinY + dz * cosY;
      if (
        localX >= -r.length * 0.5 &&
        localX <= r.length * 0.5 &&
        Math.abs(localZ) <= r.halfWidth
      ) {
        const u = (localX + r.length * 0.5) / r.length;
        baseH += u * r.height;
        surface = 'plaza';
      }
    }

    // Finite-difference surface normal for true 3D hill pitch
    const eps = 0.35;
    const hx1 = this.baseTerrainHeight(x + eps, z);
    const hx0 = this.baseTerrainHeight(x - eps, z);
    const hz1 = this.baseTerrainHeight(x, z + eps);
    const hz0 = this.baseTerrainHeight(x, z - eps);
    const dHx = (hx1 - hx0) / (2 * eps);
    const dHz = (hz1 - hz0) / (2 * eps);
    const inv = 1 / Math.hypot(dHx, 1, dHz);

    out.height = baseH;
    out.nx = -dHx * inv;
    out.ny = inv;
    out.nz = -dHz * inv;
    out.surface = surface;
    return out;
  }
}
