export type CameraMode = 'first_person' | 'third_person' | 'moto_vlog' | 'free_orbit';

export type PhysicsPreset = 'mx_pro' | 'simulation' | 'assist';

export type GraphicsQuality = 'low' | 'medium' | 'high' | 'ultra';

export type EmoteId =
  | 'none'
  | 'salve'
  | 'hang_loose'
  | 'salute'
  | 'flex'
  | 'celebrate'
  | 'clap';

export interface ControlInputs {
  throttle: number; // 0..1
  frontBrake: number; // 0..1
  rearBrake: number; // 0..1 (freio no pé - essencial pro grau)
  steer: number; // -1 (left) .. +1 (right)
  riderPitch: number; // -1 (lean forward/tuck) .. +1 (lean back/pull grau)
  molejo: number; // -1 .. +1 (extra body sway)
  clutch: boolean; // clutch kick / embrear
  noHand: boolean; // grau sem mão / salve
  burnout: boolean;
  emote?: EmoteId;
}

export type RiderState = 'mounted' | 'dismounting' | 'on_foot' | 'mounting';

export type GloveStyle = 'none' | 'black' | 'ducati_red' | 'white';

export interface TelemetryState {
  speedKmh: number;
  rpm: number;
  maxRpm: number;
  gear: number; // 0 = N, 1..6
  wheelieAngleDeg: number; // 0..95
  stoppieAngleDeg: number; // 0..60
  leanAngleDeg: number; // -55..+55
  frontSuspRatio: number; // 0..1 compressed
  rearSuspRatio: number; // 0..1 compressed
  rearSlip: number; // 0..1
  isWheelie: boolean;
  isBalancePoint: boolean;
  isScrape: boolean;
  isStoppie: boolean;
  isAirborne: boolean;
  isNoHand: boolean;
  activeEmote: EmoteId;
  revLimiter: boolean;
  clutchEngaged: boolean;
  grauDistanceM: number;
  grauDurationS: number;
  currentCombo: number;
  totalScore: number;
  bestGrauDistanceM: number;
  bestCombo: number;
  crashed: boolean;
  crashReason: string;
  posX: number;
  posZ: number;
  yawRad: number;
  riderState: RiderState;
  nearBike: boolean;
  dismountHint: string;
}

export interface LoadProgress {
  loaded: boolean;
  percent: number;
  statusText: string;
  error: string | null;
}
